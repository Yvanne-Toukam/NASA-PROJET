/* ASTRA-MED — banc d'essai reproductible (méthodologie expérimentale, hypothèses H1, H2, H5) */
(function () {
  'use strict';
  const A = window.ASTRA;

  A.DETECTORS = {
    A: 'A · Seuils généraux (FC, SpO₂, FR)',
    B: 'B · Ligne de base personnelle, FC seule',
    C: 'C · Multi-paramètres personnalisé (FC + SpO₂ + FR)',
    D: 'D · Multi-paramètres + CO₂ ambiant'
  };
  A.ANOM_TYPES = {
    subtle: 'Dérive discrète (fatigue)',
    cardiac: 'Anomalie cardiaque',
    resp: 'Dégradation respiratoire',
    env: 'Atmosphère dégradée (CO₂)'
  };

  A.runBenchmark = function (N, seed) {
    const rng = A.makeRng(seed), g = () => A.gauss(rng);
    const names = ['A', 'B', 'C', 'D'];
    const R = {}, byType = {};
    names.forEach(n => (R[n] = { tp: 0, fp: 0, tn: 0, fn: 0, lat: [] }));
    const types = Object.keys(A.ANOM_TYPES);
    types.forEach(t => (byType[t] = { n: 0, A: 0, B: 0, C: 0, D: 0 }));
    const WARM = 576, TEST = 288;

    for (let run = 0; run < N; run++) {
      const anomalous = rng() < 0.5;
      const type = types[Math.floor(rng() * types.length)];
      const p = { hr: 48 + rng() * 40, spo2: 96 + rng() * 2.3, rr: 12 + rng() * 5, co2: 650 + rng() * 150 };
      const nz = { hr: 2.5, spo2: 0.45, rr: 0.9, co2: 60 };
      const onset = 60 + Math.floor(rng() * 140);
      const X = [];
      for (let t = 0; t < WARM + TEST; t++) {
        const k = t - WARM;
        const f = anomalous && k >= onset ? Math.min(1, (k - onset + 1) / 20) : 0;
        let hr = p.hr + g() * nz.hr, spo2 = p.spo2 + g() * nz.spo2, rr = p.rr + g() * nz.rr, co2 = p.co2 + g() * nz.co2;
        if (f > 0) {
          if (type === 'subtle') { hr += 0.10 * p.hr * f; spo2 -= 1.3 * f; rr += 2.6 * f; }
          else if (type === 'cardiac') { hr += 35 * f; }
          else if (type === 'resp') { spo2 -= 6 * f; rr += 8 * f; }
          else if (type === 'env') { co2 += 1800 * f; spo2 -= 0.9 * f; rr += 1.8 * f; }
        }
        X.push({ hr, spo2, rr, co2 });
      }
      const W = X.slice(0, WARM);
      const c = {}, s = {};
      ['hr', 'spo2', 'rr', 'co2'].forEach(k => { const arr = W.map(x => x[k]); c[k] = A.mean(arr); s[k] = Math.max(A.sd(arr), 1e-6); });
      const zhr = x => Math.abs(x.hr - c.hr) / s.hr;
      const zsp = x => Math.max(0, (c.spo2 - x.spo2) / s.spo2);
      const zrr = x => Math.max(0, (x.rr - c.rr) / s.rr);
      const zco = x => Math.max(0, (x.co2 - c.co2) / s.co2);
      function ewma(stat) {
        let e = 0; const out = [];
        X.forEach((x, i) => { const v = stat(x); e = i === 0 ? v : 0.35 * v + 0.65 * e; out.push(e); });
        return out;
      }
      function calib(series) { let m = 0; for (let i = 20; i < WARM; i++) m = Math.max(m, series[i]); return m * 1.15; }
      const sC = ewma(x => (zhr(x) + zsp(x) + zrr(x)) / Math.sqrt(3)), sD = ewma(x => (zhr(x) + zsp(x) + zrr(x) + zco(x)) / 2);
      const thC = calib(sC), thD = calib(sD);
      const over = {
        A: X.map(x => x.hr > 100 || x.hr < 50 || x.spo2 < 94 || x.rr > 20),
        B: X.map(x => zhr(x) > 3),
        C: sC.map(v => v > thC),
        D: sD.map(v => v > thD)
      };
      if (anomalous) byType[type].n++;
      names.forEach(n => {
        const o = over[n];
        let first = -1, any = false;
        for (let k = 1; k < TEST; k++) {
          const i = WARM + k;
          if (o[i] && o[i - 1]) {            // 2 pas consécutifs = 10 min
            any = true;
            if (anomalous && k >= onset && first < 0) first = k;
          }
        }
        if (anomalous) {
          if (first >= 0) { R[n].tp++; R[n].lat.push((first - onset) * A.TICK_MIN); byType[type][n]++; }
          else R[n].fn++;
        } else {
          if (any) R[n].fp++; else R[n].tn++;
        }
      });
    }
    const out = {};
    names.forEach(n => {
      const r = R[n];
      const sens = r.tp / Math.max(1, r.tp + r.fn), spec = r.tn / Math.max(1, r.tn + r.fp);
      const prec = r.tp / Math.max(1, r.tp + r.fp), f1 = prec + sens ? (2 * prec * sens) / (prec + sens) : 0;
      out[n] = { tp: r.tp, fp: r.fp, tn: r.tn, fn: r.fn, sens, spec, prec, f1, lat: r.lat.length ? A.mean(r.lat) : NaN };
    });
    return { N, seed, metrics: out, byType };
  };
})();
