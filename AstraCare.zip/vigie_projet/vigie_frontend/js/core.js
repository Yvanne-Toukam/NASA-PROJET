/* ASTRA-MED — utilitaires, statistiques, Isolation Forest (aucune dépendance) */
(function () {
  'use strict';
  const A = (window.ASTRA = window.ASTRA || {});

  A.TICK_MIN = 5;          // 1 pas de simulation = 5 minutes simulées
  A.DAY_TICKS = 288;       // 24 h

  A.makeRng = function (seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  A.gauss = function (rng) {
    let u = 0, v = 0;
    while (u === 0) u = rng();
    while (v === 0) v = rng();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };

  A.clamp = (x, a, b) => Math.min(b, Math.max(a, x));
  A.pad = n => String(n).padStart(2, '0');
  A.mean = arr => (arr.length ? arr.reduce((s, x) => s + x, 0) / arr.length : NaN);
  A.sd = arr => {
    if (arr.length < 2) return 0;
    const m = A.mean(arr);
    return Math.sqrt(arr.reduce((s, x) => s + (x - m) * (x - m), 0) / (arr.length - 1));
  };
  A.median = arr => {
    if (!arr.length) return NaN;
    const s = arr.slice().sort((a, b) => a - b);
    const m = s.length >> 1;
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  };
  A.mad = (arr, med) => {
    if (med === undefined) med = A.median(arr);
    return A.median(arr.map(x => Math.abs(x - med))) * 1.4826;
  };
  A.quantile = (arr, q) => {
    if (!arr.length) return NaN;
    const s = arr.slice().sort((a, b) => a - b);
    return s[Math.min(s.length - 1, Math.floor(q * s.length))];
  };
  A.fmt = (x, d) => (isFinite(x) ? Number(x).toFixed(d || 0).replace('.', ',') : '—');
  A.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // Horloge de mission simulée : le pas 0 correspond à J1 08:00
  const OFFSET = 96;
  A.OFFSET = OFFSET;
  A.clock = t => {
    const tt = t + OFFSET;
    const day = Math.floor(tt / A.DAY_TICKS) + 1;
    const mins = (((tt % A.DAY_TICKS) + A.DAY_TICKS) % A.DAY_TICKS) * A.TICK_MIN;
    return { day, hh: Math.floor(mins / 60), mm: mins % 60, tod: mins / 60 };
  };
  A.fmtTime = t => { const c = A.clock(t); return 'J' + c.day + ' ' + A.pad(c.hh) + ':' + A.pad(c.mm); };
  A.fmtDur = min => {
    min = Math.round(min);
    if (min < 60) return min + ' min';
    const h = Math.floor(min / 60), m = min % 60;
    if (h < 48) return h + ' h' + (m ? ' ' + A.pad(m) : '');
    return Math.floor(h / 24) + ' j ' + (h % 24) + ' h';
  };

  // Hachage non cryptographique (cyrb53) — démonstration du chaînage du journal d'audit
  A.hash = function (str) {
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, '0');
  };

  // Isolation Forest (Liu, Ting, Zhou — 2008) : implémentation compacte
  A.IsoForest = function (data, rng, nTrees, sub) {
    nTrees = nTrees || 60; sub = sub || 128;
    const n = data.length, d = data[0].length;
    const psi = Math.min(sub, n);
    const maxDepth = Math.ceil(Math.log2(psi));
    const trees = [];
    function build(rows, depth) {
      if (depth >= maxDepth || rows.length <= 1) return { size: rows.length };
      const q = Math.floor(rng() * d);
      let lo = Infinity, hi = -Infinity;
      for (const r of rows) { if (r[q] < lo) lo = r[q]; if (r[q] > hi) hi = r[q]; }
      if (lo === hi) return { size: rows.length };
      // variante « plage élargie » : les points hors de la plage d'apprentissage sont isolés plus tôt
      const m = 0.5 * (hi - lo);
      const p = lo - m + rng() * (hi - lo + 2 * m);
      const L = [], R = [];
      for (const r of rows) (r[q] < p ? L : R).push(r);
      return { q, p, l: build(L, depth + 1), r: build(R, depth + 1) };
    }
    for (let i = 0; i < nTrees; i++) {
      const rows = [];
      for (let j = 0; j < psi; j++) rows.push(data[Math.floor(rng() * n)]);
      trees.push(build(rows, 0));
    }
    const cfn = m => (m <= 1 ? 0 : m === 2 ? 1 : 2 * (Math.log(m - 1) + 0.5772156649) - (2 * (m - 1)) / m);
    const c = cfn(psi);
    function path(x, node, depth) {
      if (node.size !== undefined) return depth + cfn(node.size);
      return path(x, x[node.q] < node.p ? node.l : node.r, depth + 1);
    }
    this.score = function (x) {
      let s = 0;
      for (const t of trees) s += path(x, t, 0);
      s /= trees.length;
      return Math.pow(2, -s / c);
    };
  };
})();
