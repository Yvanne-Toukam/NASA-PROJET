/* ASTRA-MED — simulation embarquée : équipage, environnement, contrôle qualité,
   ligne de base, détection (règles + Isolation Forest), alertes, liaison Terre, audit. */
(function () {
  'use strict';
  const A = window.ASTRA;
  const DAY = A.DAY_TICKS, WARM = 2 * DAY, CAP = 5200, K = 3;
  const RECS = 6 * 7 + 3 * 5;            // enregistrements générés par pas (6 astronautes x 7 + 3 modules x 5)
  const LINK_STEP = 400;                 // enregistrements envoyés toutes les 200 ms en rattrapage (= 2000 / s)

  A.VITALS = ['hr', 'spo2', 'rr', 'temp', 'sys'];
  A.PARAMS = {
    hr:   { label: 'Fréquence cardiaque', short: 'FC', unit: 'bpm', min: 25, max: 220, dec: 0, floor: 2.0 },
    spo2: { label: 'Saturation en O₂', short: 'SpO₂', unit: '%', min: 60, max: 100, dec: 1, floor: 0.5 },
    rr:   { label: 'Fréquence respiratoire', short: 'FR', unit: '/min', min: 4, max: 60, dec: 0, floor: 0.8 },
    temp: { label: 'Température', short: 'T°', unit: '°C', min: 33, max: 42, dec: 1, floor: 0.12 },
    sys:  { label: 'Pression systolique', short: 'PA', unit: 'mmHg', min: 60, max: 240, dec: 0, floor: 3 },
    ecg:  { label: 'Irrégularité ECG (indice)', short: 'ECG', unit: '', min: 0, max: 1, dec: 2 },
    act:  { label: 'Activité', short: 'Act.', unit: '%', min: 0, max: 100, dec: 0 }
  };
  A.ENVP = {
    co2:   { label: 'CO₂', unit: 'ppm', dec: 0 },
    temp:  { label: 'Température', unit: '°C', dec: 1 },
    hum:   { label: 'Humidité', unit: '%', dec: 0 },
    noise: { label: 'Bruit', unit: 'dB', dec: 0 },
    rad:   { label: 'Rayonnements', unit: 'µSv/h', dec: 1 }
  };
  A.LEVELS = {
    technical: { label: 'Technique', rank: 0 },
    vigilance: { label: 'Vigilance', rank: 1 },
    medical: { label: 'Médicale', rank: 2 },
    emergency: { label: 'Urgence potentielle', rank: 3 }
  };
  A.SCENARIOS = {
    S1: { label: 'S1 · État normal (réinitialiser)', desc: 'Annule toutes les injections' },
    S2: { label: 'S2 · Fatigue progressive', desc: 'Sommeil dégradé 3 nuits, dérive FC/SpO₂/FR, fatigue déclarée' },
    S3: { label: 'S3 · Anomalie cardiaque', desc: 'FC élevée + ECG irrégulier' },
    S4: { label: 'S4 · Dégradation respiratoire', desc: 'Baisse de SpO₂ + FR élevée' },
    S5: { label: 'S5 · Environnement dégradé', desc: 'CO₂ et température en hausse dans le module + symptômes' },
    S6: { label: 'S6 · Panne de capteur (SpO₂)', desc: 'Plus de signal : alerte technique, pas d’alerte médicale' },
    S7: { label: 'S7 · Perte de communication', desc: 'Bascule la liaison Terre (coupure / reprise)' },
    S8: { label: 'S8 · Fausse donnée (FC aberrante)', desc: 'Valeur impossible : rejet en quarantaine' }
  };

  const CREWDEF = [
    { code: 'AST-01', name: 'Orion',  role: 'Commandant',          module: 0, hr: 58, spo2: 97.6, rr: 13, temp: 36.6, sys: 114, sleep: 7.2 },
    { code: 'AST-02', name: 'Lyra',   role: 'Ingénieure de vol',   module: 2, hr: 66, spo2: 98.0, rr: 14, temp: 36.7, sys: 108, sleep: 7.0 },
    { code: 'AST-03', name: 'Vega',   role: 'Médecin de bord',     module: 0, hr: 62, spo2: 97.8, rr: 14, temp: 36.5, sys: 112, sleep: 7.4 },
    { code: 'AST-04', name: 'Altaïr', role: 'Spécialiste mission', module: 1, hr: 74, spo2: 97.2, rr: 15, temp: 36.8, sys: 120, sleep: 6.9 },
    { code: 'AST-05', name: 'Sirius', role: 'Pilote',              module: 2, hr: 54, spo2: 98.2, rr: 12, temp: 36.4, sys: 110, sleep: 7.5 },
    { code: 'AST-06', name: 'Rigel',  role: 'Scientifique',        module: 1, hr: 80, spo2: 97.0, rr: 16, temp: 36.9, sys: 124, sleep: 6.8 }
  ];
  const MODS = [
    { name: 'Module vie',        co2: 720, temp: 22.4, hum: 45, noise: 46, rad: 7.0 },
    { name: 'Laboratoire',       co2: 680, temp: 23.1, hum: 42, noise: 52, rad: 7.4 },
    { name: 'Poste de pilotage', co2: 700, temp: 22.0, hum: 44, noise: 49, rad: 8.1 }
  ];
  A.MODULES = MODS.map(m => m.name);

  const S = (A.state = {
    t: 0, ready: false, running: true, speed: 1, silent: false,
    crew: [], env: { t: [], mods: [] },
    alerts: [], active: {}, alertSeq: 1, alertVersion: 0, trig: new Set(), suppress: {},
    reports: [], meds: [], latencies: [], marks: {}, qcRejected: 0,
    audit: [], auditTampered: false,
    comm: { online: true, catchup: false, queue: 0, generated: 0, received: 0, log: [], flushStartReal: 0, flushStartQueue: 0, lastDuration: null, outages: 0 }
  });
  A.hooks = { toast: null };
  A.notify = (msg, level) => { if (!S.silent && A.hooks.toast) A.hooks.toast(msg, level || 'info'); };

  /* ---------- Utilisateurs et sécurité ---------- */
  A.users = [
    { username: 'medecin',    password: 'astra2026',  role: 'flight_surgeon', name: 'Dr Camille Laurent (médecin de bord)', mfa: true,  active: true },
    { username: 'astronaute', password: 'orbit2026',  role: 'astronaut',      name: 'Orion (AST-01)', mfa: false, active: true, astronautId: 0 },
    { username: 'terre',      password: 'ground2026', role: 'ground_center',  name: 'Centre médical terrestre', mfa: false, active: true },
    { username: 'admin',      password: 'admin2026',  role: 'admin',          name: 'Administrateur système', mfa: true,  active: true }
  ];
  A.ROLE_LABEL = { astronaut: 'Astronaute', flight_surgeon: 'Médecin de bord', ground_center: 'Centre terrestre', admin: 'Administrateur' };
  A.MFA_CODE = '123456';
  const fails = {};
  A.login = function (username, password) {
    const key = (username || '').toLowerCase();
    const f = fails[key] || (fails[key] = { n: 0, until: 0 });
    if (Date.now() < f.until) return { ok: false, error: 'Compte verrouillé temporairement (' + Math.ceil((f.until - Date.now()) / 1000) + ' s).' };
    const u = A.users.find(x => x.username === key);
    if (!u || u.password !== password) {
      f.n++;
      A.auditLog('LOGIN_ECHEC', key, 'tentative ' + f.n, { actor: key });
      if (f.n >= 5) { f.until = Date.now() + 30000; f.n = 0; A.auditLog('COMPTE_VERROUILLE', key, '30 s', { actor: key }); return { ok: false, error: 'Trop d’échecs : compte verrouillé 30 s.' }; }
      return { ok: false, error: 'Identifiant ou mot de passe incorrect.' };
    }
    if (!u.active) return { ok: false, error: 'Compte désactivé par l’administrateur.' };
    f.n = 0;
    return { ok: true, user: u, needMfa: u.mfa };
  };

  /* ---------- Journal d'audit chaîné ---------- */
  A.currentUser = null;
  A.auditLog = function (action, target, details, opt) {
    const prev = S.audit.length ? S.audit[S.audit.length - 1].hash : '0';
    const actor = (opt && opt.actor) || (A.currentUser ? A.currentUser.username : 'système');
    const e = { i: S.audit.length + 1, real: new Date().toISOString(), tick: S.t, actor, action, target: target || '', details: details || '', prev };
    e.hash = A.hash([prev, e.i, e.real, e.actor, e.action, e.target, e.details].join('|'));
    S.audit.push(e);
    return e;
  };
  A.verifyAudit = function () {
    let prev = '0';
    for (const e of S.audit) {
      const h = A.hash([prev, e.i, e.real, e.actor, e.action, e.target, e.details].join('|'));
      if (e.prev !== prev || e.hash !== h) return { ok: false, brokenAt: e.i, total: S.audit.length };
      prev = e.hash;
    }
    return { ok: true, total: S.audit.length };
  };
  A.tamperAudit = function () {
    if (S.audit.length < 3) return false;
    const e = S.audit[Math.floor(S.audit.length / 2)];
    e.details = (e.details || '') + ' [modifié]';
    S.auditTampered = true;
    return e.i;
  };

  /* ---------- Initialisation ---------- */
  function mkCrew() {
    S.crew = CREWDEF.map((d, i) => ({
      id: i, code: d.code, name: d.name, role: d.role, module: d.module,
      base: { hr: d.hr, spo2: d.spo2, rr: d.rr, temp: d.temp, sys: d.sys }, sleep: d.sleep,
      hist: { t: [], hr: [], spo2: [], rr: [], temp: [], sys: [], ecg: [], act: [], st: [], fl: [] },
      inj: { cur: { hr: 0, spo2: 0, rr: 0, temp: 0, sys: 0, ecg: 0 }, tgt: { hr: 0, spo2: 0, rr: 0, temp: 0, sys: 0, ecg: 0 }, faults: {}, glitch: null, sleepDelta: 0 },
      missing: { hr: 0, spo2: 0, rr: 0, temp: 0, sys: 0 },
      sleepHist: [], baseline: null, forest: null, fmu: null, fsd: null, ifThr: 0.6, trainedAt: -1,
      streak: { R01: 0, R02: 0, ML: 0 }, symptomTick: -9999, quarantine: [], last: {}, lastSt: 1, lastScore: 0,
      rng: A.makeRng(100 + i)
    }));
    S.crew.forEach(a => {
      const r = A.makeRng(900 + a.id);
      for (let k = 5; k >= 1; k--) a.sleepHist.push({ t: -k * DAY + 84, h: a.sleep + A.gauss(r) * 0.3 });
    });
    S.env.mods = MODS.map((m, i) => ({
      name: m.name, base: m, rng: A.makeRng(500 + i),
      cur: { co2: 0, temp: 0, rad: 0 }, tgt: { co2: 0, temp: 0, rad: 0 },
      val: { co2: m.co2, temp: m.temp, hum: m.hum, noise: m.noise, rad: m.rad },
      hist: { co2: [], temp: [], hum: [], noise: [], rad: [] }
    }));
  }

  A.init = function () {
    mkCrew();
    S.silent = true;
    S.t = 0;
    for (let i = 0; i < WARM; i++) A.step();
    S.crew.forEach(a => { computeBaseline(a); trainForest(a); });
    S.silent = false;
    S.alerts.length = 0; S.active = {}; S.alertVersion++; S.qcRejected = 0;
    S.comm.generated = 0; S.comm.received = 0; S.comm.queue = 0; S.comm.log = [];
    S.audit.length = 0;
    A.auditLog('SYSTEME_DEMARRE', 'ASTRA-MED', 'ligne de base initiale calculée (2 jours simulés)', { actor: 'système' });
    S.ready = true;
  };

  /* ---------- Ligne de base individuelle (médiane + MAD) ---------- */
  function computeBaseline(a) {
    const H = a.hist, n = H.t.length, start = Math.max(0, n - 2 * DAY);
    const out = { 0: {}, 1: {} };
    for (const st of [0, 1]) {
      for (const p of A.VITALS) {
        const vals = [];
        for (let i = start; i < n; i++) if (H.st[i] === st && !H.fl[i] && isFinite(H[p][i])) vals.push(H[p][i]);
        if (vals.length < 20) { out[st][p] = null; continue; }
        const c = A.median(vals);
        out[st][p] = { c, s: Math.max(A.mad(vals, c), A.PARAMS[p].floor), n: vals.length };
      }
    }
    if (out[0].hr && out[1].hr) a.baseline = out;
  }
  A.recomputeBaseline = computeBaseline;

  /* ---------- Isolation Forest sur les écarts normalisés à la ligne de base ---------- */
  // Vecteur = écarts (en σ robustes) de FC, SpO2, FR, T°, PA à la ligne de base de l'état courant
  // (sommeil / éveil au repos) + indice ECG. L'effort physique est exclu de ce moteur (état 2).
  const FEATS = ['hr', 'spo2', 'rr', 'temp', 'sys', 'ecg'];
  function zVec(a, v, st, ecgMu, ecgSd) {
    const B = a.baseline && a.baseline[st];
    if (!B) return null;
    const z = [];
    for (const p of A.VITALS) {
      if (!B[p] || !isFinite(v[p])) return null;
      z.push(A.clamp((v[p] - B[p].c) / B[p].s, -40, 40));
    }
    if (!isFinite(v.ecg)) return null;
    z.push(A.clamp((v.ecg - ecgMu) / ecgSd, -40, 40));
    return z;
  }
  function trainForest(a) {
    if (!a.baseline) return;
    const H = a.hist, n = H.t.length, start = Math.max(0, n - 2 * DAY);
    const es = [];
    for (let i = start; i < n; i++) if (!H.fl[i] && H.st[i] !== 2) es.push(H.ecg[i]);
    if (es.length < 200) return;
    const ecgMu = A.mean(es), ecgSd = Math.max(A.sd(es), 0.01);
    const rows = [];
    for (let i = start; i < n; i++) {
      if (H.fl[i] || H.st[i] === 2) continue;
      const v = { ecg: H.ecg[i] };
      for (const p of A.VITALS) v[p] = H[p][i];
      const z = zVec(a, v, H.st[i], ecgMu, ecgSd);
      if (z) rows.push(z);
    }
    if (rows.length < 200) return;
    const rng = A.makeRng(1000 + a.id * 7 + Math.floor(S.t / DAY));
    const forest = new A.IsoForest(rows, rng, 100, 128);
    const scores = rows.map(z => forest.score(z));
    a.forest = forest; a.ecgMu = ecgMu; a.ecgSd = ecgSd;
    a.ifThr = Math.max(0.55, A.quantile(scores, 0.995) + 0.02);
    a.trainedAt = S.t;
  }

  /* ---------- Alertes ---------- */
  function conf(x) { return Math.min(0.97, Math.max(0.3, x)); }
  function activeFor(a) {
    for (const k in S.active) { const al = S.active[k]; if (al.astronautId === a.id && al.level !== 'technical') return true; }
    return false;
  }
  function related(a, exclude) {
    const out = [];
    const B = a.baseline && a.baseline[a.lastSt === 0 ? 0 : 1];
    if (B) for (const p of A.VITALS) {
      if (p === exclude || !B[p] || !isFinite(a.last[p])) continue;
      const z = (a.last[p] - B[p].c) / B[p].s;
      if (Math.abs(z) > 2.5) {
        const pct = (a.last[p] - B[p].c) / B[p].c * 100;
        out.push(A.PARAMS[p].short + ' ' + (pct >= 0 ? '+' : '−') + Math.abs(pct).toFixed(p === 'spo2' ? 1 : 0) + ' %');
      }
    }
    const r = lastReport(a.id);
    if (r && S.t - r.tick <= DAY && r.fatigue >= 7) out.push('fatigue déclarée élevée (' + r.fatigue + '/10)');
    const sh = a.sleepHist.slice(-3);
    if (sh.length === 3) { const m = A.mean(sh.map(x => x.h)); if (m < 6) out.push('sommeil réduit (' + A.fmt(m, 1) + ' h en moyenne sur 3 nuits)'); }
    const co2 = S.env.mods[a.module].val.co2;
    if (co2 > 1500) out.push('CO₂ élevé (' + Math.round(co2) + ' ppm)');
    return out;
  }
  function lastReport(id) {
    for (let i = S.reports.length - 1; i >= 0; i--) if (S.reports[i].astronautId === id) return S.reports[i];
    return null;
  }
  function summarize(al) {
    const L = A.LEVELS[al.level].label;
    let s = L + ' — ' + al.headline + ' depuis ' + A.fmtDur(al.durationTicks * A.TICK_MIN) + '.';
    if (al.related && al.related.length) s += ' Éléments associés : ' + al.related.join(' ; ') + '.';
    s += ' Niveau de confiance : ' + Math.round(al.confidence * 100) + ' %. Recommandation : ' + al.action + '.';
    return s;
  }
  function raise(key, spec) {
    const t = S.t;
    S.trig.add(key);
    let al = S.active[key];
    if (al) {
      al.durationTicks = t - al.createdTick + 1;
      al.measured = spec.measured; al.baseline = spec.baseline; al.headline = spec.headline;
      al.confidence = spec.confidence; al.clear = 0;
      al.related = spec.related || al.related;
      if (A.LEVELS[spec.level].rank > A.LEVELS[al.level].rank) {
        al.level = spec.level;
        A.auditLog('ALERTE_ESCALADE_AUTO', '#' + al.id, spec.rule + ' → ' + spec.level, { actor: 'système' });
        A.notify('Alerte #' + al.id + ' relevée au niveau ' + A.LEVELS[al.level].label, 'medical');
      }
      al.summary = summarize(al);
      return al;
    }
    if (S.suppress[key] && S.suppress[key] > t) return null;
    const a = spec.astronautId != null ? S.crew[spec.astronautId] : null;
    al = Object.assign({ id: S.alertSeq++, key, createdTick: t, createdReal: Date.now(), status: 'open', notes: [], clear: 0, durationTicks: 1 }, spec);
    if (!al.related) al.related = a ? related(a, spec.param) : [];
    al.paramLabel = spec.param && A.PARAMS[spec.param] ? A.PARAMS[spec.param].label : (spec.paramLabel || '');
    al.unit = spec.param && A.PARAMS[spec.param] ? A.PARAMS[spec.param].unit : (spec.unit || '');
    al.dec = spec.param && A.PARAMS[spec.param] ? A.PARAMS[spec.param].dec : (spec.dec || 0);
    al.summary = summarize(al);
    S.alerts.unshift(al);
    if (S.alerts.length > 600) S.alerts.length = 600;
    S.active[key] = al;
    S.alertVersion++;
    const who = a ? a.name : (spec.module || '');
    A.auditLog('ALERTE_CREEE', '#' + al.id, spec.rule + ' · ' + A.LEVELS[al.level].label + ' · ' + who, { actor: 'système' });
    A.notify('Alerte ' + A.LEVELS[al.level].label.toLowerCase() + ' · ' + who + ' · ' + spec.rule, al.level);
    const mk = a && S.marks[a.id];
    if (mk && mk.first == null && t >= mk.t) {
      mk.first = t - mk.t;
      S.latencies.push({ scenario: mk.id, astronaut: a.name, minutes: mk.first * A.TICK_MIN, rule: spec.rule, level: al.level });
    }
    return al;
  }

  /* ---------- Détection par astronaute ---------- */
  function detectAstro(a, t, v, st) {
    const B = a.baseline && a.baseline[st];
    const id = a.id, str = a.streak;
    if (B && st !== 2) {
      // R01 — FC au repos hors plage personnelle (≥ 2 pas consécutifs = 10 min)
      if (isFinite(v.hr) && B.hr) {
        const b = B.hr, dev = v.hr - b.c, pct = dev / b.c * 100;
        const out = Math.abs(dev) > K * b.s && Math.abs(pct) >= 8;
        str.R01 = out ? str.R01 + 1 : 0;
        if (str.R01 >= 2) raise('R01:' + id, {
          level: 'vigilance', rule: 'R01', astronautId: id, param: 'hr', measured: v.hr, baseline: b.c,
          headline: 'Fréquence cardiaque ' + A.fmt(v.hr) + ' bpm, ' + (dev > 0 ? 'supérieure' : 'inférieure') + ' de ' + Math.abs(pct).toFixed(0) + ' % à la ligne de base personnelle (' + A.fmt(b.c) + ' bpm)',
          action: 'contrôle et surveillance de la fréquence cardiaque', confidence: conf(0.55 + 0.06 * (Math.abs(dev) / b.s - K) + 0.03 * str.R01)
        });
      }
      // R02 — baisse de SpO2 associée à une FR élevée (+ seuil de sécurité absolu SpO2 < 90 %)
      if (isFinite(v.spo2) && B.spo2 && B.rr) {
        const b1 = B.spo2, b2 = B.rr;
        const low = v.spo2 < b1.c - Math.max(K * b1.s, 2);
        const hi = isFinite(v.rr) && v.rr > b2.c + Math.max(K * b2.s, 3);
        const crit = v.spo2 < 90;
        str.R02 = (low && (hi || crit)) ? str.R02 + 1 : 0;
        if (str.R02 >= 2) raise('R02:' + id, {
          level: 'medical', rule: 'R02', astronautId: id, param: 'spo2', measured: v.spo2, baseline: b1.c,
          headline: 'Baisse de SpO₂ (' + A.fmt(v.spo2, 1) + ' %, référence ' + A.fmt(b1.c, 1) + ' %)' + (hi ? ' associée à une fréquence respiratoire élevée (' + A.fmt(v.rr) + '/min)' : ' sous le seuil de sécurité de 90 %'),
          action: 'examen respiratoire et vérification de l’atmosphère', confidence: conf(0.65 + 0.03 * str.R02)
        });
      }
    }
    // R03 — sommeil insuffisant 3 nuits consécutives
    const sh = a.sleepHist.slice(-3);
    if (sh.length === 3 && sh.every(x => x.h < 6.0)) {
      const m = A.mean(sh.map(x => x.h));
      raise('R03:' + id, {
        level: 'vigilance', rule: 'R03', astronautId: id, param: null, paramLabel: 'Sommeil', unit: 'h', dec: 1, measured: m, baseline: a.sleep,
        headline: 'Sommeil insuffisant sur 3 nuits consécutives (' + A.fmt(m, 1) + ' h en moyenne, référence ' + A.fmt(a.sleep, 1) + ' h)',
        action: 'ajustement du planning et période de récupération', confidence: conf(0.6 + (6 - m) * 0.1)
      });
    }
    // R04 — CO2 élevé et symptômes déclarés
    const mod = S.env.mods[a.module];
    if (mod.val.co2 > 2500 && t - a.symptomTick <= 36) {
      raise('R04:' + id, {
        level: 'medical', rule: 'R04', astronautId: id, param: null, paramLabel: 'CO₂ + symptômes', unit: 'ppm', dec: 0, measured: mod.val.co2, baseline: mod.base.co2,
        headline: 'CO₂ à ' + Math.round(mod.val.co2) + ' ppm dans « ' + mod.name + ' » avec symptômes déclarés',
        action: 'vérification environnementale (ventilation, épuration du CO₂) et évaluation médicale', confidence: conf(0.7 + (mod.val.co2 - 2500) / 10000)
      });
    }
    // R05 — perte de capteur vital (≥ 2 pas sans signal = 10 min)
    for (const p of A.VITALS) {
      if (a.missing[p] >= 2) raise('R05:' + id + ':' + p, {
        level: 'technical', rule: 'R05', astronautId: id, param: p, measured: NaN, baseline: NaN,
        headline: 'Capteur ' + A.PARAMS[p].short + ' sans signal (aucune alerte médicale générée pour ce paramètre)',
        action: 'maintenance du capteur et surveillance alternative', confidence: 0.95, related: []
      });
    }
    // Moteur d'anomalies multivarié (Isolation Forest)
    if (a.forest && st !== 2) {
      const z = zVec(a, v, st, a.ecgMu, a.ecgSd);
      if (z) {
        const score = a.forest.score(z);
        a.lastScore = score;
        str.ML = score > a.ifThr ? str.ML + 1 : 0;
        if (str.ML >= 2) {
          const top = [];
          z.forEach((zz, j) => { if (Math.abs(zz) > 3) top.push(A.PARAMS[FEATS[j]].short + ' ' + A.fmt(v[FEATS[j]], A.PARAMS[FEATS[j]].dec) + ' ' + A.PARAMS[FEATS[j]].unit + ' (écart ' + (zz > 0 ? '+' : '−') + Math.abs(zz).toFixed(1) + ' σ)'); });
          raise('ML:' + id, {
            level: score >= a.ifThr + 0.08 ? 'medical' : 'vigilance', rule: 'ML', astronautId: id, param: null, paramLabel: 'Profil multi-paramètres', unit: '', dec: 2, measured: score, baseline: a.ifThr,
            headline: 'Profil physiologique atypique (score d’anomalie ' + score.toFixed(2) + ', seuil ' + a.ifThr.toFixed(2) + ')',
            action: 'évaluation clinique et vérification des paramètres concernés', confidence: conf(0.55 + (score - a.ifThr) * 2),
            related: top
          });
        }
      }
    }
    // R06 — combinaison d'anomalies médicales
    const meds = Object.values(S.active).filter(x => x.astronautId === id && x.level === 'medical' && x.rule !== 'R06');
    if (meds.length >= 2) {
      raise('R06:' + id, {
        level: 'emergency', rule: 'R06', astronautId: id, param: null, paramLabel: 'Combinaison d’anomalies', unit: 'anomalie(s)', dec: 0, measured: meds.length, baseline: 0,
        headline: meds.length + ' anomalies de niveau médical simultanées (' + meds.map(x => x.rule).join(' + ') + ')',
        action: 'protocole médical d’urgence et notification immédiate du centre terrestre', confidence: 0.9, related: meds.map(x => x.rule + ' : ' + x.headline)
      });
    }
  }

  function detectEnv(t) {
    S.env.mods.forEach((m, i) => {
      const v = m.val;
      if (v.co2 > 2500) raise('ENV:' + i + ':co2', { level: 'vigilance', rule: 'ENV1', astronautId: null, module: m.name, param: null, paramLabel: 'CO₂', unit: 'ppm', dec: 0, measured: v.co2, baseline: m.base.co2, headline: 'CO₂ élevé dans « ' + m.name + ' » (' + Math.round(v.co2) + ' ppm)', action: 'vérifier la ventilation et l’épuration du CO₂', confidence: 0.9, related: [] });
      if (v.temp > 29) raise('ENV:' + i + ':temp', { level: 'vigilance', rule: 'ENV1', astronautId: null, module: m.name, param: null, paramLabel: 'Température', unit: '°C', dec: 1, measured: v.temp, baseline: m.base.temp, headline: 'Température élevée dans « ' + m.name + ' » (' + A.fmt(v.temp, 1) + ' °C)', action: 'contrôler le circuit thermique', confidence: 0.9, related: [] });
      if (v.rad > 25) raise('ENV:' + i + ':rad', { level: 'vigilance', rule: 'ENV1', astronautId: null, module: m.name, param: null, paramLabel: 'Rayonnements', unit: 'µSv/h', dec: 1, measured: v.rad, baseline: m.base.rad, headline: 'Débit de dose élevé dans « ' + m.name + ' » (' + A.fmt(v.rad, 1) + ' µSv/h)', action: 'rejoindre une zone protégée', confidence: 0.9, related: [] });
    });
  }

  /* ---------- Pas de simulation ---------- */
  function stepEnv(t) {
    const tod = A.clock(t).tod;
    S.env.t.push(t);
    S.env.mods.forEach(m => {
      for (const k in m.cur) m.cur[k] += (m.tgt[k] - m.cur[k]) * 0.06;
      const g = () => A.gauss(m.rng), b = m.base;
      m.val = {
        co2: b.co2 + m.cur.co2 + 80 * Math.sin((tod - 6) / 24 * 2 * Math.PI) + g() * 25,
        temp: b.temp + m.cur.temp + 0.4 * Math.sin((tod - 15) / 24 * 2 * Math.PI) + g() * 0.1,
        hum: b.hum + g() * 1.2, noise: b.noise + g() * 1.5, rad: Math.max(0, b.rad + m.cur.rad + g() * 0.5)
      };
      for (const k in m.hist) m.hist[k].push(m.val[k]);
    });
  }

  function stepAstro(a, t) {
    const rng = a.rng, g = () => A.gauss(rng), inj = a.inj, b = a.base;
    for (const k in inj.cur) inj.cur[k] += (inj.tgt[k] - inj.cur[k]) * 0.12;
    const tod = A.clock(t).tod;
    const sleeping = tod >= 23 || tod < 6.5;
    const exStart = 9 + (a.id % 4);
    const ex = !sleeping && tod >= exStart && tod < exStart + 1;
    const act = sleeping ? 3 + rng() * 4 : ex ? 80 + rng() * 10 : 15 + rng() * 30;
    const st = sleeping ? 0 : act >= 35 ? 2 : 1;
    const circ = 2.2 * Math.sin((tod - 8) / 24 * 2 * Math.PI);
    const raw = {
      hr: b.hr + circ + (sleeping ? -8 : 0) + (ex ? 38 : act * 0.08) + inj.cur.hr + g() * 2.0,
      spo2: Math.min(100, b.spo2 + (ex ? -0.4 : 0) + inj.cur.spo2 + g() * 0.4),
      rr: b.rr + (sleeping ? -2 : 0) + (ex ? 9 : 0) + inj.cur.rr + g() * 0.8,
      temp: b.temp + 0.25 * Math.sin((tod - 16) / 24 * 2 * Math.PI) + (ex ? 0.4 : 0) + inj.cur.temp + g() * 0.08,
      sys: b.sys + (sleeping ? -8 : 0) + (ex ? 18 : 0) + inj.cur.sys + g() * 3
    };
    const v = {};
    for (const p of A.VITALS) {
      let x = raw[p];
      if (inj.faults[p]) x = null;
      else if (inj.glitch && inj.glitch.p === p) { x = inj.glitch.v; inj.glitch = null; }
      if (x === null) { a.missing[p]++; v[p] = NaN; continue; }
      a.missing[p] = 0;
      const P = A.PARAMS[p];
      if (!(x >= P.min && x <= P.max)) {
        a.quarantine.push({ t, p, v: x });
        if (a.quarantine.length > 200) a.quarantine.shift();
        S.qcRejected++;
        A.auditLog('DONNEE_REJETEE', a.code, P.short + ' = ' + A.fmt(x, 0) + ' (hors plage physiologique) → quarantaine', { actor: 'système' });
        A.notify(a.name + ' : valeur aberrante de ' + P.short + ' rejetée (quarantaine)', 'info');
        v[p] = NaN;
      } else v[p] = x;
    }
    v.ecg = A.clamp(0.05 + Math.abs(g()) * 0.03 + inj.cur.ecg, 0, 1);
    v.act = act;
    const H = a.hist;
    H.t.push(t); H.st.push(st); H.fl.push(activeFor(a) ? 1 : 0);
    for (const p of A.VITALS) H[p].push(v[p]);
    H.ecg.push(v.ecg); H.act.push(v.act);
    for (const p of A.VITALS) if (isFinite(v[p])) a.last[p] = v[p];
    a.last.ecg = v.ecg; a.last.act = v.act; a.lastSt = st;
    // nuit de sommeil (calculée à 07:00)
    if (A.clock(t).hh === 7 && A.clock(t).mm === 0) {
      const h = Math.max(2, a.sleep + inj.sleepDelta + g() * 0.35);
      a.sleepHist.push({ t, h });
      if (a.sleepHist.length > 40) a.sleepHist.shift();
    }
    if (t >= WARM && a.baseline) detectAstro(a, t, v, st);
    if (t >= WARM && t % DAY === 150) {   // mise à jour quotidienne de la ligne de base (si aucune alerte active)
      if (!activeFor(a)) { computeBaseline(a); trainForest(a); }
    }
    if (H.t.length > CAP + 400) for (const k in H) H[k].splice(0, 400);
  }

  A.step = function () {
    const t = S.t;
    S.trig = new Set();
    stepEnv(t);
    S.crew.forEach(a => stepAstro(a, t));
    if (t >= WARM) detectEnv(t);
    for (const k of Object.keys(S.active)) {
      const al = S.active[k];
      // pendant un effort physique, les règles de signes vitaux ne sont pas évaluées : l'alerte est maintenue
      const hold = al.astronautId != null && S.crew[al.astronautId].lastSt === 2 && (al.rule === 'R01' || al.rule === 'R02' || al.rule === 'ML' || al.rule === 'R06');
      if (!S.trig.has(k) && !hold) {
        al.clear++;
        if (al.clear >= 6) {
          al.status = 'resolved'; al.resolvedTick = t; delete S.active[k]; S.alertVersion++;
          A.auditLog('ALERTE_RESOLUE', '#' + al.id, 'condition disparue depuis 30 min', { actor: 'système' });
        }
      }
    }
    if (S.env.t.length > CAP + 400) { S.env.t.splice(0, 400); S.env.mods.forEach(m => { for (const k in m.hist) m.hist[k].splice(0, 400); }); }
    // liaison Terre
    const C = S.comm;
    C.generated += RECS;
    if (C.online && !C.catchup) C.received += RECS; else C.queue += RECS;
    S.t = t + 1;
  };

  A.advanceDay = function () {
    const before = S.silent; S.silent = true;
    for (let i = 0; i < DAY; i++) A.step();
    S.silent = before;
  };

  /* ---------- Liaison Terre ---------- */
  A.syncedTick = function () {
    const C = S.comm;
    if (C.online && !C.catchup) return S.t - 1;
    return Math.max(0, S.t - 1 - Math.floor(C.queue / RECS));
  };
  A.setLink = function (online, why) {
    const C = S.comm;
    if (C.online === online) return;
    C.online = online;
    if (!online) {
      C.outages++; C.offlineSince = S.t;
      C.log.unshift({ real: Date.now(), tick: S.t, text: 'Liaison coupée — surveillance locale maintenue, mise en file persistante des données' });
      A.auditLog('LIAISON_COUPEE', 'Terre', why || '');
    } else {
      C.catchup = true; C.flushStartReal = Date.now(); C.flushStartQueue = C.queue;
      C.log.unshift({ real: Date.now(), tick: S.t, text: 'Liaison rétablie — synchronisation différée de ' + C.queue + ' enregistrements' });
      A.auditLog('LIAISON_RETABLIE', 'Terre', 'file : ' + C.queue + ' enregistrements');
    }
    A.notify(online ? 'Liaison Terre rétablie : synchronisation en cours' : 'Liaison Terre coupée : mode autonome', online ? 'info' : 'vigilance');
  };
  A.flushStep = function () {
    const C = S.comm;
    if (!C.online || !C.catchup) return;
    const n = Math.min(C.queue, LINK_STEP);
    C.queue -= n; C.received += n;
    if (C.queue <= 0) {
      C.queue = 0; C.catchup = false;
      C.lastDuration = (Date.now() - C.flushStartReal) / 1000;
      C.log.unshift({ real: Date.now(), tick: S.t, text: 'Synchronisation terminée : ' + C.flushStartQueue + ' enregistrements en ' + A.fmt(C.lastDuration, 1) + ' s, aucune perte' });
      A.auditLog('SYNCHRO_TERMINEE', 'Terre', C.flushStartQueue + ' enr. en ' + C.lastDuration.toFixed(1) + ' s');
    }
  };
  A.lossRate = function () {
    const C = S.comm;
    return C.generated ? (C.generated - C.received - C.queue) / C.generated : 0;
  };

  /* ---------- Actions sur les alertes ---------- */
  A.ackAlert = function (id) {
    const al = S.alerts.find(x => x.id === id);
    if (!al || al.status !== 'open') return;
    al.status = 'acknowledged'; al.ackBy = A.currentUser.username; al.ackTick = S.t; S.alertVersion++;
    A.auditLog('ALERTE_ACQUITTEE', '#' + id, al.rule);
  };
  A.escalateAlert = function (id) {
    const al = S.alerts.find(x => x.id === id);
    if (!al || (al.status !== 'open' && al.status !== 'acknowledged')) return;
    al.status = 'escalated'; al.escTick = S.t; S.alertVersion++; S.comm.generated++; S.comm.queue++;
    A.auditLog('ALERTE_ESCALADEE', '#' + id, 'notification du centre terrestre (' + (S.comm.online ? 'envoyée' : 'en file, liaison coupée') + ')');
    A.notify('Alerte #' + id + ' escaladée vers le centre terrestre' + (S.comm.online ? '' : ' (en file : liaison coupée)'), 'info');
  };
  A.closeAlert = function (id) {
    const al = S.alerts.find(x => x.id === id);
    if (!al || al.status === 'closed' || al.status === 'resolved') return;
    al.status = 'closed'; al.closedTick = S.t;
    if (S.active[al.key] === al) { delete S.active[al.key]; S.suppress[al.key] = S.t + 36; }
    S.alertVersion++;
    A.auditLog('ALERTE_CLOTUREE', '#' + id, al.rule);
  };
  A.addNote = function (id, text) {
    const al = S.alerts.find(x => x.id === id);
    if (!al || !text) return;
    al.notes.push({ who: A.currentUser.username, tick: S.t, text });
    S.alertVersion++;
    A.auditLog('NOTE_AJOUTEE', '#' + id, text.slice(0, 60));
  };

  /* ---------- Auto-évaluations et médicaments ---------- */
  A.addReport = function (r) {
    r.tick = S.t;
    S.reports.push(r);
    if (r.symptoms && r.symptoms.length) S.crew[r.astronautId].symptomTick = S.t;
    A.auditLog('AUTOEVALUATION', S.crew[r.astronautId].code, 'fatigue ' + r.fatigue + ' · humeur ' + r.mood + ' · stress ' + r.stress + (r.symptoms.length ? ' · symptômes : ' + r.symptoms.join(', ') : ''), r.auto ? { actor: 'système' } : undefined);
  };
  A.addMed = function (m) { S.meds.push(m); A.auditLog('MEDICAMENT_AJOUTE', S.crew[m.astronautId].code, m.name + ' ' + m.dose); };
  A.takeMed = function (idx) { const m = S.meds[idx]; if (!m) return; m.taken.push(S.t); A.auditLog('MEDICAMENT_PRIS', S.crew[m.astronautId].code, m.name); };

  /* ---------- Scénarios d'expérimentation ---------- */
  A.scenario = function (id, astroId) {
    const a = S.crew[astroId], mod = S.env.mods[a.module], inj = a.inj;
    const mark = () => { S.marks[a.id] = { id, t: S.t, first: null }; };
    A.auditLog('SCENARIO', id, a.code + ' · ' + A.SCENARIOS[id].label);
    switch (id) {
      case 'S1':
        for (const k in inj.tgt) inj.tgt[k] = 0;
        inj.faults = {}; inj.glitch = null; inj.sleepDelta = 0;
        S.crew.forEach(c => { c.inj.sleepDelta = 0; });
        a.sleepHist.slice(-3).forEach(x => { x.h = a.sleep + A.gauss(a.rng) * 0.3; });
        S.env.mods.forEach(m => { m.tgt.co2 = 0; m.tgt.temp = 0; m.tgt.rad = 0; });
        delete S.marks[a.id];
        break;
      case 'S2':
        mark();
        inj.tgt.hr = 9; inj.tgt.spo2 = -0.6; inj.tgt.rr = 1.5; inj.sleepDelta = -2.6;
        for (let k = 0; k < 3; k++) { if (a.sleepHist[a.sleepHist.length - 1 - k]) a.sleepHist[a.sleepHist.length - 1 - k].h = 4.6 + k * 0.4; }
        A.addReport({ astronautId: a.id, fatigue: 8, mood: 4, stress: 6, symptoms: [], notes: 'Fatigue marquée (scénario S2)', auto: true });
        break;
      case 'S3': mark(); inj.tgt.hr = 42; inj.tgt.ecg = 0.65; inj.tgt.sys = 12; break;
      case 'S4': mark(); inj.tgt.spo2 = -7; inj.tgt.rr = 9; inj.tgt.temp = 0.3; break;
      case 'S5':
        mark(); mod.tgt.co2 = 3800; mod.tgt.temp = 4.5;
        A.addReport({ astronautId: a.id, fatigue: 6, mood: 5, stress: 5, symptoms: ['Maux de tête'], notes: 'Symptômes déclarés (scénario S5)', auto: true });
        break;
      case 'S6': mark(); inj.faults.spo2 = true; break;
      case 'S7': A.setLink(!S.comm.online, 'scénario S7'); break;
      case 'S8': mark(); inj.glitch = { p: 'hr', v: 300 }; break;
    }
  };

  /* ---------- Exports ---------- */
  A.seriesFor = function (astroId, param, win) {
    // retourne [{t, v}] pour les dernières 'win' mesures de l'astronaute
    const out = [];
    if (param.indexOf('env:') === 0) {
      const [, mi, p] = param.split(':');
      const m = S.env.mods[+mi], T = S.env.t, n = T.length;
      for (let i = Math.max(0, n - win); i < n; i++) out.push({ t: T[i], v: m.hist[p][i], q: 'valide' });
      return out;
    }
    const H = S.crew[astroId].hist, n = H.t.length;
    for (let i = Math.max(0, n - win); i < n; i++) {
      const x = H[param][i];
      out.push({ t: H.t[i], v: x, q: isFinite(x) ? 'valide' : 'manquante/rejetée' });
    }
    return out;
  };
})();
