/**
 * VIGIE — Client Frontend (NASA Space Apps Challenge 2026)
 * Principes stricts appliqués :
 * - P1 : L'astronaute est l'utilisateur principal ("comment je vais, ce qui change, quoi faire").
 * - P2 : Le calcul décide, le frontend n'affiche que ce que l'API renvoie.
 * - P3 : Fonctionnement 100% autonome et hors-ligne, aucun CDN, appels relatifs /api/...
 * - P4 : Explicable et auditable.
 * - P5 : Aucun diagnostic médical ni prescription.
 * - P6 : Dégradation maîtrisée (capteur muet signalé avec cohérence partout).
 */

(function () {
  "use strict";

  // État local unique de l'application
  const etatApp = {
    astronauteActif: null,
    listeAstronautes: [],
    etatCourant: null,
    seuilsConfig: null,
    moduleActif: "cardio",
    vueActive: "accueil",
    enLigne: true,
    echecsConsecutifs: 0,
    delaiReconnexionMs: 2000,
    timerPolling: null,
    timerSante: null,
    intervalleMs: 2000,
    animCanvasIds: new Map(), // Références pour les animations de courbes
  };

  // Catalogue des métadonnées de présentation (unités et libellés usuels)
  const METADONNEES = {
    pouls: { nom: "Pouls au repos", unite: "bpm" },
    hrv: { nom: "Variabilité cardiaque", unite: "ms" },
    spo2: { nom: "Saturation en O₂", unite: "%" },
    resp: { nom: "Fréquence respiratoire", unite: "/min" },
    temp_peau: { nom: "Température cutanée", unite: "°C" },
    sommeil: { nom: "Durée du sommeil", unite: "h" },
    activite: { nom: "Activité physique", unite: "min" },
    tension_sys: { nom: "Tension systolique", unite: "mmHg" },
    tension_dia: { nom: "Tension diastolique", unite: "mmHg" },
    force_main: { nom: "Force de préhension", unite: "kg" },
    debit_dose: { nom: "Débit de dose", unite: "µSv/h" },
  };

  // -------------------------------------------------------------------
  // 1. Initialisation au chargement du DOM
  // -------------------------------------------------------------------
  document.addEventListener("DOMContentLoaded", () => {
    configurerRouteurVues();
    configurerFormulaireBilan();
    configurerOngletsModules();
    configurerBoutonsScenario();
    chargerSeuilsConfig();
    chargerAstronautes();
    demarrerBoucleSante();
  });

  // -------------------------------------------------------------------
  // 2. Client API unique et centralisé (P3 : URL relative, délai, erreurs)
  // -------------------------------------------------------------------
  async function requeteApi(methode, url, donnees = null, timeoutMs = 8000) {
    const controleur = new AbortController();
    const idTimer = setTimeout(() => controleur.abort(), timeoutMs);

    const options = {
      method: methode,
      headers: {
        "Accept": "application/json",
      },
      signal: controleur.signal,
    };

    if (donnees) {
      options.headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(donnees);
    }

    try {
      const reponse = await fetch(url, options);
      clearTimeout(idTimer);

      let corpsJson = null;
      const texte = await reponse.text();
      if (texte) {
        try {
          corpsJson = JSON.parse(texte);
        } catch {
          corpsJson = null;
        }
      }

      if (!reponse.ok) {
        // Construction du message d'erreur précis à partir du champ detail du backend
        const detailErreur = (corpsJson && corpsJson.detail) ? corpsJson.detail : `Erreur HTTP ${reponse.status}`;
        const err = new Error(`Erreur ${reponse.status} : ${detailErreur}`);
        err.status = reponse.status;
        err.detail = detailErreur;
        throw err;
      }

      return corpsJson;
    } catch (err) {
      clearTimeout(idTimer);
      if (err.name === "AbortError") {
        const timeoutErr = new Error("Délai d'attente de réponse dépassé (timeout 8s).");
        timeoutErr.status = 408;
        throw timeoutErr;
      }
      throw err;
    }
  }

  function apiGet(url) {
    return requeteApi("GET", url);
  }

  function apiPost(url, donnees) {
    return requeteApi("POST", url, donnees);
  }

  // -------------------------------------------------------------------
  // 3. Gestion de l'état de connexion (Source de vérité unique)
  // -------------------------------------------------------------------
  async function verifierSanteConnexion() {
    try {
      const sante = await apiGet("/api/sante");
      // Succès réel de l'appel de santé : connexion rétablie ou confirmée
      etatApp.echecsConsecutifs = 0;
      etatApp.delaiReconnexionMs = 2000;
      mettreAJourAffichageConnexion(true);
      return sante;
    } catch (err) {
      etatApp.echecsConsecutifs++;
      // Déconnexion déclarée après 3 échecs consécutifs
      if (etatApp.echecsConsecutifs >= 3) {
        // Calcul du délai croissant avec plafond à 15 secondes
        etatApp.delaiReconnexionMs = Math.min(etatApp.delaiReconnexionMs * 1.5, 15000);
        mettreAJourAffichageConnexion(false, err.message);
      }
      return null;
    }
  }

  function mettreAJourAffichageConnexion(estConnecte, messageErreur = "") {
    etatApp.enLigne = estConnecte;
    const badge = document.getElementById("connexionBadge");
    const banniere = document.getElementById("banniereErreur");
    const msgEl = document.getElementById("messageErreur");

    if (estConnecte) {
      // Badge vert et masquage immédiat du bandeau rouge
      badge.className = "badge-connexion badge-ok";
      badge.innerHTML = '<span class="point-status">●</span> Connecté (127.0.0.1)';
      banniere.hidden = true;
    } else {
      // Badge rouge et affichage du bandeau rouge avec cause réelle
      badge.className = "badge-connexion badge-erreur";
      badge.innerHTML = '<span class="point-status">●</span> Hors-ligne';
      banniere.hidden = false;
      if (msgEl) {
        msgEl.textContent = `Connexion au serveur Vigie perdue (${messageErreur}). Tentative de reconnexion en cours...`;
      }
    }
  }

  function demarrerBoucleSante() {
    const cycle = async () => {
      await verifierSanteConnexion();
      etatApp.timerSante = setTimeout(cycle, etatApp.enLigne ? 2000 : etatApp.delaiReconnexionMs);
    };
    cycle();
  }

  // -------------------------------------------------------------------
  // 4. Routeur de vues avec fragments d'URL (#) et accessibilité clavier
  // -------------------------------------------------------------------
  const VUES_DISPONIBLES = ["accueil", "modules", "alertes", "bilan", "cabine", "demo"];

  function configurerRouteurVues() {
    // Boutons de navigation principale
    const boutons = document.querySelectorAll(".nav-btn");
    boutons.forEach((btn, index) => {
      btn.addEventListener("click", () => {
        const cible = btn.dataset.vue;
        changerVue(cible, true);
      });

      // Prise en charge de la navigation au clavier (flèches et Entrée)
      btn.addEventListener("keydown", (e) => {
        let prochainIndex = -1;
        if (e.key === "ArrowRight") {
          prochainIndex = (index + 1) % boutons.length;
        } else if (e.key === "ArrowLeft") {
          prochainIndex = (index - 1 + boutons.length) % boutons.length;
        }
        if (prochainIndex >= 0) {
          e.preventDefault();
          boutons[prochainIndex].focus();
          changerVue(boutons[prochainIndex].dataset.vue, true);
        }
      });
    });

    // Liens rapides "Examiner les courbes" depuis la vue Accueil
    document.querySelectorAll(".btn-consulter").forEach((b) => {
      b.addEventListener("click", () => {
        const mod = b.dataset.goto;
        changerVue("modules", true);
        activerOngletModule(mod);
      });
    });

    // Sélecteur d'astronaute
    const select = document.getElementById("selectAstro");
    select.addEventListener("change", (e) => {
      etatApp.astronauteActif = e.target.value;
      rafraichirEtat();
    });

    // Écouteur pour l'historique de navigation et le bouton Précédent/Suivant
    window.addEventListener("hashchange", () => {
      const fragment = window.location.hash.replace("#", "").trim();
      if (VUES_DISPONIBLES.includes(fragment)) {
        changerVue(fragment, false);
      }
    });

    // Vue initiale dérivée du fragment d'URL ou accueil par défaut
    const fragmentInitial = window.location.hash.replace("#", "").trim();
    const vueInitiale = VUES_DISPONIBLES.includes(fragmentInitial) ? fragmentInitial : "accueil";
    changerVue(vueInitiale, true);
  }

  function changerVue(nomVue, majUrl = false) {
    if (!VUES_DISPONIBLES.includes(nomVue)) nomVue = "accueil";
    etatApp.vueActive = nomVue;

    // Mise à jour de l'URL fragment
    if (majUrl && window.location.hash !== `#${nomVue}`) {
      window.location.hash = nomVue;
    }

    // Mise à jour des boutons de navigation (aria-selected et classe active)
    document.querySelectorAll(".nav-btn").forEach((b) => {
      const estActif = (b.dataset.vue === nomVue);
      b.classList.toggle("actif", estActif);
      b.setAttribute("aria-selected", estActif ? "true" : "false");
    });

    // Affichage strict d'une seule section à la fois via l'attribut hidden
    VUES_DISPONIBLES.forEach((v) => {
      const section = document.getElementById(`vue-${v}`);
      if (section) {
        section.hidden = (v !== nomVue);
      }
    });

    // Déclenchement des chargements ciblés selon la vue active
    if (nomVue === "modules") {
      afficherDetailModule();
    } else if (nomVue === "cabine") {
      chargerDonneesCabine();
    } else if (nomVue === "demo") {
      chargerSanteSysteme();
    } else if (nomVue === "alertes") {
      rafraichirAlertes();
    }
  }

  function configurerOngletsModules() {
    document.querySelectorAll(".onglet-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        activerOngletModule(btn.dataset.tab);
      });
    });
  }

  function activerOngletModule(nomModule) {
    etatApp.moduleActif = nomModule;
    document.querySelectorAll(".onglet-btn").forEach((b) => {
      const estActif = (b.dataset.tab === nomModule);
      b.classList.toggle("actif", estActif);
      b.setAttribute("aria-selected", estActif ? "true" : "false");
    });
    afficherDetailModule();
  }

  // -------------------------------------------------------------------
  // 5. Chargement des seuils depuis la configuration
  // -------------------------------------------------------------------
  async function chargerSeuilsConfig() {
    try {
      const config = await apiGet("/api/config/seuils");
      if (config) {
        etatApp.seuilsConfig = config;
        mettreAJourTextesSeuils(config);
      }
    } catch {
      // Les seuils par défaut du moteur restent valides en repli
    }
  }

  function mettreAJourTextesSeuils(cfg) {
    const inds = cfg.indicateurs || {};
    const descUrgence = document.getElementById("descScenarioUrgence");
    if (descUrgence && inds.spo2 && inds.pouls) {
      const seuilSpo2 = inds.spo2.n2 || 92;
      const seuilPouls = inds.pouls.abs_max || 120;
      descUrgence.textContent = `Détérioration critique simultanée (pouls > ${seuilPouls} bpm, SpO2 < ${seuilSpo2}%). Niveau global 2.`;
    }
  }

  // -------------------------------------------------------------------
  // 6. Chargement de l'équipage et surveillance périodique
  // -------------------------------------------------------------------
  async function chargerAstronautes() {
    try {
      const liste = await apiGet("/api/astronautes");
      if (!liste || liste.length === 0) return;

      etatApp.listeAstronautes = liste;
      const select = document.getElementById("selectAstro");
      select.innerHTML = "";

      liste.forEach((a) => {
        const opt = document.createElement("option");
        opt.value = a.id;
        opt.textContent = `${a.id} — ${a.first_name} (${a.role})`;
        select.appendChild(opt);
      });

      if (!etatApp.astronauteActif) {
        etatApp.astronauteActif = liste[0].id;
      }
      select.value = etatApp.astronauteActif;

      rafraichirEtat();
      if (etatApp.timerPolling) clearInterval(etatApp.timerPolling);
      etatApp.timerPolling = setInterval(rafraichirEtat, etatApp.intervalleMs);
    } catch (err) {
      console.warn("Chargement initial équipage en attente :", err.message);
    }
  }

  async function rafraichirEtat() {
    if (!etatApp.astronauteActif) return;
    try {
      const etat = await apiGet(`/api/etat/${etatApp.astronauteActif}`);
      if (!etat) return;

      etatApp.etatCourant = etat;
      if (etat.config_seuils) {
        etatApp.seuilsConfig = { indicateurs: etat.config_seuils };
        mettreAJourTextesSeuils({ indicateurs: etat.config_seuils });
      }

      // Horodatage strict UTC
      const hEl = document.getElementById("horodatageDernier");
      if (etat.t) hEl.textContent = `${etat.t} UTC`;

      // Rendu cohérent des vues
      mettreAJourAccueil(etat);
      if (etatApp.vueActive === "modules") afficherDetailModule();
      if (etatApp.vueActive === "alertes") afficherAlertes(etat.alertes || []);
    } catch (err) {
      console.warn("Échec rafraîchissement état :", err.message);
    }
  }

  // -------------------------------------------------------------------
  // 7. Rendu cohérent de l'écran d'accueil (P1, P6)
  // -------------------------------------------------------------------
  function mettreAJourAccueil(etat) {
    const niv = etat.niveau_global;
    const sourcesMuettes = etat.sources_muettes || [];
    const aDesSourcesMuettes = sourcesMuettes.length > 0;

    const card = document.getElementById("syntheseCard");
    const icone = document.getElementById("syntheseIcone");
    const titre = document.getElementById("syntheseTitre");
    const phrase = document.getElementById("synthesePhrase");
    const badge = document.getElementById("syntheseNiveauBadge");
    const actionEl = document.getElementById("actionConseillee");

    // Cohérence P6 : si un capteur est muet, l'état global reflète l'incertitude
    if (aDesSourcesMuettes) {
      card.className = "card card-synthese niveau-muet";
      icone.textContent = "⊘";
      titre.textContent = "Donnée incertaine : capteur muet";
      phrase.textContent = `Signal interrompu pour : ${sourcesMuettes.join(", ")}. Données physiologiques partielles.`;
      badge.className = "badge-niveau badge-muet";
      badge.textContent = "⊘ Capteur muet";
      actionEl.textContent = "Contrôler la position des capteurs corporels ou recourir aux mesures médicales manuelles.";
    } else if (niv === 0) {
      card.className = "card card-synthese niveau-0";
      icone.textContent = "✓";
      titre.textContent = "État général nominal";
      phrase.textContent = "Tous vos paramètres physiologiques sont stables et conformes à votre normale.";
      badge.className = "badge-niveau badge-niv-0";
      badge.textContent = "● Nominal";
      actionEl.textContent = "Poursuivre le programme de vol standard et la séance d'exercice prévue.";
    } else if (niv === 1) {
      card.className = "card card-synthese niveau-1";
      icone.textContent = "⚠️";
      titre.textContent = "Signaux de vigilance à surveiller";
      phrase.textContent = "Des écarts modérés ou une dérive lente par rapport à votre normale ont été identifiés.";
      badge.className = "badge-niveau badge-niv-1";
      badge.textContent = "▲ À surveiller";
      actionEl.textContent = "Hydratation recommandée, adapter l'intensité d'effort et vérifier le repos.";
    } else {
      card.className = "card card-synthese niveau-2";
      icone.textContent = "🚨";
      titre.textContent = "Alerte de niveau critique";
      phrase.textContent = "Plusieurs paramètres physiologiques nécessitent une prise en charge prioritaire.";
      badge.className = "badge-niveau badge-niv-2";
      badge.textContent = "■ Critique";
      actionEl.textContent = "Cesser immédiatement l'activité en cours et contacter le médecin de bord.";
    }

    // Mise à jour du compteur d'alertes
    const alertesActives = (etat.alertes || []).filter((a) => a.niveau > 0);
    const cptAlertes = document.getElementById("compteurAlertes");
    if (alertesActives.length > 0) {
      cptAlertes.textContent = alertesActives.length;
      cptAlertes.hidden = false;
    } else {
      cptAlertes.hidden = true;
    }

    // Rendu cohérent des 4 cartes modules de l'accueil
    const modules = etat.modules || {};
    for (const [modKey, modData] of Object.entries(modules)) {
      const badgeMod = document.getElementById(`badge-mod-${modKey}`);
      const resumeMod = document.getElementById(`resume-mod-${modKey}`);
      if (!badgeMod || !resumeMod) continue;

      const inds = modData.indicateurs || [];
      const moduleContientMuet = inds.some((i) => sourcesMuettes.includes(i.mesure));
      const modNiv = modData.niveau || 0;

      // Le badge du module signale le capteur muet si pertinent
      if (moduleContientMuet) {
        badgeMod.className = "badge-niveau badge-muet";
        badgeMod.textContent = "⊘ Capteur muet";
      } else if (modNiv === 0) {
        badgeMod.className = "badge-niveau badge-niv-0";
        badgeMod.textContent = "● Nominal";
      } else if (modNiv === 1) {
        badgeMod.className = "badge-niveau badge-niv-1";
        badgeMod.textContent = "▲ À surveiller";
      } else {
        badgeMod.className = "badge-niveau badge-niv-2";
        badgeMod.textContent = "■ Critique";
      }

      if (inds.length === 0) {
        resumeMod.textContent = "Aucune mesure récente.";
      } else {
        const lignes = inds.map((i) => {
          const meta = METADONNEES[i.mesure] || { nom: i.mesure, unite: "" };
          const estMuet = sourcesMuettes.includes(i.mesure);

          if (estMuet) {
            return `${meta.nom} : <strong>${i.valeur} ${meta.unite}</strong> <small style="color:#a855f7;">(dernière valeur valide)</small> <span class="badge-niveau badge-muet">⊘ Capteur muet</span>`;
          }
          let ligne = `${meta.nom} : <strong>${i.valeur} ${meta.unite}</strong>`;
          if (i.confiance < 0.7) {
            ligne += ' <span style="color:#f59e0b;">(donnée incertaine)</span>';
          }
          return ligne;
        });
        resumeMod.innerHTML = lignes.slice(0, 2).join("<br>");
      }
    }
  }

  // -------------------------------------------------------------------
  // 8. Rendu des détails de modules et courbes Canvas animées en continu
  // -------------------------------------------------------------------
  async function afficherDetailModule() {
    const conteneur = document.getElementById("listeIndicateursModule");
    if (!conteneur || !etatApp.etatCourant) return;

    const modKey = etatApp.moduleActif;
    const modData = (etatApp.etatCourant.modules || {})[modKey];
    if (!modData) {
      conteneur.innerHTML = "<p>Aucune donnée disponible pour ce module.</p>";
      return;
    }

    const indicateurs = modData.indicateurs || [];
    const sourcesMuettes = etatApp.etatCourant.sources_muettes || [];

    // Création ou mise à jour incrémentale pour éviter les clignotements
    conteneur.innerHTML = "";

    for (const ind of indicateurs) {
      const meta = METADONNEES[ind.mesure] || { nom: ind.mesure, unite: "" };
      const estMuet = sourcesMuettes.includes(ind.mesure);

      const carte = document.createElement("div");
      carte.className = "carte-indicateur";

      let badgeNiv = "";
      if (estMuet) {
        badgeNiv = '<span class="badge-niveau badge-muet">⊘ Capteur muet</span>';
      } else if (ind.niveau === 0) {
        badgeNiv = '<span class="badge-niveau badge-niv-0">● Nominal</span>';
      } else if (ind.niveau === 1) {
        badgeNiv = '<span class="badge-niveau badge-niv-1">▲ À surveiller</span>';
      } else {
        badgeNiv = '<span class="badge-niveau badge-niv-2">■ Critique</span>';
      }

      let ecartHtml = "";
      if (ind.ecart_pct !== null && ind.ecart_pct !== undefined) {
        const signe = ind.ecart_pct > 0 ? "+" : "";
        const cl = ind.ecart_pct > 0 ? "hausse" : "baisse";
        ecartHtml = `<span class="ind-ecart ${cl}">${signe}${ind.ecart_pct}%</span>`;
      }

      const etiquetteValeur = estMuet
        ? `<span class="ind-val-actuelle">${ind.valeur} <small style="font-size:14px;">${meta.unite}</small></span> <small style="color:#a855f7;">(dernière valeur valide)</small>`
        : `<span class="ind-val-actuelle">${ind.valeur} <small style="font-size:14px;">${meta.unite}</small></span>`;

      carte.innerHTML = `
        <div class="ind-header">
          <span class="ind-titre">${meta.nom}</span>
          ${badgeNiv}
        </div>
        <div class="ind-valeurs">
          ${etiquetteValeur}
          <span class="ind-val-ref">Réf. normale : ${ind.ref !== null ? ind.ref + " " + meta.unite : "—"}</span>
          ${ecartHtml}
        </div>
        <div class="ind-infos-ligne">
          <span>Tendance : <strong>${ind.tendance_14j}</strong></span>
          <span>Dérive CUSUM : <strong>${ind.derive ? "Oui (détectée)" : "Non"}</strong></span>
          <span>Confiance : <strong>${Math.round(ind.confiance * 100)}%</strong></span>
        </div>
        <canvas id="cv_${ind.mesure}" class="canvas-courbe"></canvas>
      `;

      conteneur.appendChild(carte);
      initialiserCourbeAnimee(`cv_${ind.mesure}`, ind.mesure, ind.ref);
    }
  }

  // Animation dynamique et tracé glissant des courbes en temps réel ("au fur et à mesure")
  async function initialiserCourbeAnimee(idCanvas, nomMesure, valeurRef) {
    const cv = document.getElementById(idCanvas);
    if (!cv || !etatApp.astronauteActif) return;

    try {
      const data = await apiGet(`/api/mesures/${etatApp.astronauteActif}?mesure=${nomMesure}&jours=14`);
      if (!data || data.length === 0) return;

      const valeurs = data.map((d) => d.valeur);
      dessinerCourbeCanvas(cv, valeurs, valeurRef);
    } catch {
      // Échec temporaire ignoré lors du polling
    }
  }

  function dessinerCourbeCanvas(cv, valeurs, valeurRef) {
    const ctx = cv.getContext("2d");
    const dpr = window.devicePixelRatio || 1;
    const w = cv.clientWidth || 300;
    const h = cv.clientHeight || 130;
    cv.width = w * dpr;
    cv.height = h * dpr;
    ctx.scale(dpr, dpr);

    let minVal = Math.min(...valeurs);
    let maxVal = Math.max(...valeurs);
    if (valeurRef !== null && valeurRef !== undefined) {
      minVal = Math.min(minVal, valeurRef);
      maxVal = Math.max(maxVal, valeurRef);
    }
    const marge = (maxVal - minVal) * 0.18 || 2.0;
    minVal -= marge;
    maxVal += marge;

    const coordY = (v) => h - 18 - ((v - minVal) / (maxVal - minVal)) * (h - 36);
    const coordX = (idx) => 24 + (idx / Math.max(valeurs.length - 1, 1)) * (w - 48);

    ctx.clearRect(0, 0, w, h);

    // Grille légère de fond
    ctx.strokeStyle = "rgba(37, 51, 82, 0.4)";
    ctx.lineWidth = 1;
    for (let gy = 20; gy < h - 10; gy += 25) {
      ctx.beginPath();
      ctx.moveTo(10, gy);
      ctx.lineTo(w - 10, gy);
      ctx.stroke();
    }

    // Ligne de référence individuelle en pointillés
    if (valeurRef !== null && valeurRef !== undefined) {
      const yRef = coordY(valeurRef);
      ctx.beginPath();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "#94a3b8";
      ctx.lineWidth = 1;
      ctx.moveTo(10, yRef);
      ctx.lineTo(w - 10, yRef);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "#94a3b8";
      ctx.font = "10px sans-serif";
      ctx.fillText(`Normale : ${valeurRef}`, 15, yRef - 4);
    }

    // Tracé de la courbe temporelle
    ctx.beginPath();
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 2;
    for (let i = 0; i < valeurs.length; i++) {
      const x = coordX(i);
      const y = coordY(valeurs[i]);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Remplissage dégradé sous la courbe
    const gradient = ctx.createLinearGradient(0, 0, 0, h);
    gradient.addColorStop(0, "rgba(56, 189, 248, 0.25)");
    gradient.addColorStop(1, "rgba(56, 189, 248, 0.0)");
    ctx.beginPath();
    for (let i = 0; i < valeurs.length; i++) {
      const x = coordX(i);
      const y = coordY(valeurs[i]);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.lineTo(coordX(valeurs.length - 1), h - 15);
    ctx.lineTo(coordX(0), h - 15);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();

    // Points de mesure
    for (let i = 0; i < valeurs.length; i++) {
      const x = coordX(i);
      const y = coordY(valeurs[i]);
      ctx.beginPath();
      ctx.arc(x, y, 2.5, 0, 2 * Math.PI);
      ctx.fillStyle = "#0284c7";
      ctx.fill();
    }

    // Curseur animé de battement / dernière mesure reçue (effet ECG dynamique)
    if (valeurs.length > 0) {
      const dernierIdx = valeurs.length - 1;
      const xLast = coordX(dernierIdx);
      const yLast = coordY(valeurs[dernierIdx]);

      // Anneau extérieur lumineux
      ctx.beginPath();
      ctx.arc(xLast, yLast, 6, 0, 2 * Math.PI);
      ctx.strokeStyle = "rgba(56, 189, 248, 0.7)";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Point central vif
      ctx.beginPath();
      ctx.arc(xLast, yLast, 3, 0, 2 * Math.PI);
      ctx.fillStyle = "#ffffff";
      ctx.fill();
    }
  }

  // -------------------------------------------------------------------
  // 9. Journal des alertes avec acquittement (P0)
  // -------------------------------------------------------------------
  async function rafraichirAlertes() {
    if (!etatApp.astronauteActif) return;
    try {
      const alertes = await apiGet(`/api/alertes/${etatApp.astronauteActif}`);
      if (alertes) afficherAlertes(alertes);
    } catch (err) {
      const conteneur = document.getElementById("listeAlertes");
      if (conteneur) {
        conteneur.innerHTML = `<div class="erreur-carte">Impossible de charger le journal des alertes : ${err.message}</div>`;
      }
    }
  }

  function afficherAlertes(listeAlertes) {
    const conteneur = document.getElementById("listeAlertes");
    if (!conteneur) return;

    if (!listeAlertes || listeAlertes.length === 0) {
      conteneur.innerHTML = '<div class="card"><p>Aucune alerte active pour cet astronaute.</p></div>';
      return;
    }

    conteneur.innerHTML = "";
    listeAlertes.forEach((a) => {
      const el = document.createElement("div");
      const estAcquittee = (a.acquittee === 1);
      el.className = `item-alerte niv-${a.niveau}`;

      const badgeNiv = a.niveau === 2
        ? '<span class="badge-niveau badge-niv-2">■ Critique</span>'
        : '<span class="badge-niveau badge-niv-1">▲ À surveiller</span>';

      const boutonAcquitter = estAcquittee
        ? '<span style="color:#10b981; font-weight:600; font-size:13px;">✓ Acquittée</span>'
        : `<button class="btn-acquitter" data-id="${a.id}">Acquitter</button>`;

      el.innerHTML = `
        <div class="alerte-corps">
          <div class="alerte-haut">
            ${badgeNiv}
            <span class="alerte-regle">Règle : ${a.regle}</span>
            <span class="alerte-date">${a.t || ""} UTC</span>
          </div>
          <p class="alerte-texte">${a.texte_court || a.regle}</p>
        </div>
        <div class="alerte-action">
          ${boutonAcquitter}
        </div>
      `;

      conteneur.appendChild(el);
    });

    // Branchement des boutons d'acquittement
    conteneur.querySelectorAll(".btn-acquitter").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const alerteId = btn.dataset.id;
        btn.disabled = true;
        btn.textContent = "Acquittement...";
        try {
          const res = await apiPost(`/api/alertes/${alerteId}/acquitter`, {});
          if (res && res.ok) {
            rafraichirAlertes();
            rafraichirEtat();
          }
        } catch (err) {
          alert(`Erreur d'acquittement : ${err.message}`);
          btn.disabled = false;
          btn.textContent = "Acquitter";
        }
      });
    });
  }

  // -------------------------------------------------------------------
  // 10. Formulaire du bilan quotidien (P0)
  // -------------------------------------------------------------------
  function configurerFormulaireBilan() {
    document.querySelectorAll(".select-score").forEach((groupe) => {
      groupe.querySelectorAll(".btn-score").forEach((btn) => {
        btn.addEventListener("click", () => {
          groupe.querySelectorAll(".btn-score").forEach((b) => b.classList.remove("actif"));
          btn.classList.add("actif");
        });
      });
    });

    const form = document.getElementById("formBilan");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const humeurBtn = document.querySelector('.select-score[data-field="humeur"] .btn-score.actif');
      const stressBtn = document.querySelector('.select-score[data-field="stress"] .btn-score.actif');
      const fatigueBtn = document.querySelector('.select-score[data-field="fatigue"] .btn-score.actif');

      const payload = {
        astro: etatApp.astronauteActif,
        humeur: parseInt(humeurBtn ? humeurBtn.dataset.val : 3, 10),
        stress: parseInt(stressBtn ? stressBtn.dataset.val : 2, 10),
        fatigue: parseInt(fatigueBtn ? fatigueBtn.dataset.val : 2, 10),
        symptomes: document.getElementById("bilanSymptomes").value.trim(),
        note: document.getElementById("bilanNote").value.trim(),
      };

      const btnSubmit = document.getElementById("btnEnvoyerBilan");
      const feedback = document.getElementById("feedbackBilan");
      btnSubmit.disabled = true;

      try {
        const resultat = await apiPost("/api/bilan", payload);
        btnSubmit.disabled = false;

        if (resultat && resultat.ok) {
          feedback.hidden = false;
          feedback.className = "feedback-message feedback-ok";
          feedback.textContent = "✓ Bilan quotidien enregistré avec succès dans SQLite.";
          form.reset();
          setTimeout(() => { feedback.hidden = true; }, 4000);
        }
      } catch (err) {
        btnSubmit.disabled = false;
        feedback.hidden = false;
        feedback.className = "feedback-message feedback-err";
        feedback.textContent = `Échec de l'enregistrement : ${err.message}`;
      }
    });
  }

  // -------------------------------------------------------------------
  // 11. Surveillance cabine
  // -------------------------------------------------------------------
  async function chargerDonneesCabine() {
    const grille = document.getElementById("grilleCabine");
    if (!grille) return;
    try {
      const data = await apiGet("/api/cabine");
      if (!data) return;

      grille.innerHTML = "";
      for (const [zone, mes] of Object.entries(data)) {
        const carte = document.createElement("div");
        carte.className = "zone-carte";
        carte.innerHTML = `
          <h3>Zone : ${zone}</h3>
          <div class="zone-mesures-liste">
            <div class="zone-item">
              <span class="zone-libelle">Dioxyde de carbone (CO₂)</span>
              <span class="zone-valeur">${mes.co2 !== undefined ? mes.co2 + " ppm" : "—"}</span>
            </div>
            <div class="zone-item">
              <span class="zone-libelle">Oxygène (O₂)</span>
              <span class="zone-valeur">${mes.o2 !== undefined ? mes.o2 + " %" : "—"}</span>
            </div>
            <div class="zone-item">
              <span class="zone-libelle">Température cabine</span>
              <span class="zone-valeur">${mes.temp_cabine !== undefined ? mes.temp_cabine + " °C" : "—"}</span>
            </div>
            <div class="zone-item">
              <span class="zone-libelle">Humidité relative</span>
              <span class="zone-valeur">${mes.humidite !== undefined ? mes.humidite + " %" : "—"}</span>
            </div>
          </div>
        `;
        grille.appendChild(carte);
      }
    } catch (err) {
      grille.innerHTML = `<div class="erreur-carte">Impossible de lire les données cabine : ${err.message}</div>`;
    }
  }

  // -------------------------------------------------------------------
  // 12. Démonstration, déclenchement des scénarios et santé système
  // -------------------------------------------------------------------
  function configurerBoutonsScenario() {
    document.querySelectorAll(".btn-scenario").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const scenario = btn.dataset.scenario;
        const feedback = document.getElementById("demoFeedback");
        btn.disabled = true;
        const txtInitial = btn.textContent;
        btn.textContent = "Simulation en cours...";

        try {
          const res = await apiPost("/api/simulation/scenario", {
            scenario: scenario,
            jours: 28,
          });

          btn.disabled = false;
          btn.textContent = txtInitial;

          if (res && res.ok) {
            feedback.hidden = false;
            feedback.className = "feedback-message feedback-ok";
            feedback.textContent = `✓ Scénario '${scenario}' généré : ${res.trames_generees} trames insérées.`;
            rafraichirEtat();
            chargerSanteSysteme();
            setTimeout(() => { feedback.hidden = true; }, 5000);
          }
        } catch (err) {
          btn.disabled = false;
          btn.textContent = txtInitial;
          feedback.hidden = false;
          feedback.className = "feedback-message feedback-err";
          feedback.textContent = `Erreur lors du scénario '${scenario}' : ${err.message}`;
        }
      });
    });
  }

  async function chargerSanteSysteme() {
    const el = document.getElementById("telemetrieSante");
    if (!el) return;

    el.innerHTML = '<div class="chargement-spinner">Actualisation de l\'état système...</div>';

    try {
      const sante = await apiGet("/api/sante");
      if (!sante) {
        el.innerHTML = '<div class="erreur-carte">⚠️ Impossible de récupérer les données du serveur Vigie.</div>';
        return;
      }

      const statutBadge = (sante.etat === "ok")
        ? '<span class="badge-niveau badge-niv-0">● OK</span>'
        : '<span class="badge-niveau badge-niv-1">▲ Mode Dégradé</span>';

      const sourcesLignes = Object.entries(sante.dernieres_trames || {}).map(([src, info]) => {
        const dateAffichee = (info && info.derniere_date) ? info.derniere_date : "—";
        const ageAffiche = (info && info.age) ? info.age : "Aucune trame";
        return `
          <tr>
            <td><strong>${src}</strong></td>
            <td>${dateAffichee}</td>
            <td>${ageAffiche}</td>
          </tr>
        `;
      }).join("");

      el.innerHTML = `
        <div class="telemetrie-stats">
          <div class="stat-boite">
            <span class="stat-label">État du système</span>
            <span class="stat-valeur">${statutBadge}</span>
          </div>
          <div class="stat-boite">
            <span class="stat-label">Mesures en base</span>
            <span class="stat-valeur">${sante.nb_mesures}</span>
          </div>
          <div class="stat-boite">
            <span class="stat-label">Trames rejetées auditées</span>
            <span class="stat-valeur">${sante.trames_rejetees}</span>
          </div>
          <div class="stat-boite">
            <span class="stat-label">Modèle IA local</span>
            <span class="stat-valeur">${sante.modele_local}</span>
          </div>
        </div>

        <h4 style="margin-top:12px; margin-bottom:6px; font-size:14px; color:var(--bleu-spatial);">
          Âge et réception des sources matérielles
        </h4>
        <table class="telemetrie-table">
          <thead>
            <tr>
              <th>Source</th>
              <th>Dernière réception (UTC)</th>
              <th>Âge calculé</th>
            </tr>
          </thead>
          <tbody>
            ${sourcesLignes || "<tr><td colspan='3'>Aucune source enregistrée.</td></tr>"}
          </tbody>
        </table>
      `;
    } catch (err) {
      el.innerHTML = `<div class="erreur-carte">⚠️ Erreur lors de la récupération de l'état système : ${err.message}</div>`;
    }
  }

})();
