/* ASTRA-MED — interface (vues, graphiques canvas, actions). Aucune dépendance externe. */
(function () {
  'use strict';
  const A = window.ASTRA, S = A.state, esc = A.esc, fmt = A.fmt;
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => Array.from((el || document).querySelectorAll(s));

  let user = null, pending = null, view = 'dashboard', dirty = true, lastActivity = Date.now();
  const ui = { sel: 0, win: 288, fAlert: { level: 'all', status: 'active', astro: 'all' }, hist: { astro: 0, param: 'hr', win: 288 }, histTick: -99, envMod: 0, bench: null, lastAlertVer: -1, repAstro: 0 };
  const LV = A.LEVELS;
  const ROLE_ALL = ['astronaut', 'flight_surgeon', 'ground_center', 'admin'];
  const NAV = [
    { id: 'dashboard', label: 'Tableau de bord', icon: '▦', roles: ROLE_ALL },
    { id: 'astro', label: 'Détail astronaute', icon: '♥', roles: ROLE_ALL },
    { id: 'alerts', label: 'Alertes', icon: '⚠', roles: ROLE_ALL, badge: true },
    { id: 'env', label: 'Environnement', icon: '☁', roles: ['flight_surgeon', 'ground_center', 'admin'] },
    { id: 'selfreport', label: 'Auto-évaluation', icon: '✎', roles: ['astronaut', 'flight_surgeon', 'admin'] },
    { id: 'history', label: 'Historique & rapports', icon: '☰', roles: ROLE_ALL },
    { id: 'comm', label: 'Communication Terre', icon: '⇄', roles: ['flight_surgeon', 'ground_center', 'admin'] },
    { id: 'eval', label: 'Évaluation', icon: '✓', roles: ['flight_surgeon', 'ground_center', 'admin'] },
    { id: 'admin', label: 'Administration', icon: '⚙', roles: ['admin'] },
    { id: 'docs', label: 'Documentation', icon: '?', roles: ROLE_ALL }
  ];
  const TITLES = { dashboard: 'Tableau de bord équipage', astro: 'Détail astronaute', alerts: 'Alertes', env: 'Environnement', selfreport: 'Auto-évaluation et médicaments', history: 'Historique et rapports', comm: 'Communication avec la Terre', eval: 'Évaluation expérimentale', admin: 'Administration et sécurité', docs: 'Documentation du projet' };

  /* ---------- Rôles, visibilité ---------- */
  const canAct = () => user && (user.role === 'flight_surgeon' || user.role === 'admin');
  const isGround = () => user && user.role === 'ground_center';
  const visibleCrew = () => (user.role === 'astronaut' ? [S.crew[user.astronautId]] : S.crew);
  function lag() { return isGround() ? Math.max(0, (S.t - 1) - A.syncedTick()) : 0; }
  function endIdx(a) { return Math.max(0, a.hist.t.length - lag()); }
  function valAt(a, p, e) { for (let i = e - 1; i >= Math.max(0, e - 15); i--) if (isFinite(a.hist[p][i])) return a.hist[p][i]; return NaN; }
  function curVal(a, p) { return lag() ? valAt(a, p, endIdx(a)) : a.last[p]; }
  function visAlerts() {
    const st = A.syncedTick();
    return S.alerts.filter(al => {
      if (user.role === 'astronaut') return al.astronautId === user.astronautId || (al.astronautId == null && al.module === A.MODULES[S.crew[user.astronautId].module]);
      if (isGround()) return al.createdTick <= st;
      return true;
    });
  }
  const isLive = al => al.status === 'open' || al.status === 'acknowledged' || al.status === 'escalated';
  function crewLevel(a) {
    let best = null;
    for (const al of visAlerts()) if (al.astronautId === a.id && isLive(al) && (!best || LV[al.level].rank > LV[best].rank)) best = al.level;
    return best;
  }
  const pill = lvl => lvl ? '<span class="pill lv-' + lvl + '">' + LV[lvl].label + '</span>' : '<span class="pill lv-ok">● Nominal</span>';
  const statusLabel = s => ({ open: 'Ouverte', acknowledged: 'Acquittée', escalated: 'Escaladée', resolved: 'Résolue (auto)', closed: 'Clôturée' }[s] || s);

  /* ---------- Graphiques canvas ---------- */
  function setup(cv) {
    const dpr = window.devicePixelRatio || 1, w = Math.max(60, cv.clientWidth), h = cv.clientHeight || 150;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, w, h);
    return { c, w, h };
  }
  function drawChart(cv, o) {
    if (!cv) return;
    const { c, w, h } = setup(cv);
    const mini = !!o.mini, P = mini ? { l: 2, r: 2, t: 3, b: 3 } : { l: 46, r: 8, t: 8, b: 20 };
    const xs = o.xs || [];
    let lo = Infinity, hi = -Infinity;
    const eat = v => { if (isFinite(v)) { if (v < lo) lo = v; if (v > hi) hi = v; } };
    (o.series || []).forEach(s => s.ys.forEach(eat));
    if (o.band) { eat(o.band.lo); eat(o.band.hi); }
    (o.hlines || []).forEach(l => eat(l.y));
    if (!xs.length || !isFinite(lo)) { c.fillStyle = '#8e9bc9'; c.font = '12px system-ui'; c.fillText('Pas de données', 10, h / 2); return; }
    if (hi - lo < 1e-9) { hi += 1; lo -= 1; }
    const pad = (hi - lo) * 0.1; lo -= pad; hi += pad;
    const x0 = xs[0], x1 = xs[xs.length - 1] === x0 ? x0 + 1 : xs[xs.length - 1];
    const X = x => P.l + (x - x0) / (x1 - x0) * (w - P.l - P.r), Y = y => h - P.b - (y - lo) / (hi - lo) * (h - P.t - P.b);
    if (!mini) {
      c.strokeStyle = '#243056'; c.fillStyle = '#8e9bc9'; c.font = '11px system-ui'; c.lineWidth = 1;
      for (let i = 0; i <= 4; i++) {
        const y = lo + (hi - lo) * i / 4, yy = Y(y);
        c.beginPath(); c.moveTo(P.l, yy); c.lineTo(w - P.r, yy); c.stroke();
        c.fillText(fmt(y, o.dec || 0), 4, yy + 4);
      }
      for (let i = 0; i <= 3; i++) {
        const x = x0 + (x1 - x0) * i / 3;
        c.textAlign = i === 0 ? 'left' : i === 3 ? 'right' : 'center';
        c.fillText(A.fmtTime(Math.round(x)), X(x), h - 5);
      }
      c.textAlign = 'left';
    }
    if (o.band) { c.fillStyle = 'rgba(90,169,255,.14)'; c.fillRect(P.l, Y(o.band.hi), w - P.l - P.r, Y(o.band.lo) - Y(o.band.hi)); }
    (o.hlines || []).forEach(l => { c.strokeStyle = l.color || '#ffc857'; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(P.l, Y(l.y)); c.lineTo(w - P.r, Y(l.y)); c.stroke(); c.setLineDash([]); });
    (o.markers || []).forEach(m => {
      if (m.x < x0 || m.x > x1) return;
      c.strokeStyle = m.color; c.setLineDash([3, 3]); c.beginPath(); c.moveTo(X(m.x), P.t); c.lineTo(X(m.x), h - P.b); c.stroke(); c.setLineDash([]);
      c.fillStyle = m.color; c.beginPath(); c.moveTo(X(m.x) - 4, P.t); c.lineTo(X(m.x) + 4, P.t); c.lineTo(X(m.x), P.t + 7); c.fill();
    });
    (o.series || []).forEach(s => {
      c.strokeStyle = s.color || '#5aa9ff'; c.lineWidth = mini ? 1.5 : 1.6; c.beginPath();
      let pen = false;
      s.ys.forEach((y, i) => {
        if (!isFinite(y)) { pen = false; return; }
        if (!pen) { c.moveTo(X(xs[i]), Y(y)); pen = true; } else c.lineTo(X(xs[i]), Y(y));
      });
      c.stroke();
      if (o.dots) { c.fillStyle = s.color || '#5aa9ff'; s.ys.forEach((y, i) => { if (isFinite(y)) { c.beginPath(); c.arc(X(xs[i]), Y(y), 3, 0, 7); c.fill(); } }); }
    });
  }
  const LVCOL = { technical: '#9aa7d6', vigilance: '#ffc857', medical: '#ff7a59', emergency: '#ff3b5c' };
  function histSlice(a, p, win) { const e = endIdx(a), s = Math.max(0, e - win); return { xs: a.hist.t.slice(s, e), ys: a.hist[p].slice(s, e) }; }

  /* ---------- Toasts, modale ---------- */
  function toast(msg, level) {
    const box = $('#toasts'); if (!box) return;
    const d = document.createElement('div'); d.className = 'toast ' + (level || 'info'); d.textContent = msg;
    box.appendChild(d); while (box.children.length > 5) box.removeChild(box.firstChild);
    setTimeout(() => d.remove(), 6000);
  }
  A.hooks.toast = (m, l) => { if (user) toast(m, l); };
  function openModal(html) { const m = $('#modal'); m.innerHTML = '<div class="modal">' + html + '</div>'; m.hidden = false; }
  function closeModal() { const m = $('#modal'); m.hidden = true; m.innerHTML = ''; }

  function download(name, text, mime) {
    const b = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
    const u = URL.createObjectURL(b), a = document.createElement('a');
    a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000);
  }

  /* ---------- Connexion ---------- */
  function renderLogin(msg, step2) {
    $('#app').innerHTML = `
    <div class="login-wrap"><div class="login">
      <div class="brand"><div class="logo">A</div><div><h1 style="margin:0">ASTRA-MED</h1><div class="muted small">Surveillance intelligente de la santé des astronautes</div></div></div>
      ${step2 ? `
        <h2 style="margin-top:18px">Vérification en deux étapes</h2>
        <p class="muted">Entrez le code à 6 chiffres (démo : <b>123456</b>).</p>
        <label>Code MFA</label><input type="text" id="l-mfa" inputmode="numeric" maxlength="6" autocomplete="off">
        <div class="err" id="l-err">${esc(msg || '')}</div>
        <button class="primary" data-action="mfa">Valider</button> <button data-action="login-back">Retour</button>
      ` : `
        <label>Identifiant</label><input type="text" id="l-user" autocomplete="username">
        <label>Mot de passe</label><input type="password" id="l-pass" autocomplete="current-password">
        <div class="err" id="l-err">${esc(msg || '')}</div>
        <button class="primary" data-action="login">Se connecter</button>
        <div class="demo-acc"><div class="small muted">Comptes de démonstration (cliquez pour remplir) :</div>
          <button class="small" data-action="fill" data-u="medecin" data-p="astra2026">Médecin de bord (MFA)</button>
          <button class="small" data-action="fill" data-u="astronaute" data-p="orbit2026">Astronaute</button>
          <button class="small" data-action="fill" data-u="terre" data-p="ground2026">Centre terrestre</button>
          <button class="small" data-action="fill" data-u="admin" data-p="admin2026">Administrateur (MFA)</button>
        </div>`}
      <div class="disclaimer"><b>Prototype expérimental non certifié.</b> Outil d’assistance : il ne pose aucun diagnostic et ne remplace pas le jugement médical. Données entièrement simulées, conservées en mémoire du navigateur.</div>
    </div></div>`;
    const f = $('#l-user') || $('#l-mfa'); if (f) f.focus();
  }

  function startSession(u) {
    user = u; A.currentUser = u; lastActivity = Date.now();
    A.auditLog('CONNEXION', u.username, A.ROLE_LABEL[u.role]);
    view = 'dashboard'; ui.sel = u.astronautId != null ? u.astronautId : 0; ui.hist.astro = ui.sel; ui.repAstro = ui.sel;
    renderShell(); go('dashboard');
  }
  function logout(reason) {
    if (user) A.auditLog('DECONNEXION', user.username, reason || '');
    user = null; A.currentUser = null; pending = null; closeModal(); renderLogin(reason ? reason : '');
  }

  /* ---------- Coque ---------- */
  function renderShell() {
    $('#app').innerHTML = `
    <div class="shell">
      <aside class="side">
        <div class="brand"><div class="logo">A</div><div><b>ASTRA-MED</b><div class="muted small">v2.0 · prototype</div></div></div>
        ${NAV.filter(n => n.roles.indexOf(user.role) >= 0).map(n => `<div class="nav-item" data-action="nav" data-v="${n.id}" id="nav-${n.id}"><span>${n.icon}</span>${n.label}${n.badge ? '<span class="badge" id="nav-badge" hidden>0</span>' : ''}</div>`).join('')}
        <div class="userbox"><b>${esc(user.name)}</b><div class="muted">${A.ROLE_LABEL[user.role]}</div><button class="small" style="margin-top:8px" data-action="logout">Se déconnecter</button></div>
      </aside>
      <main class="main">
        <div class="topbar">
          <div class="title" id="tb-title"></div>
          <span class="pill" id="tb-clock"></span>
          <span class="pill" id="tb-link"></span>
          <div class="seg" id="tb-speed">
            <button data-action="speed" data-v="1">×1</button><button data-action="speed" data-v="5">×5</button><button data-action="speed" data-v="20">×20</button>
          </div>
          <button class="small" id="tb-pause" data-action="pause">⏸ Pause</button>
          ${canAct() ? '<button class="small" data-action="day" title="Avance la simulation de 24 h">+1 jour</button>' : ''}
        </div>
        <div id="view"></div>
      </main>
    </div>`;
  }
  function go(v) {
    if (!NAV.find(n => n.id === v && n.roles.indexOf(user.role) >= 0)) v = 'dashboard';
    view = v;
    $$('.nav-item').forEach(el => el.classList.toggle('active', el.id === 'nav-' + v));
    $('#tb-title').textContent = TITLES[v];
    $('#view').innerHTML = views[v].render();
    if (views[v].after) views[v].after();
    ui.lastAlertVer = -1; ui.histTick = -99;
    dirty = true; frame(true);
  }
  function topbarUpdate() {
    $('#tb-clock').textContent = '🕒 ' + A.fmtTime(S.t - 1) + ' (temps de mission)';
    const C = S.comm, lk = $('#tb-link');
    lk.innerHTML = C.online ? (C.catchup ? '<span class="dot"></span> Liaison Terre : synchronisation (' + C.queue + ')' : '<span class="dot"></span> Liaison Terre : active') : '<span class="dot off"></span> Liaison Terre : coupée · autonome (' + C.queue + ' en file)';
    $$('#tb-speed button').forEach(b => b.classList.toggle('on', +b.dataset.v === S.speed));
    $('#tb-pause').textContent = S.running ? '⏸ Pause' : '▶ Reprendre';
    const n = visAlerts().filter(isLive).length, b = $('#nav-badge');
    if (b) { b.hidden = n === 0; b.textContent = n; }
  }

  /* ---------- Vues ---------- */
  const views = {};

  /* Tableau de bord */
  views.dashboard = {
    render() {
      return `<div class="stats" id="d-stats"></div>
      <div class="grid g-dash">
        <div><h3>Équipage ${user.role === 'astronaut' ? '(vos données)' : ''}</h3>
          <div class="crew-grid">${visibleCrew().map(a => `
            <div class="card crew" id="cc-${a.id}" data-action="open-astro" data-id="${a.id}">
              <div class="head"><div><b>${esc(a.name)}</b> <span class="muted small">${a.code}</span><div class="muted small">${esc(a.role)} · ${esc(A.MODULES[a.module])}</div></div><span id="cs-${a.id}"></span></div>
              <div class="vit">${A.VITALS.map(p => `<div id="cv-${a.id}-${p}"><b>–</b><span>${A.PARAMS[p].short} ${A.PARAMS[p].unit}</span></div>`).join('')}</div>
              <canvas class="spark" id="sp-${a.id}"></canvas>
              <div class="muted small" id="cm-${a.id}"></div>
            </div>`).join('')}</div>
        </div>
        <div>
          <div class="card"><h3>Alertes actives</h3><div id="d-alerts"></div></div>
          <div class="card" style="margin-top:14px"><h3>Environnement</h3><div id="d-env"></div></div>
        </div>
      </div>`;
    },
    update() {
      const C = S.comm, crew = visibleCrew(), al = visAlerts().filter(isLive);
      const nominal = crew.filter(a => !crewLevel(a)).length;
      const stale = lag();
      $('#d-stats').innerHTML = `
        <div class="card stat"><b>${nominal} / ${crew.length}</b><span>Astronautes nominaux</span></div>
        <div class="card stat"><b>${al.length}</b><span>Alertes actives</span></div>
        <div class="card stat"><b>${C.online ? (C.catchup ? 'Rattrapage' : 'Active') : 'Coupée'}</b><span>Liaison Terre · file : ${C.queue}</span></div>
        <div class="card stat"><b>${stale ? 'Données figées' : 'Temps réel'}</b><span>${stale ? 'Vue Terre : dernière synchro ' + A.fmtTime(A.syncedTick()) : 'Dernier échantillon ' + A.fmtTime(S.t - 1)}</span></div>`;
      crew.forEach(a => {
        const lvl = crewLevel(a), card = $('#cc-' + a.id); if (!card) return;
        card.className = 'card crew ' + (lvl || '');
        $('#cs-' + a.id).innerHTML = pill(lvl);
        const B = a.baseline && a.baseline[a.lastSt === 0 ? 0 : 1];
        A.VITALS.forEach(p => {
          const el = $('#cv-' + a.id + '-' + p), v = curVal(a, p);
          el.firstChild.textContent = isFinite(v) ? fmt(v, A.PARAMS[p].dec) : '—';
          let cls = '';
          if (!isFinite(v)) cls = 'bad'; else if (B && B[p] && a.lastSt !== 2) { const z = Math.abs(v - B[p].c) / B[p].s; cls = z > 5 ? 'bad' : z > 3 ? 'warn' : ''; }
          el.className = cls;
        });
        const sl = histSlice(a, 'hr', 72);
        drawChart($('#sp-' + a.id), { xs: sl.xs, series: [{ ys: sl.ys, color: lvl === 'medical' || lvl === 'emergency' ? '#ff7a59' : '#5aa9ff' }], mini: true });
        const n = al.filter(x => x.astronautId === a.id).length;
        $('#cm-' + a.id).textContent = (n ? n + ' alerte(s) active(s) · ' : '') + 'FC sur 6 h · score IF ' + fmt(a.lastScore, 2);
      });
      if (ui.lastAlertVer !== S.alertVersion + '-' + stale + '-' + C.queue) {
        ui.lastAlertVer = S.alertVersion + '-' + stale + '-' + C.queue;
        const sorted = al.slice().sort((x, y) => LV[y.level].rank - LV[x.level].rank || y.createdTick - x.createdTick).slice(0, 8);
        $('#d-alerts').innerHTML = sorted.length ? sorted.map(alertRow).join('') : '<div class="muted">Aucune alerte active. Utilisez les scénarios (détail astronaute) pour en provoquer.</div>';
      }
      $('#d-env').innerHTML = S.env.mods.map((m, i) => {
        const v = m.val;
        return `<div style="margin-bottom:10px"><b>${esc(m.name)}</b><div class="env-tiles">
          <div class="${v.co2 > 2500 ? 'bad' : ''}"><b>${fmt(v.co2)}</b><span>CO₂ ppm</span></div>
          <div class="${v.temp > 29 ? 'bad' : ''}"><b>${fmt(v.temp, 1)}</b><span>°C</span></div>
          <div><b>${fmt(v.hum)}</b><span>% HR</span></div><div><b>${fmt(v.noise)}</b><span>dB</span></div>
          <div class="${v.rad > 25 ? 'bad' : ''}"><b>${fmt(v.rad, 1)}</b><span>µSv/h</span></div></div></div>`;
      }).join('');
    }
  };

  function alertRow(al) {
    const who = al.astronautId != null ? S.crew[al.astronautId].name : (al.module || 'Module');
    return `<div class="alert-row ${al.level}" data-action="open-alert" data-id="${al.id}">
      <div class="txt"><div><span class="pill lv-${al.level}">${LV[al.level].label}</span> <b>${esc(who)}</b> <span class="muted small">· ${al.rule} · ${A.fmtTime(al.createdTick)} · ${statusLabel(al.status)}</span></div>
      <div class="sum">${esc(al.headline)}</div></div></div>`;
  }

  /* Détail astronaute */
  const CHARTS = [['hr', 'Fréquence cardiaque (bpm)'], ['spo2', 'SpO₂ (%)'], ['rr', 'Fréquence respiratoire (/min)'], ['temp', 'Température (°C)'], ['sys', 'Pression systolique (mmHg)'], ['ecg', 'Indice d’irrégularité ECG']];
  views.astro = {
    render() {
      const sel = ui.sel;
      return `<div class="card"><div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center">
        ${user.role === 'astronaut' ? '' : `<div style="min-width:230px"><label style="margin-top:0">Astronaute</label><select data-change="sel-astro">${S.crew.map(a => `<option value="${a.id}" ${a.id === sel ? 'selected' : ''}>${a.code} · ${esc(a.name)}</option>`).join('')}</select></div>`}
        <div><label style="margin-top:0">Fenêtre</label><div class="seg">${[[72, '6 h'], [288, '24 h'], [576, '48 h'], [1152, '4 j']].map(w => `<button data-action="win" data-v="${w[0]}" class="${ui.win === w[0] ? 'on' : ''}">${w[1]}</button>`).join('')}</div></div>
        <div id="a-status" style="margin-left:auto"></div></div>
        <div class="hint">Bande bleue = ligne de base personnelle au repos ± 3 σ robustes. Triangles = alertes. Pendant l’effort physique, les règles de signes vitaux ne sont pas évaluées.</div></div>
      <div class="grid g2" style="margin-top:14px">
        ${CHARTS.map(c => `<div class="card"><h3>${c[1]}</h3><canvas class="chart" id="ch-${c[0]}"></canvas></div>`).join('')}
        <div class="card"><h3>Sommeil — durée par nuit (h)</h3><canvas class="chart" id="ch-sleep"></canvas><div class="hint">Ligne pointillée = seuil de 6 h (règle R03 : 3 nuits consécutives).</div></div>
        <div class="card"><h3>État du moteur d’analyse</h3><div id="a-info"></div></div>
      </div>
      ${canAct() ? `<div class="card" style="margin-top:14px"><h3>Scénarios d’expérimentation (injection sur cet astronaute)</h3>
        <div class="scn">${Object.keys(A.SCENARIOS).map(k => `<button class="small" title="${esc(A.SCENARIOS[k].desc)}" data-action="scenario" data-id="${k}">${A.SCENARIOS[k].label}</button>`).join('')}</div>
        <div class="hint">Les scénarios simulent des anomalies pour tester la détection. Chaque injection est tracée dans le journal d’audit.</div></div>` : ''}
      <div class="card" style="margin-top:14px"><h3>Alertes de cet astronaute</h3><div id="a-alerts"></div></div>`;
    },
    update() {
      const a = S.crew[ui.sel], lvl = crewLevel(a);
      $('#a-status').innerHTML = pill(lvl) + ' <span class="pill">' + esc(a.role) + ' · ' + esc(A.MODULES[a.module]) + '</span>';
      const mine = visAlerts().filter(x => x.astronautId === a.id);
      const B = a.baseline && a.baseline[1];
      CHARTS.forEach(([p]) => {
        const sl = histSlice(a, p, ui.win);
        const o = { xs: sl.xs, series: [{ ys: sl.ys, color: p === 'ecg' ? '#c084fc' : '#5aa9ff' }], dec: A.PARAMS[p].dec || (p === 'ecg' ? 2 : 0), markers: mine.filter(x => x.createdTick >= (sl.xs[0] || 0)).map(x => ({ x: x.createdTick, color: LVCOL[x.level] })) };
        if (B && B[p]) o.band = { lo: B[p].c - 3 * B[p].s, hi: B[p].c + 3 * B[p].s };
        drawChart($('#ch-' + p), o);
      });
      const nights = a.sleepHist.filter(x => x.t >= 0 && x.t <= S.t - 1 - lag());
      drawChart($('#ch-sleep'), { xs: nights.map(x => x.t), series: [{ ys: nights.map(x => x.h), color: '#7c5cff' }], dots: true, hlines: [{ y: 6, color: '#ffc857' }], dec: 1 });
      const q = a.quarantine.length;
      $('#a-info').innerHTML = `<dl class="kv">
        <dt>Ligne de base FC (repos)</dt><dd>${B ? fmt(B.hr.c, 1) + ' bpm ± ' + fmt(B.hr.s, 1) + ' (' + B.hr.n + ' éch.)' : '—'}</dd>
        <dt>Score d’anomalie (IF)</dt><dd>${fmt(a.lastScore, 2)} <span class="muted">/ seuil ${fmt(a.ifThr, 2)}</span></dd>
        <dt>Mises à jour du modèle</dt><dd>${a.trainedAt >= 0 ? A.fmtTime(a.trainedAt) : '—'}</dd>
        <dt>État du capteur</dt><dd>${A.VITALS.filter(p => a.missing[p] >= 2).map(p => '<span class="tag lv-technical">' + A.PARAMS[p].short + ' : sans signal</span>').join(' ') || '<span class="tag lv-ok">tous actifs</span>'}</dd>
        <dt>Données en quarantaine</dt><dd>${q} valeur(s) rejetée(s)</dd>
        <dt>Dernière auto-évaluation</dt><dd>${(() => { const r = S.reports.slice().reverse().find(x => x.astronautId === a.id); return r ? 'fatigue ' + r.fatigue + '/10 · humeur ' + r.mood + '/10 · stress ' + r.stress + '/10 (' + A.fmtTime(r.tick) + ')' : '—'; })()}</dd></dl>`;
      const key = S.alertVersion + '-' + a.id + '-' + lag();
      if (ui.lastAlertVer !== key) {
        ui.lastAlertVer = key;
        $('#a-alerts').innerHTML = mine.length ? mine.slice(0, 12).map(alertRow).join('') : '<div class="muted">Aucune alerte pour cet astronaute.</div>';
      }
    }
  };

  /* Alertes */
  views.alerts = {
    render() {
      const f = ui.fAlert;
      return `<div class="card"><div class="grid g3">
        <div><label style="margin-top:0">Niveau</label><select data-change="f-level"><option value="all">Tous</option>${Object.keys(LV).map(k => `<option value="${k}" ${f.level === k ? 'selected' : ''}>${LV[k].label}</option>`).join('')}</select></div>
        <div><label style="margin-top:0">Statut</label><select data-change="f-status">${[['active', 'Actives'], ['all', 'Toutes'], ['resolved', 'Résolues / clôturées']].map(o => `<option value="${o[0]}" ${f.status === o[0] ? 'selected' : ''}>${o[1]}</option>`).join('')}</select></div>
        <div><label style="margin-top:0">Astronaute</label><select data-change="f-astro"><option value="all">Tous</option>${visibleCrew().map(a => `<option value="${a.id}" ${String(f.astro) === String(a.id) ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}</select></div>
      </div></div>
      <div class="card" style="margin-top:14px"><div id="al-list"></div></div>`;
    },
    update() {
      const key = S.alertVersion + '-' + JSON.stringify(ui.fAlert) + '-' + lag();
      if (ui.lastAlertVer === key) return;
      ui.lastAlertVer = key;
      const f = ui.fAlert;
      const list = visAlerts().filter(al => (f.level === 'all' || al.level === f.level) && (f.status === 'all' || (f.status === 'active' ? isLive(al) : !isLive(al))) && (f.astro === 'all' || String(al.astronautId) === String(f.astro)));
      $('#al-list').innerHTML = list.length ? `<table><thead><tr><th>#</th><th>Heure</th><th>Niveau</th><th>Concerné</th><th>Règle</th><th>Résumé</th><th>Statut</th></tr></thead><tbody>${list.slice(0, 150).map(al => `
        <tr class="click" data-action="open-alert" data-id="${al.id}"><td>${al.id}</td><td>${A.fmtTime(al.createdTick)}</td><td>${pill(al.level)}</td>
        <td>${esc(al.astronautId != null ? S.crew[al.astronautId].name : al.module)}</td><td>${al.rule}</td><td>${esc(al.headline)}</td><td>${statusLabel(al.status)}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">Aucune alerte ne correspond aux filtres.</div>';
    }
  };

  function openAlert(id) {
    const al = S.alerts.find(x => x.id === id); if (!al) return;
    const a = al.astronautId != null ? S.crew[al.astronautId] : null;
    const dev = isFinite(al.measured) && isFinite(al.baseline) && al.baseline ? (al.measured - al.baseline) / Math.abs(al.baseline) * 100 : NaN;
    const live = isLive(al);
    openModal(`
      <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start"><div><h2 style="margin:0">Alerte #${al.id} · ${al.rule}</h2><div class="muted small">${A.fmtTime(al.createdTick)} · ${statusLabel(al.status)}</div></div>${pill(al.level)}</div>
      <p style="margin:14px 0;padding:12px;border:1px solid var(--line);border-radius:10px;background:#0e1736">${esc(al.summary)}</p>
      <h3>Explication</h3>
      <dl class="kv">
        <dt>Concerné</dt><dd>${esc(a ? a.name + ' (' + a.code + ')' : al.module)}</dd>
        <dt>Paramètre déclencheur</dt><dd>${esc(al.paramLabel || '—')}</dd>
        <dt>Valeur mesurée</dt><dd>${isFinite(al.measured) ? fmt(al.measured, al.dec) + ' ' + esc(al.unit) : '—'}</dd>
        <dt>Référence personnelle</dt><dd>${isFinite(al.baseline) ? fmt(al.baseline, al.dec) + ' ' + esc(al.unit) : '—'}${isFinite(dev) && al.rule !== 'R06' ? ' (' + (dev >= 0 ? '+' : '−') + Math.abs(dev).toFixed(0) + ' %)' : ''}</dd>
        <dt>Durée</dt><dd>${A.fmtDur(al.durationTicks * A.TICK_MIN)}</dd>
        <dt>Paramètres associés</dt><dd>${al.related && al.related.length ? al.related.map(esc).join('<br>') : '—'}</dd>
        <dt>Niveau de confiance</dt><dd>${Math.round(al.confidence * 100)} %</dd>
        <dt>Action recommandée</dt><dd>${esc(al.action)}</dd></dl>
      <h3 style="margin-top:16px">Notes</h3>
      <div>${al.notes.length ? al.notes.map(n => `<div class="small"><b>${esc(n.who)}</b> · ${A.fmtTime(n.tick)} — ${esc(n.text)}</div>`).join('') : '<div class="muted small">Aucune note.</div>'}</div>
      ${user.role !== 'astronaut' ? `<label>Ajouter une note</label><textarea id="al-note" placeholder="Observation clinique, décision, suivi…"></textarea>` : ''}
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
        ${user.role !== 'astronaut' ? `<button data-action="add-note" data-id="${al.id}">Enregistrer la note</button>` : ''}
        ${canAct() && al.status === 'open' ? `<button class="primary" data-action="ack" data-id="${al.id}">Acquitter</button>` : ''}
        ${canAct() && (al.status === 'open' || al.status === 'acknowledged') ? `<button class="danger" data-action="escalate" data-id="${al.id}">Escalader vers la Terre</button>` : ''}
        ${canAct() && live ? `<button data-action="close-alert" data-id="${al.id}">Clôturer</button>` : ''}
        <button style="margin-left:auto" data-action="close-modal">Fermer</button></div>
      <div class="hint">Aide à la décision uniquement : la décision médicale reste humaine.</div>`);
  }

  /* Environnement */
  const ENVCH = [['co2', 'CO₂ (ppm)', 2500], ['temp', 'Température (°C)', 29], ['hum', 'Humidité (%)', null], ['noise', 'Bruit (dB)', null], ['rad', 'Rayonnements (µSv/h)', 25]];
  views.env = {
    render() {
      return `<div class="card" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div class="seg">${S.env.mods.map((m, i) => `<button data-action="envmod" data-v="${i}" class="${ui.envMod === i ? 'on' : ''}">${esc(m.name)}</button>`).join('')}</div>
        ${canAct() ? '<button class="small danger" data-action="scenario-env">Injecter une dégradation de l’air (S5)</button><button class="small" data-action="env-reset">Rétablir</button>' : ''}
        <div class="hint" style="margin:0">Seuils d’alerte : CO₂ > 2 500 ppm · T° > 29 °C · rayonnements > 25 µSv/h (règle ENV1, R04 si symptômes).</div></div>
      <div class="grid g2" style="margin-top:14px">${ENVCH.map(c => `<div class="card"><h3>${c[1]}</h3><canvas class="chart" id="ev-${c[0]}"></canvas></div>`).join('')}</div>`;
    },
    update() {
      const m = S.env.mods[ui.envMod];
      const e = Math.max(0, S.env.t.length - lag()), s = Math.max(0, e - 576);
      ENVCH.forEach(([k, , thr]) => drawChart($('#ev-' + k), { xs: S.env.t.slice(s, e), series: [{ ys: m.hist[k].slice(s, e), color: '#3ddc97' }], hlines: thr ? [{ y: thr, color: '#ff7a59' }] : [], dec: A.ENVP[k].dec }));
    }
  };

  /* Auto-évaluation + médicaments */
  views.selfreport = {
    render() {
      const sel = ui.repAstro;
      return `<div class="grid g2">
      <div class="card"><h3>Nouvelle auto-évaluation</h3>
        ${user.role === 'astronaut' ? `<div class="muted">Astronaute : <b>${esc(S.crew[user.astronautId].name)}</b></div>` : `<label style="margin-top:0">Astronaute</label><select data-change="rep-astro">${S.crew.map(a => `<option value="${a.id}" ${a.id === sel ? 'selected' : ''}>${a.code} · ${esc(a.name)}</option>`).join('')}</select>`}
        ${[['fatigue', 'Fatigue', 3], ['mood', 'Humeur (10 = très bonne)', 7], ['stress', 'Stress', 3]].map(r => `<label>${r[1]} : <b id="v-${r[0]}">${r[2]}</b>/10</label><div class="range"><input type="range" min="0" max="10" value="${r[2]}" id="r-${r[0]}" data-range="${r[0]}"></div>`).join('')}
        <label>Symptômes</label><div class="symp">${['Maux de tête', 'Nausées', 'Essoufflement', 'Vertiges', 'Palpitations'].map(s => `<label><input type="checkbox" class="sy" value="${s}"> ${s}</label>`).join('')}</div>
        <label>Notes</label><textarea id="r-notes" placeholder="Remarques libres"></textarea>
        <button class="primary" style="margin-top:10px" data-action="submit-report">Enregistrer</button>
        <div class="hint">Les symptômes déclarés alimentent la règle R04 (CO₂ élevé + symptômes) et l’explicabilité des alertes.</div></div>
      <div class="card"><h3>Médicaments</h3><div id="meds"></div>
        <label>Ajouter un traitement</label><div style="display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:6px"><input type="text" id="m-name" placeholder="Nom"><input type="text" id="m-dose" placeholder="Dose"><input type="text" id="m-sched" placeholder="Rythme"><button data-action="add-med">Ajouter</button></div></div>
      </div>
      <div class="card" style="margin-top:14px"><h3>Auto-évaluations récentes</h3><div id="reports"></div></div>`;
    },
    update() {
      const ids = visibleCrew().map(a => a.id);
      const reps = S.reports.filter(r => ids.indexOf(r.astronautId) >= 0).slice().reverse().slice(0, 12);
      const key = S.reports.length + '-' + S.meds.length + '-' + S.meds.reduce((n, m) => n + m.taken.length, 0) + '-' + ui.repAstro;
      if (ui.lastAlertVer === key) return; ui.lastAlertVer = key;
      $('#reports').innerHTML = reps.length ? `<table><thead><tr><th>Heure</th><th>Astronaute</th><th>Fatigue</th><th>Humeur</th><th>Stress</th><th>Symptômes</th><th>Notes</th></tr></thead><tbody>${reps.map(r => `<tr><td>${A.fmtTime(r.tick)}</td><td>${esc(S.crew[r.astronautId].name)}</td><td>${r.fatigue}</td><td>${r.mood}</td><td>${r.stress}</td><td>${esc(r.symptoms.join(', ') || '—')}</td><td>${esc(r.notes || '')}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">Aucune auto-évaluation enregistrée.</div>';
      const meds = S.meds.map((m, i) => ({ m, i })).filter(x => x.m.astronautId === ui.repAstro);
      $('#meds').innerHTML = meds.length ? meds.map(x => `<div style="display:flex;gap:8px;align-items:center;margin-bottom:6px"><div style="flex:1"><b>${esc(x.m.name)}</b> ${esc(x.m.dose)} <span class="muted small">· ${esc(x.m.sched)} · ${x.m.taken.length} prise(s)${x.m.taken.length ? ', dernière ' + A.fmtTime(x.m.taken[x.m.taken.length - 1]) : ''}</span></div><button class="small" data-action="take-med" data-id="${x.i}">Marquer pris</button></div>`).join('') : '<div class="muted">Aucun traitement enregistré pour cet astronaute.</div>';
    }
  };

  /* Historique et rapports */
  function paramOptions() {
    return `<optgroup label="Signes vitaux">${['hr', 'spo2', 'rr', 'temp', 'sys', 'ecg', 'act'].map(p => `<option value="${p}" ${ui.hist.param === p ? 'selected' : ''}>${A.PARAMS[p].label}</option>`).join('')}</optgroup>` +
      S.env.mods.map((m, i) => `<optgroup label="Environnement — ${esc(m.name)}">${Object.keys(A.ENVP).map(k => `<option value="env:${i}:${k}" ${ui.hist.param === 'env:' + i + ':' + k ? 'selected' : ''}>${A.ENVP[k].label}</option>`).join('')}</optgroup>`).join('');
  }
  views.history = {
    render() {
      const h = ui.hist;
      return `<div class="card"><div class="grid g3">
        <div><label style="margin-top:0">Astronaute</label><select data-change="h-astro">${visibleCrew().map(a => `<option value="${a.id}" ${a.id === h.astro ? 'selected' : ''}>${a.code} · ${esc(a.name)}</option>`).join('')}</select></div>
        <div><label style="margin-top:0">Paramètre</label><select data-change="h-param">${paramOptions()}</select></div>
        <div><label style="margin-top:0">Période</label><select data-change="h-win">${[[72, '6 dernières heures'], [288, '24 dernières heures'], [576, '48 dernières heures'], [1152, '4 derniers jours']].map(w => `<option value="${w[0]}" ${h.win === w[0] ? 'selected' : ''}>${w[1]}</option>`).join('')}</select></div></div>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
          <button data-action="export-csv">Exporter CSV</button><button data-action="export-json">Exporter JSON</button>
          <button class="primary" data-action="print-report">Rapport médical PDF (imprimer / enregistrer en PDF)</button></div>
        <div class="hint">« Rapport PDF » ouvre la fenêtre d’impression du navigateur : choisissez « Enregistrer au format PDF ».</div></div>
      <div class="grid g2" style="margin-top:14px"><div class="card"><h3>Synthèse</h3><div id="h-sum"></div></div><div class="card"><h3>Courbe</h3><canvas class="chart" id="h-chart"></canvas></div></div>
      <div class="card" style="margin-top:14px"><h3>Données (200 dernières lignes de la période)</h3><div id="h-table" style="max-height:420px;overflow:auto"></div></div>`;
    },
    update() {
      if (S.t - ui.histTick < 6 && ui.histTick >= 0) return;
      ui.histTick = S.t;
      const h = ui.hist, e = lag();
      let rows = A.seriesFor(h.astro, h.param, h.win + e);
      if (e) rows = rows.slice(0, rows.length - e);
      const vals = rows.map(r => r.v).filter(isFinite);
      const P = h.param.indexOf('env:') === 0 ? A.ENVP[h.param.split(':')[2]] : A.PARAMS[h.param], dec = P.dec || 0;
      $('#h-sum').innerHTML = vals.length ? `<dl class="kv"><dt>Mesures valides</dt><dd>${vals.length} / ${rows.length}</dd><dt>Minimum</dt><dd>${fmt(Math.min(...vals), dec)} ${P.unit}</dd><dt>Moyenne</dt><dd>${fmt(A.mean(vals), dec)} ${P.unit}</dd><dt>Maximum</dt><dd>${fmt(Math.max(...vals), dec)} ${P.unit}</dd><dt>Écart-type</dt><dd>${fmt(A.sd(vals), dec + 1)}</dd></dl>` : '<div class="muted">Aucune donnée.</div>';
      drawChart($('#h-chart'), { xs: rows.map(r => r.t), series: [{ ys: rows.map(r => r.v), color: '#5aa9ff' }], dec });
      $('#h-table').innerHTML = `<table><thead><tr><th>Heure</th><th>Valeur</th><th>Qualité</th></tr></thead><tbody>${rows.slice(-200).reverse().map(r => `<tr><td>${A.fmtTime(r.t)}</td><td>${isFinite(r.v) ? fmt(r.v, dec + 1) + ' ' + P.unit : '—'}</td><td>${r.q}</td></tr>`).join('')}</tbody></table>`;
    }
  };

  function buildReport(id, win) {
    const a = S.crew[id], e = endIdx(a), s = Math.max(0, e - win), H = a.hist;
    const t0 = H.t[s], t1 = H.t[e - 1];
    const stat = p => { const v = H[p].slice(s, e).filter(isFinite); return v.length ? [Math.min(...v), A.mean(v), Math.max(...v)] : null; };
    const B = a.baseline && a.baseline[1];
    const al = visAlerts().filter(x => x.astronautId === id && x.createdTick >= t0);
    const reps = S.reports.filter(r => r.astronautId === id && r.tick >= t0);
    const meds = S.meds.filter(m => m.astronautId === id);
    return `<h1>ASTRA-MED — Rapport médical de synthèse</h1>
      <div>Astronaute : <b>${esc(a.name)}</b> (${a.code}) · ${esc(a.role)} · ${esc(A.MODULES[a.module])}</div>
      <div>Période : ${A.fmtTime(t0)} → ${A.fmtTime(t1)} (temps de mission) · édité par ${esc(user.username)} (${A.ROLE_LABEL[user.role]}) le ${new Date().toLocaleString('fr-FR')}</div>
      <div class="disc"><b>Prototype expérimental non certifié.</b> Données simulées. Document d’aide à la décision : il ne constitue ni un diagnostic ni une prescription.</div>
      <h2>Signes vitaux sur la période</h2>
      <table><tr><th>Paramètre</th><th>Min</th><th>Moyenne</th><th>Max</th><th>Ligne de base au repos</th></tr>
      ${A.VITALS.map(p => { const st = stat(p); return `<tr><td>${A.PARAMS[p].label} (${A.PARAMS[p].unit})</td>${st ? st.map(x => '<td>' + fmt(x, A.PARAMS[p].dec) + '</td>').join('') : '<td colspan="3">—</td>'}<td>${B && B[p] ? fmt(B[p].c, A.PARAMS[p].dec) + ' ± ' + fmt(B[p].s, A.PARAMS[p].dec + 1) : '—'}</td></tr>`; }).join('')}</table>
      <h2>Sommeil (dernières nuits)</h2><div>${a.sleepHist.filter(x => x.t >= 0).slice(-5).map(x => A.fmtTime(x.t) + ' : ' + fmt(x.h, 1) + ' h').join(' · ') || '—'}</div>
      <h2>Alertes (${al.length})</h2>
      ${al.length ? `<table><tr><th>#</th><th>Heure</th><th>Niveau</th><th>Règle</th><th>Synthèse</th><th>Statut</th></tr>${al.map(x => `<tr><td>${x.id}</td><td>${A.fmtTime(x.createdTick)}</td><td>${LV[x.level].label}</td><td>${x.rule}</td><td>${esc(x.summary)}${x.notes.length ? '<br><i>Notes : ' + x.notes.map(n => esc(n.who + ' — ' + n.text)).join(' | ') + '</i>' : ''}</td><td>${statusLabel(x.status)}</td></tr>`).join('')}</table>` : '<div>Aucune alerte sur la période.</div>'}
      <h2>Auto-évaluations</h2>
      ${reps.length ? `<table><tr><th>Heure</th><th>Fatigue</th><th>Humeur</th><th>Stress</th><th>Symptômes</th></tr>${reps.map(r => `<tr><td>${A.fmtTime(r.tick)}</td><td>${r.fatigue}</td><td>${r.mood}</td><td>${r.stress}</td><td>${esc(r.symptoms.join(', ') || '—')}</td></tr>`).join('')}</table>` : '<div>Aucune.</div>'}
      <h2>Traitements</h2><div>${meds.length ? meds.map(m => esc(m.name + ' ' + m.dose + ' (' + m.sched + ') — ' + m.taken.length + ' prise(s)')).join('<br>') : 'Aucun.'}</div>`;
  }

  /* Communication */
  views.comm = {
    render() {
      return `<div class="grid g2">
        <div class="card"><h3>Liaison</h3><div id="c-state"></div>
          ${canAct() ? '<div style="margin-top:12px"><button data-action="toggle-link" id="c-btn"></button></div>' : ''}
          <div class="hint">En cas de coupure, la surveillance, la détection et les alertes continuent à bord. Les données sont mises en file persistante puis envoyées par lots, avec identifiants uniques (idempotence), à la reprise.</div></div>
        <div class="card"><h3>Indicateurs de synchronisation</h3><div id="c-stats"></div></div></div>
      <div class="card" style="margin-top:14px"><h3>Journal de la liaison</h3><div id="c-log"></div></div>`;
    },
    update() {
      const C = S.comm;
      const pct = C.catchup && C.flushStartQueue ? Math.round((1 - C.queue / C.flushStartQueue) * 100) : (C.online ? 100 : 0);
      $('#c-state').innerHTML = `<div style="font-size:20px;margin-bottom:8px">${C.online ? (C.catchup ? '🟡 Rattrapage en cours' : '🟢 Liaison active') : '🔴 Liaison coupée — mode autonome'}</div>
        <div class="bar"><i style="width:${pct}%"></i></div><div class="muted small" style="margin-top:4px">${C.catchup ? 'Synchronisation : ' + pct + ' %' : C.online ? 'Aucune donnée en attente' : 'Données mises en file : ' + C.queue + ' enregistrements (≈ ' + A.fmtDur((C.queue / 57) * A.TICK_MIN) + ' de mission)'}</div>`;
      const btn = $('#c-btn'); if (btn) btn.textContent = C.online ? 'Couper la liaison (simulation S7)' : 'Rétablir la liaison';
      $('#c-stats').innerHTML = `<dl class="kv">
        <dt>Enregistrements générés</dt><dd>${C.generated}</dd><dt>Reçus par la Terre</dt><dd>${C.received}</dd><dt>En file d’attente</dt><dd>${C.queue}</dd>
        <dt>Taux de perte de données</dt><dd><b>${fmt(A.lossRate() * 100, 2)} %</b></dd>
        <dt>Dernier temps de synchro</dt><dd>${C.lastDuration != null ? fmt(C.lastDuration, 1) + ' s (débit simulé : 2 000 enr./s)' : '—'}</dd>
        <dt>Coupures simulées</dt><dd>${C.outages}</dd></dl>`;
      $('#c-log').innerHTML = C.log.length ? C.log.slice(0, 15).map(l => `<div class="small"><span class="muted">${A.fmtTime(l.tick)}</span> — ${esc(l.text)}</div>`).join('') : '<div class="muted">Aucun événement.</div>';
    }
  };

  /* Évaluation */
  views.eval = {
    render() {
      return `<div class="card"><h3>Banc d’essai reproductible (hypothèses H1, H2, H5)</h3>
        <p class="muted" style="margin-top:0">Compare quatre détecteurs sur des profils simulés (50 % de cas nominaux, 50 % d’anomalies injectées : dérive discrète, cardiaque, respiratoire, CO₂). Une alarme = 2 pas consécutifs au-dessus du seuil (10 min). Tout est calculé ici, dans le navigateur, avec une graine fixe.</p>
        <div style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
          <div><label style="margin-top:0">Profils simulés</label><select id="ev-n"><option>100</option><option selected>200</option><option>400</option><option>1000</option></select></div>
          <div><label style="margin-top:0">Graine aléatoire</label><input type="text" id="ev-seed" value="7" style="width:90px"></div>
          <button class="primary" data-action="run-bench">Lancer l’expérience</button></div>
        <div class="hint">Limite : les anomalies sont synthétiques et d’amplitude connue ; ces performances sont donc optimistes et ne préjugent pas du comportement sur des données réelles.</div>
        <div id="ev-res" style="margin-top:12px"></div></div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card"><h3>Mesures en direct (scénarios injectés)</h3><div id="ev-live"></div></div>
        <div class="card"><h3>Hypothèses</h3><div id="ev-hyp"></div></div></div>`;
    },
    update() {
      const L = S.latencies.slice().reverse().slice(0, 10);
      $('#ev-live').innerHTML = `<dl class="kv"><dt>Alertes générées</dt><dd>${S.alerts.length}</dd><dt>Valeurs rejetées (QC)</dt><dd>${S.qcRejected}</dd><dt>Perte de données</dt><dd>${fmt(A.lossRate() * 100, 2)} %</dd></dl>
        <h3 style="margin-top:12px">Latence de détection</h3>${L.length ? `<table><thead><tr><th>Scénario</th><th>Astronaute</th><th>Latence</th><th>Règle</th></tr></thead><tbody>${L.map(l => `<tr><td>${l.scenario}</td><td>${esc(l.astronaut)}</td><td>${l.minutes} min</td><td>${l.rule}</td></tr>`).join('')}</tbody></table>` : '<div class="muted small">Injectez un scénario (détail astronaute) pour mesurer la latence entre le début de l’anomalie et la première alerte.</div>'}`;
      const b = ui.bench, m = b && b.metrics;
      const h = (t, ok, txt) => `<tr><td><b>${t}</b></td><td>${ok === null ? '<span class="tag">à observer</span>' : ok ? '<span class="tag lv-ok">cohérente avec les résultats</span>' : '<span class="tag lv-vigilance">non confirmée</span>'}</td><td class="small">${txt}</td></tr>`;
      $('#ev-hyp').innerHTML = `<table><tbody>
        ${h('H1 · multi-paramètres', m ? (m.C.f1 > m.B.f1 && m.C.f1 > m.A.f1) : null, m ? 'F1 : C = ' + fmt(m.C.f1, 2) + ' · B = ' + fmt(m.B.f1, 2) + ' · A = ' + fmt(m.A.f1, 2) : 'Lancez l’expérience.')}
        ${h('H2 · ligne de base individuelle', m ? (m.B.prec >= m.A.prec && m.B.spec >= m.A.spec) : null, m ? 'Précision B = ' + fmt(m.B.prec, 2) + ' vs A = ' + fmt(m.A.prec, 2) + ' ; spécificité B = ' + fmt(m.B.spec, 2) + ' vs A = ' + fmt(m.A.spec, 2) : 'Lancez l’expérience.')}
        ${h('H3 · charge cognitive', null, 'Nécessite des tests avec de vrais utilisateurs (hors périmètre du prototype).')}
        ${h('H4 · autonomie hors ligne', S.comm.outages ? A.lossRate() === 0 : null, S.comm.outages ? 'Perte observée : ' + fmt(A.lossRate() * 100, 2) + ' % après ' + S.comm.outages + ' coupure(s) simulée(s).' : 'Coupez la liaison dans « Communication Terre ».')}
        ${h('H5 · données environnementales', m ? (isFinite(m.D.lat) && isFinite(m.C.lat) && m.D.lat < m.C.lat) : null, m ? 'Latence moyenne D = ' + fmt(m.D.lat, 0) + ' min vs C = ' + fmt(m.C.lat, 0) + ' min' : 'Lancez l’expérience.')}
      </tbody></table>`;
      if (b && ui.benchHtml !== b) { ui.benchHtml = b; $('#ev-res').innerHTML = benchHtml(b); }
    }
  };
  function benchHtml(b) {
    const m = b.metrics, names = Object.keys(m);
    const nAnom = m.A.tp + m.A.fn, nNorm = m.A.tn + m.A.fp;
    return `<div class="small muted">${b.N} profils (${nNorm} nominaux, ${nAnom} avec anomalie) · graine ${b.seed}</div>
      <table><thead><tr><th>Détecteur</th><th>Sensibilité</th><th>Spécificité</th><th>Précision</th><th>F1</th><th>Latence moy.</th><th>VP/FP/VN/FN</th></tr></thead><tbody>
      ${names.map(n => `<tr><td>${A.DETECTORS[n]}</td><td>${fmt(m[n].sens, 2)}</td><td>${fmt(m[n].spec, 2)}</td><td>${fmt(m[n].prec, 2)}</td><td><b>${fmt(m[n].f1, 2)}</b></td><td>${isFinite(m[n].lat) ? fmt(m[n].lat, 0) + ' min' : '—'}</td><td class="mono">${m[n].tp}/${m[n].fp}/${m[n].tn}/${m[n].fn}</td></tr>`).join('')}</tbody></table>
      <h3 style="margin-top:14px">Sensibilité par type d’anomalie</h3>
      <table><thead><tr><th>Type</th><th>Cas</th>${names.map(n => '<th>' + n + '</th>').join('')}</tr></thead><tbody>
      ${Object.keys(A.ANOM_TYPES).map(t => `<tr><td>${A.ANOM_TYPES[t]}</td><td>${b.byType[t].n}</td>${names.map(n => `<td>${b.byType[t].n ? Math.round(b.byType[t][n] / b.byType[t].n * 100) + ' %' : '—'}</td>`).join('')}</tr>`).join('')}</tbody></table>
      <h3 style="margin-top:14px">F1-score</h3>${names.map(n => `<div class="bars"><div class="nm">${A.DETECTORS[n]}</div><div class="bar"><i style="width:${Math.round(m[n].f1 * 100)}%"></i></div><b>${fmt(m[n].f1, 2)}</b></div>`).join('')}`;
  }

  /* Administration */
  views.admin = {
    render() { return `<div class="grid g2"><div class="card"><h3>Comptes</h3><div id="ad-users"></div></div><div class="card"><h3>Capteurs</h3><div id="ad-sens"></div></div></div>
      <div class="card" style="margin-top:14px"><h3>Journal d’audit (chaîné par empreintes)</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px"><button data-action="verify-audit">Vérifier l’intégrité</button><button class="danger" data-action="tamper">Simuler une altération</button><button data-action="export-audit">Exporter le journal</button><span id="ad-verify" style="align-self:center"></span></div>
        <div id="ad-log" style="max-height:380px;overflow:auto"></div>
        <div class="hint">Chaque entrée contient l’empreinte de la précédente : toute modification a posteriori est détectée. Démonstration avec un hachage non cryptographique ; en production : SHA-256 signé.</div></div>
      <div class="card" style="margin-top:14px"><h3>Sécurité : ce que fait ce prototype, et ce qu’il ne fait pas</h3>
        <ul class="small"><li><b>Implémenté (démo)</b> : authentification, MFA simulé, verrouillage après 5 échecs, déconnexion après 15 min d’inactivité, rôles et droits, journal d’audit chaîné, rejet des données aberrantes.</li>
        <li><b>Non implémenté ici</b> : chiffrement TLS/AES-256, OAuth 2.0 réel, base de données serveur. Ce prototype tourne entièrement dans le navigateur ; ces éléments figurent dans l’architecture cible (voir documentation).</li></ul></div>`; },
    update() {
      const key = S.audit.length + '-' + S.audit.length + '-' + A.users.map(u => u.active + '' + u.mfa).join('') + '-' + S.crew.map(a => a.missing.hr + a.missing.spo2 + a.missing.rr).join('');
      if (ui.lastAlertVer === key && S.t % 6) return; ui.lastAlertVer = key;
      $('#ad-users').innerHTML = `<table><thead><tr><th>Compte</th><th>Rôle</th><th>MFA</th><th>Actif</th></tr></thead><tbody>${A.users.map((u, i) => `<tr><td>${esc(u.username)}</td><td>${A.ROLE_LABEL[u.role]}</td><td><button class="small" data-action="toggle-mfa" data-id="${i}">${u.mfa ? 'Oui' : 'Non'}</button></td><td><button class="small" data-action="toggle-user" data-id="${i}" ${u.username === user.username ? 'disabled' : ''}>${u.active ? 'Oui' : 'Non'}</button></td></tr>`).join('')}</tbody></table>`;
      $('#ad-sens').innerHTML = `<table><thead><tr><th>Astronaute</th>${A.VITALS.map(p => '<th>' + A.PARAMS[p].short + '</th>').join('')}</tr></thead><tbody>${S.crew.map(a => `<tr><td>${esc(a.name)}</td>${A.VITALS.map(p => `<td>${a.missing[p] >= 2 ? '<span class="tag lv-technical">HS</span>' : '<span class="tag lv-ok">OK</span>'}</td>`).join('')}</tr>`).join('')}</tbody></table><div class="hint">HS = hors service (≥ 2 pas sans signal). Valeurs rejetées au total : ${S.qcRejected}.</div>`;
      $('#ad-log').innerHTML = `<table><thead><tr><th>#</th><th>Heure réelle</th><th>Acteur</th><th>Action</th><th>Cible</th><th>Détails</th><th>Empreinte</th></tr></thead><tbody>${S.audit.slice(-120).reverse().map(e => `<tr><td>${e.i}</td><td class="mono">${e.real.slice(11, 19)}</td><td>${esc(e.actor)}</td><td>${esc(e.action)}</td><td>${esc(e.target)}</td><td class="small">${esc(e.details)}</td><td class="mono muted">${e.hash.slice(0, 10)}</td></tr>`).join('')}</tbody></table>`;
    }
  };

  /* Documentation */
  views.docs = {
    render() {
      return `<div class="card"><h2>ASTRA-MED — prototype exécutable du cahier des charges v2.0</h2>
      <p>Ce logiciel démontre, sans rien installer, le fonctionnement du système décrit dans le cahier des charges : surveillance de six astronautes simulés, détection d’anomalies, alertes explicables, autonomie hors ligne et évaluation chiffrée.</p>
      <h3>Parcours de démonstration conseillé</h3><ol>
        <li>Connexion « Médecin de bord » (code MFA 123456).</li>
        <li>Dans « Détail astronaute », injectez <b>S3 · Anomalie cardiaque</b> et passez en vitesse ×5 : une alerte apparaît avec son explication complète.</li>
        <li>Injectez <b>S4</b> sur le même astronaute : l’alerte « Urgence potentielle » (R06) apparaît.</li>
        <li>Injectez <b>S6</b> (panne capteur) : alerte technique, aucune alerte médicale.</li>
        <li>« Communication Terre » : coupez la liaison, laissez tourner, rétablissez-la : synchronisation sans perte.</li>
        <li>Connectez-vous en « Centre terrestre » pour voir des données figées pendant la coupure.</li>
        <li>« Évaluation » : lancez le banc d’essai ; « Historique » : exportez un rapport PDF.</li></ol>
      <h3>Échelle de temps</h3><p>1 pas = 5 minutes de mission (×1 : 2 pas/s). Règles de durée : R01 = 2 pas consécutifs (10 min) ; R05 = 2 pas sans signal. Le bouton « +1 jour » avance de 24 h.</p>
      <h3>Moteur d’analyse</h3><p>Ligne de base individuelle (médiane et écart absolu médian, séparée sommeil / éveil au repos) ; règles R01 à R06 ; Isolation Forest sur les écarts normalisés ; contrôle qualité (rejet des valeurs impossibles, détection de capteur muet).</p>
      <h3>Documents du projet (dossier <code>docs/</code>)</h3><ul>
        ${[['01_cahier_des_charges_ASTRA-MED_v2.md', 'Cahier des charges v2.0'], ['02_matrice_tracabilite.md', 'Matrice de traçabilité'], ['03_regles_alerte_et_algorithmes.md', 'Règles d’alerte et algorithmes'], ['04_diagrammes_UML.md', 'Diagrammes UML'], ['05_schema_base_de_donnees.sql', 'Schéma de base de données'], ['06_plan_tests.md', 'Plan de tests'], ['07_risques.md', 'Registre des risques'], ['08_planning_budget.md', 'Planning et budget'], ['09_bibliographie.md', 'Bibliographie']].map(d => `<li><a href="docs/${d[0]}" target="_blank" rel="noopener">${d[1]}</a></li>`).join('')}</ul>
      <div class="disclaimer"><b>Limites.</b> Prototype expérimental non certifié, non qualifié pour un usage médical ou spatial. Données et anomalies simulées. Seuils à valider avec des professionnels de santé. Ajouts par rapport aux règles du cahier des charges : seuil de sécurité SpO₂ &lt; 90 % (R02) et règle environnementale ENV1.</div></div>`;
    }
  };

  /* ---------- Actions ---------- */
  const actions = {
    'fill': el => { $('#l-user').value = el.dataset.u; $('#l-pass').value = el.dataset.p; },
    'login': () => {
      const r = A.login($('#l-user').value.trim(), $('#l-pass').value);
      if (!r.ok) return renderLogin(r.error);
      if (r.needMfa) { pending = r.user; return renderLogin('', true); }
      startSession(r.user);
    },
    'mfa': () => {
      if ($('#l-mfa').value.trim() === A.MFA_CODE) { const u = pending; pending = null; startSession(u); }
      else { A.auditLog('MFA_ECHEC', pending.username, '', { actor: pending.username }); renderLogin('Code incorrect.', true); }
    },
    'login-back': () => { pending = null; renderLogin(''); },
    'logout': () => logout(),
    'nav': el => go(el.dataset.v),
    'open-astro': el => { ui.sel = +el.dataset.id; ui.hist.astro = ui.sel; go('astro'); },
    'open-alert': el => openAlert(+el.dataset.id),
    'close-modal': closeModal,
    'ack': el => { A.ackAlert(+el.dataset.id); openAlert(+el.dataset.id); dirty = true; },
    'escalate': el => { A.escalateAlert(+el.dataset.id); openAlert(+el.dataset.id); dirty = true; },
    'close-alert': el => { A.closeAlert(+el.dataset.id); closeModal(); dirty = true; },
    'add-note': el => { const t = $('#al-note').value.trim(); if (!t) return; A.addNote(+el.dataset.id, t); openAlert(+el.dataset.id); },
    'speed': el => { S.speed = +el.dataset.v; dirty = true; },
    'pause': () => { S.running = !S.running; A.auditLog(S.running ? 'SIMULATION_REPRISE' : 'SIMULATION_PAUSE', ''); dirty = true; },
    'day': () => { A.advanceDay(); toast('Simulation avancée de 24 h', 'info'); dirty = true; },
    'win': el => { ui.win = +el.dataset.v; go('astro'); },
    'scenario': el => { if (!canAct()) return; A.scenario(el.dataset.id, ui.sel); toast(A.SCENARIOS[el.dataset.id].label + ' — injecté sur ' + S.crew[ui.sel].name, 'info'); dirty = true; },
    'envmod': el => { ui.envMod = +el.dataset.v; go('env'); },
    'scenario-env': () => { const a = S.crew.find(c => c.module === ui.envMod); if (a && canAct()) { A.scenario('S5', a.id); toast('S5 injecté dans « ' + A.MODULES[ui.envMod] + ' »', 'info'); } },
    'env-reset': () => { if (canAct()) { S.env.mods.forEach(m => { m.tgt.co2 = 0; m.tgt.temp = 0; m.tgt.rad = 0; }); A.auditLog('ENVIRONNEMENT_RETABLI', 'modules', ''); } },
    'submit-report': () => {
      const id = user.role === 'astronaut' ? user.astronautId : ui.repAstro;
      A.addReport({ astronautId: id, fatigue: +$('#r-fatigue').value, mood: +$('#r-mood').value, stress: +$('#r-stress').value, symptoms: $$('.sy:checked').map(x => x.value), notes: $('#r-notes').value.trim() });
      toast('Auto-évaluation enregistrée', 'info'); $$('.sy').forEach(x => (x.checked = false)); $('#r-notes').value = ''; ui.lastAlertVer = -1; dirty = true;
    },
    'add-med': () => {
      const n = $('#m-name').value.trim(); if (!n) return;
      A.addMed({ astronautId: user.role === 'astronaut' ? user.astronautId : ui.repAstro, name: n, dose: $('#m-dose').value.trim(), sched: $('#m-sched').value.trim() || '—', taken: [] });
      ['#m-name', '#m-dose', '#m-sched'].forEach(s => ($(s).value = '')); ui.lastAlertVer = -1; dirty = true;
    },
    'take-med': el => { A.takeMed(+el.dataset.id); ui.lastAlertVer = -1; dirty = true; },
    'export-csv': () => {
      const h = ui.hist, e = lag(); let rows = A.seriesFor(h.astro, h.param, h.win + e); if (e) rows = rows.slice(0, rows.length - e);
      download('astra-med_' + S.crew[h.astro].code + '_' + h.param.replace(/:/g, '-') + '.csv', 'temps_mission;valeur;qualite\n' + rows.map(r => A.fmtTime(r.t) + ';' + (isFinite(r.v) ? String(r.v).replace('.', ',') : '') + ';' + r.q).join('\n'), 'text/csv;charset=utf-8');
      A.auditLog('EXPORT_CSV', S.crew[h.astro].code, h.param);
    },
    'export-json': () => {
      const h = ui.hist, e = lag(); let rows = A.seriesFor(h.astro, h.param, h.win + e); if (e) rows = rows.slice(0, rows.length - e);
      download('astra-med_' + S.crew[h.astro].code + '_' + h.param.replace(/:/g, '-') + '.json', JSON.stringify({ astronaut: S.crew[h.astro].code, parameter: h.param, data: rows.map(r => ({ t: A.fmtTime(r.t), v: isFinite(r.v) ? r.v : null, q: r.q })) }, null, 1), 'application/json');
      A.auditLog('EXPORT_JSON', S.crew[h.astro].code, h.param);
    },
    'print-report': () => {
      $('#printReport').innerHTML = buildReport(ui.hist.astro, ui.hist.win);
      A.auditLog('RAPPORT_PDF', S.crew[ui.hist.astro].code, 'fenêtre ' + ui.hist.win + ' pas');
      setTimeout(() => window.print(), 50);
    },
    'toggle-link': () => { if (canAct()) { A.setLink(!S.comm.online, 'action manuelle'); dirty = true; } },
    'run-bench': () => {
      const n = +$('#ev-n').value, seed = parseInt($('#ev-seed').value, 10) || 7;
      $('#ev-res').innerHTML = '<div class="muted">Calcul en cours…</div>';
      setTimeout(() => { ui.bench = A.runBenchmark(n, seed); ui.benchHtml = null; A.auditLog('BANC_ESSAI', 'N=' + n, 'graine ' + seed); dirty = true; }, 30);
    },
    'verify-audit': () => { const r = A.verifyAudit(); $('#ad-verify').innerHTML = r.ok ? '<span class="tag lv-ok">Intègre — ' + r.total + ' entrées vérifiées</span>' : '<span class="tag lv-emergency">ALTÉRATION détectée à l’entrée #' + r.brokenAt + '</span>'; },
    'tamper': () => { const i = A.tamperAudit(); toast(i ? 'Entrée #' + i + ' modifiée : vérifiez maintenant l’intégrité' : 'Journal trop court', 'vigilance'); ui.lastAlertVer = -1; },
    'export-audit': () => download('astra-med_audit.json', JSON.stringify(S.audit, null, 1), 'application/json'),
    'toggle-user': el => { const u = A.users[+el.dataset.id]; u.active = !u.active; A.auditLog('COMPTE_' + (u.active ? 'ACTIVE' : 'DESACTIVE'), u.username, ''); ui.lastAlertVer = -1; dirty = true; },
    'toggle-mfa': el => { const u = A.users[+el.dataset.id]; u.mfa = !u.mfa; A.auditLog('MFA_' + (u.mfa ? 'ACTIVE' : 'DESACTIVE'), u.username, ''); ui.lastAlertVer = -1; dirty = true; }
  };
  const changes = {
    'sel-astro': el => { ui.sel = +el.value; ui.hist.astro = ui.sel; ui.lastAlertVer = -1; dirty = true; },
    'f-level': el => { ui.fAlert.level = el.value; dirty = true; },
    'f-status': el => { ui.fAlert.status = el.value; dirty = true; },
    'f-astro': el => { ui.fAlert.astro = el.value; dirty = true; },
    'rep-astro': el => { ui.repAstro = +el.value; ui.lastAlertVer = -1; dirty = true; },
    'h-astro': el => { ui.hist.astro = +el.value; ui.histTick = -99; dirty = true; },
    'h-param': el => { ui.hist.param = el.value; ui.histTick = -99; dirty = true; },
    'h-win': el => { ui.hist.win = +el.value; ui.histTick = -99; dirty = true; }
  };

  document.addEventListener('click', e => {
    lastActivity = Date.now();
    const t = e.target;
    if (t.id === 'modal') return closeModal();
    const el = t.closest && t.closest('[data-action]');
    if (el && actions[el.dataset.action]) actions[el.dataset.action](el, e);
  });
  document.addEventListener('change', e => { lastActivity = Date.now(); const el = e.target.closest && e.target.closest('[data-change]'); if (el && changes[el.dataset.change]) changes[el.dataset.change](el); });
  document.addEventListener('input', e => { const r = e.target.dataset && e.target.dataset.range; if (r) $('#v-' + r).textContent = e.target.value; });
  document.addEventListener('keydown', e => {
    lastActivity = Date.now();
    if (e.key === 'Enter') { if (document.activeElement && (document.activeElement.id === 'l-user' || document.activeElement.id === 'l-pass')) actions.login(); else if (document.activeElement && document.activeElement.id === 'l-mfa') actions.mfa(); }
    if (e.key === 'Escape' && !$('#modal').hidden) closeModal();
  });
  window.addEventListener('resize', () => { dirty = true; });

  /* ---------- Boucles ---------- */
  function loop() { requestAnimationFrame(loop); frame(false); }
  function frame(force) {
    if (!user || (!dirty && !force)) return;
    dirty = false;
    try { topbarUpdate(); if (views[view].update) views[view].update(); } catch (err) { console.error(err); }
  }
  function simLoop() {
    if (S.ready && S.running) { A.step(); dirty = true; }
    setTimeout(simLoop, Math.max(20, 500 / S.speed));
  }
  setInterval(() => { A.flushStep(); if (S.comm.catchup) dirty = true; }, 200);
  setInterval(() => { if (user && Date.now() - lastActivity > 15 * 60 * 1000) logout('Session expirée après 15 min d’inactivité.'); }, 10000);

  A.init();
  renderLogin('');
  requestAnimationFrame(loop);
  simLoop();
  window.ASTRA_UI = { go, get view() { return view; } };   // utile pour les tests
})();
