# ASTRA-MED — Plan de tests

## 1. Scénarios expérimentaux

| ID | Scénario | Données injectées | Résultat attendu |
|---|---|---|---|
| S1 | État normal | Signes vitaux stables | Aucune alerte |
| S2 | Fatigue progressive | Sommeil dégradé, activité réduite, fatigue déclarée | Alerte de vigilance |
| S3 | Anomalie cardiaque | FC anormale, ECG modifié | Alerte médicale |
| S4 | Dégradation respiratoire | Baisse SpO2, modification respiratoire | Alerte médicale prioritaire |
| S5 | Environnement dégradé | Hausse CO2 et température | Alerte environnementale |
| S6 | Panne de capteur | Données manquantes ou incohérentes | Alerte technique, pas d'alerte médicale |
| S7 | Perte de communication | Coupure réseau | Fonctionnement local, synchronisation différée |
| S8 | Fausse donnée | Valeur aberrante | Rejet / quarantaine |

## 2. Tests unitaires, d'intégration et système

| ID | Exigence | Description | Critère de réussite |
|---|---|---|---|
| T01 | F01 | Connexion valide avec MFA | Accès accordé |
| T02 | F01 | Mot de passe erroné x5 | Compte temporairement verrouillé |
| T03 | F02 | Astronaute tente d'accéder aux données d'un autre | Refus, audit enregistré |
| T04 | F03 | Création/modification d'un profil | Données persistées |
| T05 | F04 | Flux de signes vitaux simulés | 100 % des messages stockés |
| T06 | F05 | Données de sommeil | Score de sommeil calculé |
| T07 | F06 | Flux environnemental | Données affichées et stockées |
| T08 | F07 | Valeur hors plage physiologique | Marquée `rejected` |
| T09 | F07 | Capteur silencieux > 60 s | Alerte technique R05 |
| T10 | F08 | Calcul de ligne de base sur 14 jours | Plage cohérente avec les données |
| T11 | F09 | S3 | Détection, latence ≤ 10 s (règles) |
| T12 | F09 | S2 | Détection de dérive ≤ 60 s après fenêtre d'analyse |
| T13 | F10 | S1 à S6 | Niveau d'alerte conforme au tableau |
| T14 | F11 | Ouverture d'une alerte | Tous les champs d'explicabilité renseignés |
| T15 | F12 | Dashboard avec 6 astronautes | Rafraîchissement ≤ 2 s |
| T16 | F13 | Filtre par date et paramètre | Résultats exacts |
| T17 | F14 | Export PDF | Fichier lisible, contenu conforme |
| T18 | F15 | S7 : coupure 24 h | Surveillance locale continue |
| T19 | F15 | Reconnexion | 0 % de perte, sync ≤ 5 min |
| T20 | F16 | Saisie auto-évaluation | Enregistrée et visible au médecin |
| T21 | F17 | Action sensible | Entrée d'audit chaînée |
| T22 | N01 | Mesure → affichage | ≤ 2 s |
| T23 | N03 | Exécution continue 72 h | Disponibilité ≥ 99,5 % |
| T24 | N05 | Inspection TLS et chiffrement au repos | Conforme |
| T25 | N07 | Export/suppression de données personnelles | Fonctionnel |
| T26 | N09 | Test utilisateur sur 5+ participants | ≥ 85 % comprennent l'alerte |
| T27 | N10 | `docker compose up` sur machine neuve | Système opérationnel |

## 3. Indicateurs d'évaluation

| Indicateur | Formule | Objectif |
|---|---|---|
| Sensibilité | VP / (VP + FN) | Détecter les anomalies réelles |
| Spécificité | VN / (VN + FP) | Éviter les fausses alertes |
| Précision | VP / (VP + FP) | Qualité des alertes |
| F1-score | 2·P·R / (P + R) | Équilibre global |
| Latence de détection | t(alerte) − t(début anomalie) | Réactivité |
| Disponibilité | Temps de fonctionnement / temps total | Fiabilité |
| Perte de données | Perdues / générées | Robustesse |
| Temps de synchronisation | Durée après reconnexion | Performance réseau |

## 4. Évaluation des hypothèses

| Hypothèse | Comparaison | Mesure |
|---|---|---|
| H1 | Multi-paramètres vs paramètre unique | Latence de détection, F1 |
| H2 | Ligne de base individuelle vs seuils généraux | Précision, spécificité |
| H3 | Avec vs sans priorisation | Alertes présentées, alertes manquées, temps de traitement |
| H4 | Avec vs sans liaison Terre | Détections maintenues, perte de données |
| H5 | Avec vs sans données environnementales | F1, faux positifs |
