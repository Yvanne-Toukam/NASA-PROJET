# ASTRA-MED — Cahier des charges (version finale 2.0)

**Titre académique :** Conception d'un système intelligent de surveillance de la santé des astronautes en mission spatiale
**Statut :** Prototype expérimental non certifié — ce n'est pas un dispositif médical spatial qualifié.
**Version :** 2.0 — 14/11/2026

> Note : ce document a été reconstruit à partir de l'analyse de la documentation ASTRA-MED fournie. Les valeurs numériques (seuils, délais, budget) sont des propositions à valider avec des professionnels de santé et votre encadrant.

---

## Table des matières

1. Introduction et contexte
2. Problématique, objectifs, hypothèses
3. Périmètre
4. Acteurs et parties prenantes
5. Exigences fonctionnelles (F01–F17)
6. Exigences non fonctionnelles (N01–N10)
7. Architecture technique
8. Modules du système
9. Cas d'utilisation (résumé)
10. Interfaces (maquettes textuelles)
11. Sécurité, confidentialité, fiabilité
12. Méthodologie expérimentale
13. MVP et livrables
14. Contraintes, hypothèses de travail, limites
15. Documents associés
16. Abréviations

---

## 1. Introduction et contexte

Lors d'une mission spatiale de longue durée, l'équipage est exposé à la microgravité, aux rayonnements, au confinement, à la dégradation du sommeil et à une communication retardée ou interrompue avec la Terre. Le médecin de bord doit pouvoir s'appuyer sur un outil qui collecte, analyse et surveille en continu les données de santé, **même sans liaison terrestre**.

ASTRA-MED est un logiciel d'**assistance** à la décision médicale. Il ne pose pas de diagnostic et ne prescrit pas de traitement : il détecte, hiérarchise et explique des anomalies, la décision restant humaine.

## 2. Problématique, objectifs, hypothèses

### 2.1 Problématique

Comment concevoir et évaluer un système logiciel intelligent, sécurisé et autonome capable de collecter, fusionner et analyser en temps réel les données physiologiques, comportementales, cognitives et environnementales d'un équipage spatial, afin de détecter précocement les anomalies de santé, de générer des alertes hiérarchisées et d'assister le médecin de bord et le centre médical terrestre dans la prise de décision ?

### 2.2 Objectifs

- **O1** Collecter et stocker les données de santé et d'environnement en continu.
- **O2** Détecter les anomalies à partir d'une ligne de base individuelle.
- **O3** Générer des alertes hiérarchisées et explicables.
- **O4** Fonctionner en autonomie complète pendant une perte de communication.
- **O5** Synchroniser les données avec le centre de supervision terrestre après reconnexion.
- **O6** Évaluer les performances par des indicateurs chiffrés.

### 2.3 Hypothèses testables

| ID | Hypothèse |
|---|---|
| H1 | La combinaison de plusieurs indicateurs (FC, sommeil, activité, fatigue, environnement) détecte plus tôt une dégradation qu'un paramètre seul. |
| H2 | Une ligne de base individuelle améliore la pertinence des alertes par rapport à des seuils généraux. |
| H3 | La priorisation des alertes réduit la charge cognitive du médecin de bord sans augmenter significativement les alertes manquées. |
| H4 | Le fonctionnement embarqué maintient surveillance et détection pendant une perte de communication. |
| H5 | L'intégration des données environnementales (CO2, température, humidité, rayonnements) améliore l'interprétation des variations physiologiques. |

## 3. Périmètre

**Inclus :** gestion des profils, acquisition (capteurs simulés), contrôle qualité, détection d'anomalies, alertes, tableau de bord, historique, rapports PDF, mode hors ligne, synchronisation, journal d'audit.
**Exclus :** certification médicale/spatiale, matériel réel de vol, diagnostic automatique, prescription, intégration à des systèmes d'agences.

## 4. Acteurs

| Acteur | Rôle |
|---|---|
| Astronaute | Consulte ses données, saisit des auto-évaluations (fatigue, humeur) |
| Médecin de bord | Supervise l'équipage, traite les alertes, rédige des notes |
| Centre médical terrestre | Supervise à distance, reçoit les données synchronisées |
| Administrateur système | Gère comptes, droits, configuration, maintenance |
| Capteurs / simulateur | Source de données physiologiques et environnementales |

## 5. Exigences fonctionnelles

| ID | Exigence | Priorité | Module |
|---|---|---|---|
| F01 | Le système authentifie les utilisateurs (identifiant + mot de passe, MFA pour médecin/admin). | Haute | Utilisateurs |
| F02 | Le système gère les rôles et droits (astronaute, médecin, centre terrestre, admin). | Haute | Utilisateurs |
| F03 | Le système gère un profil individuel par astronaute (données de référence, antécédents, ligne de base). | Haute | Astronautes |
| F04 | Le système collecte les signes vitaux (FC, SpO2, fréquence respiratoire, température, PA, ECG simplifié). | Haute | Acquisition |
| F05 | Le système collecte les données d'activité et de sommeil. | Moyenne | Sommeil |
| F06 | Le système collecte les données environnementales (CO2, température, humidité, bruit, rayonnements). | Moyenne | Environnement |
| F07 | Le système contrôle la qualité des données (valeurs aberrantes, données manquantes, panne capteur). | Haute | Acquisition |
| F08 | Le système calcule et met à jour une ligne de base individuelle. | Haute | IA |
| F09 | Le système détecte les anomalies (règles + Isolation Forest + tendances). | Haute | IA |
| F10 | Le système génère des alertes à 4 niveaux : technique, vigilance, médicale, urgence potentielle. | Haute | Alertes |
| F11 | Chaque alerte est explicable (paramètre, valeur, référence personnelle, durée, paramètres associés, confiance, action recommandée). | Haute | Alertes |
| F12 | Le tableau de bord affiche en temps réel les courbes, états et alertes actives. | Haute | Interface |
| F13 | Le système conserve et permet de consulter l'historique avec filtres. | Moyenne | Stockage |
| F14 | Le système exporte des rapports médicaux en PDF. | Moyenne | Rapports |
| F15 | Le système fonctionne en mode hors ligne et synchronise après reconnexion sans perte. | Haute | Communication |
| F16 | Le système permet la saisie d'auto-évaluations psychologiques et de suivi médicamenteux. | Moyenne | Santé psy / Médicaments |
| F17 | Le système journalise toutes les actions sensibles (audit non modifiable). | Haute | Sécurité |

## 6. Exigences non fonctionnelles

| ID | Exigence | Cible |
|---|---|---|
| N01 | Latence d'affichage d'une mesure | ≤ 2 s |
| N02 | Latence de détection d'anomalie | ≤ 10 s (règles), ≤ 60 s (modèle) |
| N03 | Disponibilité du serveur embarqué (simulée) | ≥ 99,5 % |
| N04 | Perte de données lors d'une coupure | 0 % (file locale persistante) |
| N05 | Chiffrement en transit et au repos | TLS 1.3 / AES-256 |
| N06 | Temps de synchronisation après reconnexion (24 h de données) | ≤ 5 min |
| N07 | Conformité aux principes RGPD (minimisation, consentement, droit d'accès) | Oui |
| N08 | Couverture de tests automatisés | ≥ 80 % sur le cœur métier |
| N09 | Utilisabilité : alerte comprise sans formation | ≥ 85 % en test utilisateur |
| N10 | Portabilité : déploiement par conteneurs | Docker Compose |

## 7. Architecture technique

```
[Capteurs / Simulateur] --MQTT--> [Passerelle d'acquisition]
        |                                  |
        v                                  v
 Contrôle qualité  -->  Moteur d'analyse (règles + ML)  -->  Moteur d'alertes
        |                                  |                       |
        +----------> PostgreSQL + TimescaleDB <--------------------+
                               |
                    API FastAPI (REST + WebSocket)
                       |                 |
              Interface React      File de synchronisation
              (astronaute/médecin)   ---> Centre terrestre (liaison intermittente)
```

| Couche | Technologie |
|---|---|
| Frontend | React |
| Backend | Python / FastAPI |
| Base de données | PostgreSQL + TimescaleDB |
| Messagerie capteurs | MQTT |
| Temps réel | WebSocket |
| Authentification | OAuth 2.0 / JWT |
| Sécurité transport/stockage | TLS, AES-256 |
| Déploiement | Docker |
| Tests | Pytest |

Synchronisation Terre-bord : file d'attente persistante, envoi par lots, reprise sur interruption, horodatage et identifiants uniques pour l'idempotence (principe de réseau tolérant aux délais).

## 8. Modules

1. Gestion des astronautes
2. Surveillance physiologique
3. Tableau de bord
4. Détection d'anomalies
5. Alertes
6. Sommeil et activité
7. Santé psychologique
8. Médicaments
9. Communication / synchronisation
10. Rapports

## 9. Cas d'utilisation

Voir `04_diagrammes_UML.md` pour les diagrammes. Cas retenus :

| ID | Cas d'utilisation | Acteur principal |
|---|---|---|
| CU1 | S'authentifier | Tous |
| CU2 | Consulter ses signes vitaux | Astronaute |
| CU3 | Saisir une auto-évaluation | Astronaute |
| CU4 | Superviser l'équipage | Médecin de bord |
| CU5 | Traiter une alerte | Médecin de bord |
| CU6 | Générer un rapport PDF | Médecin de bord |
| CU7 | Superviser à distance | Centre terrestre |
| CU8 | Gérer comptes et configuration | Administrateur |

## 10. Interfaces (écrans)

- **E1 Connexion** : identifiant, mot de passe, code MFA.
- **E2 Tableau de bord équipage** : une carte par astronaute (statut vert/orange/rouge), alertes actives triées par gravité, indicateur de connexion Terre.
- **E3 Détail astronaute** : courbes FC/SpO2/température/respiration, sommeil, ligne de base superposée, chronologie des alertes.
- **E4 Détail d'alerte** : explication complète (voir F11), boutons « Acquitter », « Escalader », « Ajouter une note ».
- **E5 Environnement** : CO2, température, humidité, bruit, rayonnements.
- **E6 Auto-évaluation** : questionnaire court fatigue/humeur/stress.
- **E7 Rapports et historique** : filtres, export PDF.
- **E8 Administration** : comptes, droits, journal d'audit, état des capteurs.

## 11. Sécurité, confidentialité, fiabilité

- Principe du moindre privilège, MFA pour comptes sensibles, expiration de session.
- Chiffrement des données au repos et en transit, gestion des clés séparée.
- Pseudonymisation dans les exports de recherche.
- Journal d'audit signé (F17).
- Mode dégradé : en cas de panne capteur, alerte **technique** (pas d'alerte médicale).
- Sauvegardes locales chiffrées, test de restauration.
- Analyse de risques conforme à l'approche ISO 14971 (voir `07_risques.md`).

## 12. Méthodologie expérimentale

**Données :** simulées selon des profils physiologiques réalistes, complétées par des jeux de données publics (FC, sommeil, activité, SpO2) pour l'entraînement/validation.

**Scénarios :** voir `06_plan_tests.md` (S1 à S8).

**Indicateurs :** sensibilité, spécificité, précision, F1, latence de détection, disponibilité, taux de perte de données, temps de synchronisation.

**Protocole :**
1. Générer N profils simulés avec anomalies injectées à des instants connus.
2. Comparer trois approches : seuils généraux, seuils personnalisés, modèle multi-paramètres (tests de H1, H2).
3. Mesurer latence et alertes manquées (H3).
4. Couper la liaison Terre pendant 24-72 h simulées (H4).
5. Comparer avec/sans données environnementales (H5).
6. Analyse statistique : moyennes, intervalles de confiance, tests appariés.

## 13. MVP et livrables

**MVP :** gestion des utilisateurs, capteurs simulés, collecte, graphiques, alertes, historique, export PDF, mode hors ligne simulé.

**Livrables :** application (code source + Docker Compose), documentation, jeux de données simulés, résultats d'évaluation, rapport final, présentation.

## 14. Contraintes et limites

- Seuils cliniques non validés médicalement : à définir avec des professionnels.
- Données simulées : les performances mesurées ne garantissent pas les performances en conditions réelles.
- Pas de certification, pas de qualification spatiale.
- Ressources de calcul embarquées supposées limitées : modèles légers en priorité.

## 15. Documents associés

| Fichier | Contenu |
|---|---|
| 02_matrice_tracabilite.md | Exigences ↔ tests ↔ risques |
| 03_regles_alerte_et_algorithmes.md | Règles R01–R06, algorithmes, explicabilité |
| 04_diagrammes_UML.md | Cas d'utilisation, séquence, classes, déploiement (Mermaid) |
| 05_schema_base_de_donnees.sql | Schéma PostgreSQL/TimescaleDB |
| 06_plan_tests.md | Scénarios, tests, indicateurs |
| 07_risques.md | Registre des risques |
| 08_planning_budget.md | Gantt, ressources, budget |
| 09_bibliographie.md | Références |

## 16. Abréviations

FC : fréquence cardiaque · SpO2 : saturation en oxygène · ECG : électrocardiogramme · PA : pression artérielle · MFA : authentification multifacteur · MVP : produit minimum viable · RGPD : Règlement général sur la protection des données · DTN : réseau tolérant aux délais.
