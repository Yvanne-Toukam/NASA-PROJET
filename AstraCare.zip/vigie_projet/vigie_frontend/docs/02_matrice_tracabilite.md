# ASTRA-MED — Matrice de traçabilité (exigences ↔ tests ↔ risques)

Tests : voir `06_plan_tests.md`. Risques : voir `07_risques.md`.

| Exigence | Description courte | Tests | Risques liés |
|---|---|---|---|
| F01 | Authentification (MFA) | T01, T02 | RK08 |
| F02 | Rôles et droits | T03 | RK08 |
| F03 | Profil individuel | T04 | RK05 |
| F04 | Collecte signes vitaux | T05 | RK01, RK02 |
| F05 | Sommeil et activité | T06 | RK02 |
| F06 | Données environnementales | T07 | RK02 |
| F07 | Contrôle qualité | T08, T09 | RK01, RK03 |
| F08 | Ligne de base individuelle | T10 | RK05 |
| F09 | Détection d'anomalies | T11, T12 | RK03, RK04 |
| F10 | Alertes à 4 niveaux | T13 | RK04 |
| F11 | Alertes explicables | T14 | RK04, RK06 |
| F12 | Tableau de bord temps réel | T15 | RK09 |
| F13 | Historique | T16 | RK07 |
| F14 | Export PDF | T17 | RK07 |
| F15 | Mode hors ligne et synchro | T18, T19 | RK10 |
| F16 | Auto-évaluation et médicaments | T20 | RK05 |
| F17 | Journal d'audit | T21 | RK08 |

| Exigence non fonctionnelle | Test |
|---|---|
| N01 latence d'affichage | T22 |
| N02 latence de détection | T11, T12 |
| N03 disponibilité | T23 |
| N04 perte de données | T19 |
| N05 chiffrement | T24 |
| N06 temps de synchronisation | T19 |
| N07 RGPD | T25 |
| N08 couverture de tests | CI (pytest --cov) |
| N09 utilisabilité | T26 |
| N10 déploiement conteneurs | T27 |
