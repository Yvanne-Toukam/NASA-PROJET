# ASTRA-MED — Règles d'alerte, algorithmes, explicabilité

> Les seuils ci-dessous sont des **valeurs de départ pour le prototype**. Ils doivent être validés avec des professionnels de santé et ajustés expérimentalement.

## 1. Niveaux d'alerte

| Niveau | Signification | Destinataire |
|---|---|---|
| Technique | Problème capteur ou donnée, pas d'alerte médicale | Administrateur, médecin |
| Vigilance | Dérive à surveiller | Médecin de bord |
| Médicale | Anomalie probable nécessitant évaluation | Médecin de bord (+ Terre) |
| Urgence potentielle | Combinaison d'anomalies critiques | Médecin de bord + Terre, notification immédiate |

## 2. Règles R01–R06

| ID | Condition | Niveau | Action recommandée |
|---|---|---|---|
| R01 | FC au repos hors plage personnelle (ex. ± 2 écarts-types) pendant 10 min | Vigilance | Contrôle et surveillance |
| R02 | Baisse de SpO2 sous la ligne de base personnelle associée à une fréquence respiratoire élevée | Médicale | Examen respiratoire |
| R03 | Sommeil insuffisant 3 jours consécutifs | Vigilance | Ajustement du planning |
| R04 | CO2 élevé et symptômes déclarés | Médicale | Vérification environnementale |
| R05 | Perte d'un capteur vital > 60 s | Technique | Maintenance et surveillance alternative |
| R06 | Combinaison d'au moins 2 anomalies de niveau médical simultanées | Urgence potentielle | Protocole médical et notification |

Principe : une donnée jugée invalide par le contrôle qualité (F07) déclenche une alerte **technique** et n'alimente pas les règles médicales.

## 3. Algorithmes

### MVP
| Algorithme | Rôle | Entrées | Sortie |
|---|---|---|---|
| Ligne de base glissante (médiane + écart absolu médian) | Référence individuelle (F08) | Mesures des 7-14 derniers jours | Plage personnelle par paramètre |
| Isolation Forest | Détection de mesures atypiques multivariées | Vecteur [FC, SpO2, FR, température, sommeil, activité, CO2] sur fenêtre | Score d'anomalie 0-1 |
| Tendance (régression linéaire / moyenne mobile exponentielle) | Dérive sur plusieurs jours | Série journalière | Pente et significativité |

### Version avancée (perspectives)
LSTM ou modèle temporel, autoencoder multivarié, explicabilité par SHAP.

## 4. Fusion des signaux

Score de risque = combinaison pondérée du score d'anomalie, des écarts à la ligne de base, des règles déclenchées et du contexte environnemental. Les pondérations sont des paramètres de configuration évalués expérimentalement (H1, H2, H5).

## 5. Explicabilité (F11)

Chaque alerte contient : paramètre déclencheur, valeur mesurée, valeur de référence personnelle, durée, paramètres associés, niveau de confiance, action recommandée.

Exemple de rendu :
> **Alerte de vigilance** : FC au repos supérieure de 18 % à la ligne de base personnelle depuis 6 h, associée à une baisse de 32 % de la qualité du sommeil et à une fatigue déclarée élevée. Recommandation : contrôle de la pression artérielle et évaluation médicale.

## 6. Format JSON d'une alerte

```json
{
  "alert_id": "uuid",
  "astronaut_id": "uuid",
  "level": "vigilance",
  "rule_id": "R01",
  "trigger_parameter": "heart_rate_rest",
  "measured_value": 82.0,
  "baseline_value": 69.5,
  "deviation_pct": 18.0,
  "duration_min": 360,
  "related_parameters": ["sleep_quality", "fatigue_self_report"],
  "confidence": 0.78,
  "recommended_action": "Contrôle PA et évaluation médicale",
  "created_at": "2026-01-01T08:00:00Z",
  "status": "open"
}
```
