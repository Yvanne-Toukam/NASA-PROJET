# ASTRA-MED — Planning, ressources, budget

Durée proposée : 24 semaines. À adapter à votre calendrier.

## 1. Planning (Gantt)

```mermaid
gantt
  title ASTRA-MED — planning prévisionnel
  dateFormat  YYYY-MM-DD
  axisFormat  %d/%m
  section Cadrage
  Analyse des besoins et état de l'art :a1, 2027-01-04, 3w
  Cahier des charges et risques        :a2, after a1, 2w
  section Conception
  Architecture et modèle de données    :b1, after a2, 3w
  Maquettes et UML                     :b2, after a2, 3w
  section Développement
  Acquisition, simulateur, stockage    :c1, after b1, 4w
  Moteur d'analyse et alertes          :c2, after c1, 4w
  Interfaces et rapports               :c3, after c1, 4w
  Mode hors ligne et synchronisation   :c4, after c2, 2w
  section Validation
  Tests et expérimentations            :d1, after c4, 3w
  Analyse des résultats                :d2, after d1, 2w
  section Clôture
  Rédaction du rapport et soutenance   :e1, after d2, 3w
```

## 2. Ressources humaines

| Rôle | Charge estimée |
|---|---|
| Chef de projet / analyste | 20 % |
| Développeur backend / IA | 40 % |
| Développeur frontend | 25 % |
| Testeur / qualité | 15 % |
| Conseiller médical (consultation) | ponctuel |

## 3. Matériel et logiciels

Poste de développement, serveur ou machine virtuelle, outils open source (React, FastAPI, PostgreSQL/TimescaleDB, Eclipse Mosquitto, Docker, Pytest, scikit-learn). Aucune licence payante requise.

## 4. Budget indicatif (projet universitaire)

| Poste | Estimation |
|---|---|
| Matériel (si non disponible) | 0 à 800 € |
| Hébergement cloud de test | 0 à 150 € |
| Licences logicielles | 0 € (open source) |
| Impression, soutenance | 50 € |
| **Total** | **≈ 50 à 1 000 €** |

Ces montants sont des ordres de grandeur à ajuster.

## 5. Jalons

| Jalon | Semaine |
|---|---|
| J1 Cahier des charges validé | 5 |
| J2 Conception validée | 8 |
| J3 MVP fonctionnel | 16 |
| J4 Version complète avec hors ligne | 18 |
| J5 Évaluation terminée | 23 |
| J6 Rapport final et soutenance | 24 |
