# ASTRA-MED — Bibliographie

> À vérifier et compléter (dates d'accès, numéros de version, DOI) avant dépôt du mémoire. Ajoutez aussi des articles récents de santé spatiale et de détection d'anomalies sur signaux physiologiques.

## Santé spatiale
- NASA. *NASA Space Flight Human-System Standard (NASA-STD-3001), Volume 1: Crew Health* et Volume 2: *Human Factors, Habitability, and Environmental Health*.
- NASA Human Research Program. Feuille de route des risques pour la santé humaine (*Human Research Roadmap*), site officiel NASA.

## Intelligence artificielle
- Liu, F. T., Ting, K. M., Zhou, Z.-H. (2008). *Isolation Forest*. IEEE International Conference on Data Mining (ICDM).
- Hochreiter, S., Schmidhuber, J. (1997). *Long Short-Term Memory*. Neural Computation, 9(8).
- Lundberg, S., Lee, S.-I. (2017). *A Unified Approach to Interpreting Model Predictions (SHAP)*. NeurIPS.
- Chandola, V., Banerjee, A., Kumar, V. (2009). *Anomaly Detection: A Survey*. ACM Computing Surveys, 41(3).

## Normes et réglementation
- ISO 14971 — Dispositifs médicaux : application de la gestion des risques.
- IEC 62304 — Logiciels de dispositifs médicaux : processus du cycle de vie.
- ISO/IEC 27001 — Systèmes de management de la sécurité de l'information.
- Règlement (UE) 2016/679 (RGPD).

## Communications spatiales
- CCSDS — Space Packet Protocol (CCSDS 133.0-B).
- IETF RFC 9171 — Bundle Protocol Version 7 (réseaux tolérants aux délais).

## Technologies
- Documentation officielle : FastAPI, React, PostgreSQL, TimescaleDB, MQTT (OASIS), scikit-learn, Docker, Pytest.
- IETF RFC 6749 — The OAuth 2.0 Authorization Framework.
- IETF RFC 8446 — TLS 1.3.
