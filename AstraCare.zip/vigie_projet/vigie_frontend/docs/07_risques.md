# ASTRA-MED — Registre des risques

Probabilité (P) et impact (I) de 1 à 5 ; criticité = P × I (≥ 15 critique, 8-14 élevé, < 8 modéré).

| ID | Risque | P | I | Crit. | Mitigation |
|---|---|---|---|---|---|
| RK01 | Capteur défaillant produisant de fausses mesures | 4 | 4 | 16 | Contrôle qualité, alerte technique distincte, redondance |
| RK02 | Données manquantes ou désynchronisées | 4 | 3 | 12 | Horodatage, file persistante, interpolation signalée |
| RK03 | Fausses alertes (alert fatigue) | 4 | 4 | 16 | Ligne de base individuelle, priorisation, réglage des seuils |
| RK04 | Alerte manquée (faux négatif) | 2 | 5 | 10 | Règles + ML en complément, tests de sensibilité, revue clinique |
| RK05 | Ligne de base biaisée (peu de données initiales) | 3 | 3 | 9 | Période d'apprentissage, valeurs de population en secours |
| RK06 | Mauvaise interprétation d'une alerte | 3 | 4 | 12 | Explicabilité, formulation claire, test utilisateur |
| RK07 | Perte ou corruption de l'historique | 2 | 4 | 8 | Sauvegardes chiffrées, test de restauration |
| RK08 | Accès non autorisé aux données de santé | 2 | 5 | 10 | MFA, moindre privilège, chiffrement, audit |
| RK09 | Surcharge ou latence du tableau de bord | 3 | 3 | 9 | Agrégats continus, tests de charge |
| RK10 | Échec de synchronisation après coupure | 3 | 4 | 12 | Idempotence, reprise, accusés de réception |
| RK11 | Dérive du planning / périmètre trop large | 4 | 3 | 12 | MVP priorisé, revues hebdomadaires |
| RK12 | Seuils cliniques non validés | 4 | 4 | 16 | Revue par un professionnel de santé, mention explicite des limites |

Revue du registre : à chaque fin de phase.
