# ASTRA-MED — Diagrammes UML (Mermaid)

Visualisables dans tout éditeur compatible Mermaid (GitHub, VS Code, mermaid.live).

## 1. Cas d'utilisation

```mermaid
flowchart LR
  A[Astronaute] --> CU1((S'authentifier))
  A --> CU2((Consulter ses signes vitaux))
  A --> CU3((Saisir une auto-évaluation))
  M[Médecin de bord] --> CU1
  M --> CU4((Superviser l'équipage))
  M --> CU5((Traiter une alerte))
  M --> CU6((Générer un rapport PDF))
  T[Centre terrestre] --> CU1
  T --> CU7((Superviser à distance))
  D[Administrateur] --> CU1
  D --> CU8((Gérer comptes et configuration))
```

## 2. Séquence — détection et traitement d'une alerte

```mermaid
sequenceDiagram
  participant S as Capteur/Simulateur
  participant G as Passerelle (MQTT)
  participant Q as Contrôle qualité
  participant A as Moteur d'analyse
  participant E as Moteur d'alertes
  participant DB as TimescaleDB
  participant UI as Interface médecin
  S->>G: mesure
  G->>Q: mesure brute
  Q->>DB: mesure validée
  Q->>A: mesure validée
  A->>A: comparaison à la ligne de base + modèle
  A->>E: anomalie + score
  E->>DB: alerte enregistrée
  E-->>UI: alerte (WebSocket)
  UI->>E: acquittement / note
  E->>DB: audit
```

## 3. Séquence — perte de communication

```mermaid
sequenceDiagram
  participant B as Serveur de bord
  participant F as File de synchronisation
  participant T as Centre terrestre
  B->>T: envoi lot n
  T--xB: liaison perdue
  B->>F: mise en file (persistante)
  Note over B: surveillance et alertes locales continuent
  T-->>B: liaison rétablie
  F->>T: envoi des lots en attente (idempotent)
  T-->>F: accusé de réception
```

## 4. Classes

```mermaid
classDiagram
  class Astronaut { +uuid id +string name +date birth_date +float height_cm +float weight_kg }
  class User { +uuid id +string username +string role +bool mfa_enabled }
  class Sensor { +uuid id +string type +string status }
  class Measurement { +timestamp time +string parameter +float value +string quality }
  class Baseline { +string parameter +float center +float spread +date computed_on }
  class Alert { +uuid id +string level +string rule_id +float confidence +string status }
  class SelfReport { +timestamp time +int fatigue +int mood +int stress }
  class Medication { +string name +string dose +string schedule }
  class AuditLog { +timestamp time +string action +string actor }
  Astronaut "1" --> "*" Measurement
  Astronaut "1" --> "*" Baseline
  Astronaut "1" --> "*" Alert
  Astronaut "1" --> "*" SelfReport
  Astronaut "1" --> "*" Medication
  Sensor "1" --> "*" Measurement
  User "1" --> "*" AuditLog
  Alert "*" --> "*" Measurement : explique
```

## 5. Déploiement

```mermaid
flowchart TB
  subgraph Bord["Vaisseau (serveur local)"]
    GW[Passerelle MQTT]
    API[API FastAPI]
    AI[Moteur d'analyse]
    DB[(PostgreSQL + TimescaleDB)]
    UI[Interface React]
    Q[File de synchronisation]
  end
  subgraph Terre["Centre de supervision"]
    TAPI[API terrestre]
    TDB[(Base terrestre)]
    TUI[Interface médecin sol]
  end
  GW --> API --> AI
  API --> DB
  API --> UI
  API --> Q
  Q -. liaison intermittente chiffrée TLS .-> TAPI
  TAPI --> TDB
  TAPI --> TUI
```
