-- ASTRA-MED — Schéma de base de données (PostgreSQL + TimescaleDB)
-- Prototype : à adapter avant tout usage.

CREATE EXTENSION IF NOT EXISTS timescaledb;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE app_user (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('astronaut','flight_surgeon','ground_center','admin')),
  mfa_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE astronaut (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES app_user(id),
  code_name TEXT UNIQUE NOT NULL,          -- pseudonyme
  birth_date DATE,
  height_cm NUMERIC(5,1),
  weight_kg NUMERIC(5,1),
  medical_history TEXT,                    -- à chiffrer au niveau applicatif
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sensor (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  astronaut_id UUID REFERENCES astronaut(id),
  sensor_type TEXT NOT NULL,               -- hr, spo2, resp, temp, bp, ecg, co2, humidity, radiation...
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','faulty','offline')),
  last_seen TIMESTAMPTZ
);

CREATE TABLE measurement (
  time TIMESTAMPTZ NOT NULL,
  astronaut_id UUID REFERENCES astronaut(id),
  sensor_id UUID REFERENCES sensor(id),
  parameter TEXT NOT NULL,
  value DOUBLE PRECISION,
  quality TEXT NOT NULL DEFAULT 'valid' CHECK (quality IN ('valid','suspect','rejected')),
  synced BOOLEAN NOT NULL DEFAULT FALSE,
  msg_id UUID NOT NULL DEFAULT gen_random_uuid(),
  UNIQUE (msg_id, time)
);
SELECT create_hypertable('measurement', 'time');
CREATE INDEX ON measurement (astronaut_id, parameter, time DESC);

CREATE TABLE environment_measurement (
  time TIMESTAMPTZ NOT NULL,
  module TEXT NOT NULL,
  parameter TEXT NOT NULL,                 -- co2, temperature, humidity, noise, radiation
  value DOUBLE PRECISION,
  synced BOOLEAN NOT NULL DEFAULT FALSE
);
SELECT create_hypertable('environment_measurement', 'time');

CREATE TABLE baseline (
  astronaut_id UUID REFERENCES astronaut(id),
  parameter TEXT NOT NULL,
  center DOUBLE PRECISION NOT NULL,
  spread DOUBLE PRECISION NOT NULL,
  computed_on DATE NOT NULL,
  PRIMARY KEY (astronaut_id, parameter, computed_on)
);

CREATE TABLE alert (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  astronaut_id UUID REFERENCES astronaut(id),
  level TEXT NOT NULL CHECK (level IN ('technical','vigilance','medical','potential_emergency')),
  rule_id TEXT,
  trigger_parameter TEXT,
  measured_value DOUBLE PRECISION,
  baseline_value DOUBLE PRECISION,
  duration_min INTEGER,
  related_parameters TEXT[],
  confidence NUMERIC(3,2),
  recommended_action TEXT,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','acknowledged','escalated','closed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  handled_by UUID REFERENCES app_user(id)
);

CREATE TABLE self_report (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  astronaut_id UUID REFERENCES astronaut(id),
  reported_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  fatigue SMALLINT CHECK (fatigue BETWEEN 0 AND 10),
  mood SMALLINT CHECK (mood BETWEEN 0 AND 10),
  stress SMALLINT CHECK (stress BETWEEN 0 AND 10),
  notes TEXT
);

CREATE TABLE medication (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  astronaut_id UUID REFERENCES astronaut(id),
  name TEXT NOT NULL,
  dose TEXT,
  schedule TEXT,
  taken_at TIMESTAMPTZ[]
);

CREATE TABLE sync_queue (
  id BIGSERIAL PRIMARY KEY,
  entity TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  sent_at TIMESTAMPTZ,
  attempts INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  time TIMESTAMPTZ NOT NULL DEFAULT now(),
  actor UUID REFERENCES app_user(id),
  action TEXT NOT NULL,
  target TEXT,
  details JSONB,
  prev_hash TEXT,
  row_hash TEXT                            -- chaînage de hachage pour détecter les modifications
);

-- Agrégats continus pour le tableau de bord
CREATE MATERIALIZED VIEW measurement_1min
WITH (timescaledb.continuous) AS
SELECT time_bucket('1 minute', time) AS bucket, astronaut_id, parameter,
       avg(value) AS avg_value, min(value) AS min_value, max(value) AS max_value
FROM measurement
WHERE quality = 'valid'
GROUP BY bucket, astronaut_id, parameter;
