"""Cree le squelette du projet Vigie (backend).
Usage : placez ce fichier dans un dossier vide, puis  python creer_structure.py
Le script ne remplace jamais un fichier existant : on peut le relancer sans risque."""
from pathlib import Path

RACINE = Path("vigie_projet")

# chemin -> description (ecrite en premiere ligne du fichier)
FICHIERS = {
    # --- configuration : aucun chiffre metier dans le code ---
    "config/app.yaml": "Parametres de l'application : port serie, debit, chemin de la base, niveau de journal",
    "config/seuils.yaml": "Seuils d'alerte par indicateur (hypotheses d'ingenierie, ajustables)",
    "config/regles.yaml": "Regles de croisement causes-effets CR-01 a CR-05",
    "config/scenarios/nominal.yaml": "Scenario : journee normale",
    "config/scenarios/derive_lente.yaml": "Scenario : sommeil en baisse, pouls en hausse",
    "config/scenarios/urgence.yaml": "Scenario : pouls et SpO2 qui se degradent",
    "config/scenarios/panne_capteur.yaml": "Scenario : capteur muet, mode degrade",
    # --- noyau commun ---
    "vigie/__init__.py": "Paquet Vigie",
    "vigie/core/__init__.py": "Noyau commun : ne depend d'aucun service",
    "vigie/core/config.py": "charger_config() : point de lecture UNIQUE des fichiers YAML",
    "vigie/core/constantes.py": "Catalogue des mesures (unite, plage), sources, qualites, modules de sante",
    "vigie/core/journal.py": "Configuration du journal (logging) partagee par tous les services",
    # --- service 1 : ingestion ---
    "vigie/services/__init__.py": "Les services : un dossier = une responsabilite",
    "vigie/services/ingestion/__init__.py": "Service INGESTION : du port serie jusqu'a la base",
    "vigie/services/ingestion/validation.py": "valider_trame(ligne) -> dict ou None (contrat, section 10)",
    "vigie/services/ingestion/lecteur_serie.py": "Lecture pyserial, reconnexion, appel de la validation puis du stockage",
    # --- service 2 : stockage ---
    "vigie/services/stockage/__init__.py": "Service STOCKAGE : seul endroit qui ecrit du SQL",
    "vigie/services/stockage/schema.sql": "Schema SQLite complet (section 11 du cahier des charges)",
    "vigie/services/stockage/connexion.py": "connecter() : ouvre la base, active WAL, cree les tables",
    "vigie/services/stockage/mesures.py": "inserer_mesure(), lire_serie(), derniere_mesure()",
    "vigie/services/stockage/references.py": "Lecture et ecriture de references_perso",
    "vigie/services/stockage/alertes.py": "Journal des alertes : creer sans doublon, acquitter, lister",
    "vigie/services/stockage/systeme.py": "Compteurs et etat du systeme (trames rejetees, age des sources)",
    # --- service 3 : analyse (le moteur) ---
    "vigie/services/analyse/__init__.py": "Service ANALYSE : expose analyser() et calculer_references()",
    "vigie/services/analyse/series.py": "Lecture et agregation pandas (moyennes par jour, fenetres)",
    "vigie/services/analyse/references.py": "Calcul des references personnelles (moyenne, ecart-type)",
    "vigie/services/analyse/statistiques.py": "z-score, CUSUM, moyenne glissante, pente de tendance",
    "vigie/services/analyse/niveaux.py": "Traduction valeur -> niveau 0, 1 ou 2 selon seuils.yaml",
    "vigie/services/analyse/croisements.py": "Regles causes-effets (CR-01 a CR-05)",
    "vigie/services/analyse/alertes.py": "Construction des alertes : regroupement, texte court, regle",
    "vigie/services/analyse/moteur.py": "analyser(con, astro) -> JSON de la section 13.5",
    # --- service 4 : simulation ---
    "vigie/services/simulation/__init__.py": "Service SIMULATION : memes trames que Proteus, pour tester et secourir la demo",
    "vigie/services/simulation/profils.py": "Valeurs de base et bruit de chaque mesure, difference entre astronautes",
    "vigie/services/simulation/scenarios.py": "Application des scenarios (derive, urgence, panne) aux valeurs",
    "vigie/services/simulation/simulateur.py": "generer() : ecrit des jours de mesures via validation + stockage",
    # --- points d'entree ---
    "scripts/initialiser_base.py": "Cree la base et les tables",
    "scripts/lancer_lecteur.py": "Demarre le lecteur serie",
    "scripts/lancer_simulateur.py": "Remplit la base avec un scenario : python scripts/lancer_simulateur.py --scenario derive_lente",
    "scripts/analyser.py": "Affiche le JSON du moteur pour un astronaute (outil de mise au point)",
    # --- tests : le miroir des services ---
    "tests/__init__.py": "Tests",
    "tests/conftest.py": "Fixtures partagees : base SQLite en memoire, jeu de donnees de test",
    "tests/ingestion/__init__.py": "",
    "tests/ingestion/test_validation.py": "Tests du contrat : trames valides, invalides, hors plage, doublons",
    "tests/ingestion/test_lecteur.py": "Tests du lecteur sans port serie reel",
    "tests/stockage/__init__.py": "",
    "tests/stockage/test_mesures.py": "Tests d'insertion, de lecture et d'anti-doublon",
    "tests/analyse/__init__.py": "",
    "tests/analyse/test_statistiques.py": "Tests de z-score et CUSUM",
    "tests/analyse/test_moteur.py": "Tests de bout en bout sur les scenarios simules",
    "tests/simulation/__init__.py": "",
    "tests/simulation/test_simulateur.py": "Le simulateur respecte le contrat",
    # --- documentation ---
    "docs/contrat.md": "Trame serie, schema de base, JSON du moteur : ce que l'equipe peut utiliser",
    "docs/decisions.md": "Choix techniques et hypotheses (utile pour le dossier du jury)",
    "README.md": "Vigie backend : installation, lancement, tests",
}

CONTENUS_SPECIAUX = {
    ".gitignore": "venv/\n__pycache__/\n*.pyc\ndata/\n*.db\n*.db-wal\n*.db-shm\n.pytest_cache/\n",
    "requirements.txt": "pandas\nnumpy\npyyaml\npyserial\npytest\n",
    "data/.gitkeep": "",
}


def entete(chemin, description):
    if chemin.endswith(".py"):
        return f'"""{description}"""\n' if description else ""
    if chemin.endswith((".yaml", ".sql")):
        prefixe = "--" if chemin.endswith(".sql") else "#"
        return f"{prefixe} {description}\n"
    if chemin.endswith(".md"):
        return f"# {description}\n"
    return ""


def main():
    crees = 0
    for chemin, description in {**FICHIERS, **CONTENUS_SPECIAUX}.items():
        cible = RACINE / chemin
        cible.parent.mkdir(parents=True, exist_ok=True)
        if cible.exists():
            continue
        cible.write_text(CONTENUS_SPECIAUX.get(chemin, entete(chemin, description)), encoding="utf-8")
        crees += 1
    print(f"{crees} fichiers crees dans {RACINE}/")


if __name__ == "__main__":
    main()