"""Tests d'intégration du moteur d'analyse sur scénarios simulés."""
from vigie.services.database.connectdb import connecter
from vigie.services.simulation.simulateur import generer
from vigie.services.analyse.references import calculer_references
from vigie.services.analyse.moteur import analyser


def test_analyse_nominal_complet():
    con = connecter(":memory:")
    generer(con, scenario="nominal", jours=20)
    calculer_references(con, "AST2026-001")
    res = analyser(con, "AST2026-001")
    assert res["astro"] == "AST2026-001"
    assert res["niveau_global"] == 0
    assert "cardio" in res["modules"]
    assert "os_muscles" in res["modules"]
    assert "immunite" in res["modules"]
    assert "comportement" in res["modules"]
    assert len(res["alertes"]) == 0
    con.close()
