"""Tests unitaires des calculs statistiques (z-score, CUSUM, tendance)."""
from vigie.services.analyse.statistiques import zscore, cusum, calculer_pente_tendance


def test_calcul_zscore():
    assert zscore(70, 60, 5) == 2.0
    assert zscore(50, 60, 5) == -2.0
    # Protection division par zéro si écart-type nul
    assert zscore(60, 60, 0) == 0.0


def test_algorithme_cusum():
    # Série stable centrée : aucun cumul
    assert not cusum([0.0, 0.2, -0.1, 0.1, 0.0] * 5, k=0.5, h=5.0)
    # Dérive modérée mais continue au-dessus de k=0.5 :
    # chaque point contribue à s += (1.2 - 0.5) = 0.7. Au bout de 8 points, s = 5.6 > 5.0 -> True
    assert cusum([1.2] * 8, k=0.5, h=5.0)
    # Une seule valeur extrême ne doit pas déclencher
    assert not cusum([3.0], k=0.5, h=5.0)


def test_calculer_pente_tendance():
    serie_croissante = [10, 11, 12, 13, 14, 15]
    assert calculer_pente_tendance(serie_croissante) > 0
    serie_decroissante = [20, 18, 16, 14, 12]
    assert calculer_pente_tendance(serie_decroissante) < 0
    serie_plate = [5, 5, 5, 5, 5]
    assert calculer_pente_tendance(serie_plate) == 0.0
