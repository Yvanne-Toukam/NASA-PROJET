"""Tests des opérations de stockage des mesures (anti-doublon et contraintes)."""
import pytest
import sqlite3
from vigie.services.database.connectdb import connecter
from vigie.services.database import mesures


def test_insertion_et_lecture_mesure():
    con = connecter(":memory:")
    m_id = mesures.inserer_mesure(
        con,
        astro="AST2026-001",
        source="watch",
        mesure="pouls",
        valeur=72.0,
        unite="bpm",
        seq=1,
    )
    assert m_id is not None
    m = mesures.select_mesure_id(con, m_id)
    assert m["valeur"] == 72.0
    assert m["qualite"] == "ok"


def test_anti_doublon_mesure():
    con = connecter(":memory:")
    # Première insertion
    m1 = mesures.inserer_mesure(
        con, astro="AST2026-001", source="watch", mesure="pouls", valeur=72.0, unite="bpm", seq=42
    )
    assert m1 is not None

    # Deuxième insertion identique (même source, astro, seq) -> retourne None
    m2 = mesures.inserer_mesure(
        con, astro="AST2026-001", source="watch", mesure="pouls", valeur=72.0, unite="bpm", seq=42
    )
    assert m2 is None


def test_erreur_integrite_propagee_si_hors_doublon():
    con = connecter(":memory:")
    # Insertion avec qualite invalide -> doit lever sqlite3.IntegrityError car violation de CHECK
    with pytest.raises(sqlite3.IntegrityError):
        mesures.inserer_mesure(
            con, astro="AST2026-001", source="watch", mesure="pouls", valeur=72.0, unite="bpm", seq=99, qualite="inconnue"
        )
