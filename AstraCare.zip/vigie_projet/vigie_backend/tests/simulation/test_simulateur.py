import sqlite3
from datetime import datetime
from pathlib import Path
from statistics import mean

import pytest

from vigie.services.ingestion.contrat import valider_trame
from vigie.services.simulation.simulateur import (
    ASTRONAUTES, PAS_PAR_JOUR, ZONES, Simulateur, injecter_pas, remplir_base,
)

SCHEMA = Path(__file__).resolve().parents[2] / "vigie" / "services" / "database" / "database.sql"
DEBUT = datetime(2026, 11, 1, 0, 0, 0)
LIGNES_PAR_PAS = len(ASTRONAUTES) * 8 + len(ZONES) * 4  # 4 astros * 8 + 2 zones * 4 = 40 trames par pas


@pytest.fixture
def con():
    c = sqlite3.connect(":memory:")
    c.row_factory = sqlite3.Row
    c.executescript(SCHEMA.read_text(encoding="utf-8"))
    yield c
    c.close()


def valeurs(lignes, astro, mesure):
    sortie = []
    for l in lignes:
        trame, _ = valider_trame(l)
        if trame["astro"] == astro and trame["mesure"] == mesure:
            sortie.append(trame["valeur"])
    return sortie


def lancer(sim, nb_pas):
    toutes = []
    for _ in range(nb_pas):
        toutes += sim.pas()[1]
    return toutes


def test_nombre_de_lignes_par_pas():
    _, lignes = Simulateur(debut=DEBUT).pas()
    assert len(lignes) == LIGNES_PAR_PAS


def test_toutes_les_lignes_sont_valides():
    for ligne in lancer(Simulateur(debut=DEBUT), 300):
        trame, motif = valider_trame(ligne)
        assert trame is not None, f"{ligne} -> {motif}"


def test_deterministe_avec_la_meme_graine():
    assert lancer(Simulateur(graine=3, debut=DEBUT), 20) == lancer(Simulateur(graine=3, debut=DEBUT), 20)


def test_numeros_de_sequence_sans_doublon():
    cles = set()
    for ligne in lancer(Simulateur(debut=DEBUT), 50):
        t, _ = valider_trame(ligne)
        cle = (t["source"], t["astro"], t["seq"])
        assert cle not in cles
        cles.add(cle)


def test_le_temps_avance_de_5_minutes():
    sim = Simulateur(debut=DEBUT)
    t1, _ = sim.pas()
    t2, _ = sim.pas()
    assert (t1, t2) == ("2026-11-01 00:00:00", "2026-11-01 00:05:00")


def test_s3_anomalie_cardiaque():
    sim, cible, autre = Simulateur(debut=DEBUT), ASTRONAUTES[0], ASTRONAUTES[1]
    avant = valeurs(lancer(sim, 20), cible, "pouls")
    sim.activer("S3")
    apres_lignes = lancer(sim, 20)
    assert mean(valeurs(apres_lignes, cible, "pouls")[-10:]) > mean(avant) + 20
    assert mean(valeurs(apres_lignes, autre, "pouls")[-10:]) < mean(valeurs(apres_lignes, autre, "pouls")[:3]) + 10


def test_s4_urgence_baisse_spo2():
    sim, cible = Simulateur(debut=DEBUT), ASTRONAUTES[0]
    avant = valeurs(lancer(sim, 20), cible, "spo2")
    sim.activer("S4")
    apres = valeurs(lancer(sim, 20), cible, "spo2")
    assert mean(apres[-10:]) < mean(avant) - 5
    assert min(apres) >= 70  # reste dans la plage valide du contrat


def test_s5_air_degrade_seulement_dans_la_zone_ciblee():
    sim = Simulateur(debut=DEBUT)
    sim.activer("S5")
    lignes = lancer(sim, 30)
    assert mean(valeurs(lignes, ZONES[0], "co2")[-5:]) > 4000
    assert mean(valeurs(lignes, ZONES[1], "co2")[-5:]) < 1500


def test_s6_panne_capteur_marque_capteur_hs():
    sim, cible = Simulateur(debut=DEBUT), ASTRONAUTES[0]
    sim.activer("S6")
    _, lignes = sim.pas()
    for l in lignes:
        trame, _ = valider_trame(l)
        attendu = "capteur_hs" if trame["astro"] == cible and trame["source"] == "watch" and trame["mesure"] == "pouls" else "ok"
        assert trame["qualite"] == attendu


def test_retablir_arrete_le_scenario():
    sim = Simulateur(debut=DEBUT)
    sim.activer("S5")
    lancer(sim, 20)
    sim.retablir()
    assert mean(valeurs(lancer(sim, 5), ZONES[0], "co2")) < 1500


def test_scenario_inconnu():
    with pytest.raises(ValueError):
        Simulateur(debut=DEBUT).activer("S99")


def test_remplir_base_une_journee(con):
    n = remplir_base(con, Simulateur(debut=DEBUT), PAS_PAR_JOUR)
    assert n == PAS_PAR_JOUR * LIGNES_PAR_PAS
    assert con.execute("SELECT COUNT(*) FROM mesures").fetchone()[0] == n
    premiere, derniere = con.execute("SELECT MIN(create_at), MAX(create_at) FROM mesures").fetchone()
    assert premiere == "2026-11-01 00:00:00" and derniere == "2026-11-01 23:55:00"


def test_injecter_pas_en_direct(con):
    resultats = injecter_pas(con, Simulateur(debut=DEBUT))
    assert resultats == ["ok"] * LIGNES_PAR_PAS


def test_reprendre_evite_les_doublons(con):
    remplir_base(con, Simulateur(debut=DEBUT), 3)
    suite = Simulateur(graine=99, debut=datetime(2026, 11, 2))
    suite.reprendre(con)
    assert set(injecter_pas(con, suite)) == {"ok"}
