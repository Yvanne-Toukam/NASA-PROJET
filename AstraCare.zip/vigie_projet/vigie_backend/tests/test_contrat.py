"""Tests de conformité du contrat de trame série (CDC section 10)."""
from vigie.services.ingestion.contrat import valider_trame


def test_trame_valide():
    trame, motif = valider_trame("watch,AST2026-001,pouls,72,bpm,ok,1042")
    assert motif is None
    assert trame == {
        "source": "watch",
        "astro": "AST2026-001",
        "mesure": "pouls",
        "valeur": 72.0,
        "unite": "bpm",
        "qualite": "ok",
        "seq": 1042,
    }


def test_trame_cabine_valide():
    trame, motif = valider_trame("cab,cabine1,co2,800,ppm,ok,12")
    assert motif is None
    assert trame["astro"] == "cabine1"
    assert trame["mesure"] == "co2"


def test_mauvais_nombre_de_champs():
    trame, motif = valider_trame("watch,AST2026-001,pouls,72,bpm,ok")
    assert trame is None and "champs: 6" in motif

    trame, motif = valider_trame("watch,AST2026-001,pouls,72,bpm,ok,1,trop")
    assert trame is None and "champs: 8" in motif


def test_mesure_inconnue_ou_mauvaise_unite():
    trame, motif = valider_trame("watch,AST2026-001,glycemie,5,mmol,ok,1")
    assert trame is None and "mesure inconnue" in motif

    trame, motif = valider_trame("watch,AST2026-001,pouls,72,pct,ok,1")
    assert trame is None and "unite pct incorrecte" in motif


def test_hors_plage_rejete():
    trame, motif = valider_trame("watch,AST2026-001,pouls,400,bpm,ok,1")
    assert trame is None and "hors plage" in motif

    trame, motif = valider_trame("watch,AST2026-001,spo2,60,pct,ok,1")
    assert trame is None and "hors plage" in motif


def test_valeur_non_numerique():
    trame, motif = valider_trame("watch,AST2026-001,pouls,abc,bpm,ok,1")
    assert trame is None and "non numerique" in motif

    trame, motif = valider_trame("watch,AST2026-001,pouls,nan,bpm,ok,1")
    assert trame is None and "non finie" in motif or "non numerique" in motif


def test_source_astro_qualite_inconnus():
    trame, motif = valider_trame("radar,AST2026-001,pouls,72,bpm,ok,1")
    assert trame is None and "source inconnue" in motif

    trame, motif = valider_trame("watch,inconnu,pouls,72,bpm,ok,1")
    assert trame is None and "identifiant invalide" in motif

    trame, motif = valider_trame("watch,AST2026-001,pouls,72,bpm,douteux,1")
    assert trame is None and "qualite inconnue" in motif


def test_seq_invalide():
    trame, motif = valider_trame("watch,AST2026-001,pouls,72,bpm,ok,-3")
    assert trame is None and "negatif" in motif

    trame, motif = valider_trame("watch,AST2026-001,pouls,72,bpm,ok,lettre")
    assert trame is None and "seq non entier" in motif


def test_capteur_hs_enregistre_meme_hors_plage():
    # P6 : Un capteur en panne est accepté même hors plage pour être tracé et signaler « capteur muet »
    trame, motif = valider_trame("watch,AST2026-001,pouls,0,bpm,capteur_hs,5")
    assert motif is None
    assert trame is not None
    assert trame["qualite"] == "capteur_hs"
    assert trame["valeur"] == 0.0
