"""Tests des routes de l'API FastAPI et des exigences du cahier des charges (CDC section 15)."""
import pytest
from fastapi.testclient import TestClient

from vigie.serveur import app
from vigie.services.database.connectdb import connecter
from vigie.services.database import alertes as db_alertes, bilans as db_bilans, actions as db_actions
from vigie.services.simulation.simulateur import generer, reinitialiser, SCENARIOS
from vigie.services.analyse.references import calculer_references

client = TestClient(app)


@pytest.fixture(autouse=True)
def initialiser_environnement():
    """Prépare la base locale pour les tests API."""
    con = connecter()
    reinitialiser(con)
    generer(con, scenario="nominal", jours=15)
    for a in ("AST2026-001", "AST2026-002", "AST2026-003", "AST2026-004"):
        calculer_references(con, a)
    con.close()


def test_route_astronautes():
    res = client.get("/api/astronautes")
    assert res.status_code == 200
    data = res.json()
    assert isinstance(data, list)
    assert len(data) >= 4
    assert "niveau_global" in data[0]


def test_route_etat():
    res = client.get("/api/etat/AST2026-001")
    assert res.status_code == 200
    data = res.json()
    assert data["astro"] == "AST2026-001"
    assert "niveau_global" in data
    assert "modules" in data
    assert "cardio" in data["modules"]
    assert "alertes" in data
    assert "croisements" in data
    assert "sources_muettes" in data


def test_route_etat_inconnu():
    res = client.get("/api/etat/AST_INCONNU")
    assert res.status_code == 404
    data = res.json()
    assert "detail" in data
    assert "code" in data
    assert data["code"] == "HTTP_404"


def test_route_mesures():
    res = client.get("/api/mesures/AST2026-001?mesure=pouls&jours=7")
    assert res.status_code == 200
    data = res.json()
    assert isinstance(data, list)
    if len(data) > 0:
        assert "valeur" in data[0]
        assert "create_at" in data[0]


def test_route_bilan():
    payload = {
        "astro": "AST2026-001",
        "humeur": 4,
        "stress": 2,
        "fatigue": 2,
        "symptomes": "aucun",
        "note": "bonne forme",
    }
    res = client.post("/api/bilan", json=payload)
    assert res.status_code == 200
    assert res.json()["ok"] is True


def test_route_examen():
    payload = {
        "astro": "AST2026-001",
        "type": "poids",
        "valeur": 74.5,
        "unite": "kg",
    }
    res = client.post("/api/examen", json=payload)
    assert res.status_code == 200
    assert res.json()["ok"] is True


def test_route_alertes_et_acquittement():
    con = connecter()
    a_id = db_alertes.inserer_alerte(con, "AST2026-001", "cardio", 1, "TEST_REGLE", "Alerte de test")
    con.close()

    res = client.get("/api/alertes/AST2026-001")
    assert res.status_code == 200
    alertes = res.json()
    assert any(a["id"] == a_id for a in alertes)

    # Acquittement
    res_acq = client.post(f"/api/alertes/{a_id}/acquitter")
    assert res_acq.status_code == 200
    assert res_acq.json()["ok"] is True


def test_route_assistant_501():
    payload = {"astro": "AST2026-001", "question": "Comment va mon coeur ?"}
    res = client.post("/api/assistant", json=payload)
    assert res.status_code == 501


def test_route_cabine():
    res = client.get("/api/cabine")
    assert res.status_code == 200
    assert isinstance(res.json(), dict)


def test_route_simulation_scenario():
    res = client.post("/api/simulation/scenario", json={"scenario": "derive_lente", "jours": 20})
    assert res.status_code == 200
    data = res.json()
    assert data["ok"] is True
    assert data["scenario"] == "derive_lente"


def test_route_sante():
    res = client.get("/api/sante")
    assert res.status_code == 200
    data = res.json()
    assert "etat" in data
    assert "statut" in data
    assert "trames_rejetees" in data
    assert "nb_mesures" in data
    assert "dernieres_trames" in data
    assert "modele_local" in data


# ---------------------------------------------------------------------
# 5 Nouveaux tests obligatoires (tests_a_ajouter)
# ---------------------------------------------------------------------

def test_1_quatre_scenarios_complets():
    """1. Pour chacun des 4 scénarios : POST /api/simulation/scenario renvoie 200, puis GET /api/etat/{astro} renvoie un JSON conforme."""
    for sc in SCENARIOS:
        res = client.post("/api/simulation/scenario", json={"scenario": sc, "jours": 28})
        assert res.status_code == 200, f"Échec du scénario {sc} : {res.text}"
        assert res.json()["ok"] is True

        res_etat = client.get("/api/etat/AST2026-001")
        assert res_etat.status_code == 200
        data = res_etat.json()
        for cle in ("astro", "t", "niveau_global", "modules", "alertes", "croisements", "sources_muettes"):
            assert cle in data, f"Clé {cle} absente pour le scénario {sc}"


def test_2_reinitialisation_base_avec_contraintes_fk_et_double_reset():
    """2. La réinitialisation fonctionne avec des données existantes (clés étrangères) et fonctionne deux fois de suite."""
    con = connecter()
    # Ajout préalable de bilans, alertes et actions liés aux clés étrangères
    b_id = db_bilans.inserer_bilan(con, "AST2026-001", 3, 2, 2, "test", "test")
    a_id = db_alertes.inserer_alerte(con, "AST2026-001", "cardio", 1, "REGLE_TEST", "Texte test")
    con.execute(
        "INSERT INTO actions (astro, alerte_id, t, description) VALUES (?, ?, ?, ?)",
        ("AST2026-001", a_id, "2026-11-15 12:00:00", "Action de test"),
    )
    con.commit()

    # Premier reset : ne doit pas lever d'IntegrityError
    reinitialiser(con)
    assert con.execute("SELECT COUNT(*) FROM bilans").fetchone()[0] == 0
    assert con.execute("SELECT COUNT(*) FROM alertes").fetchone()[0] == 0
    assert con.execute("SELECT COUNT(*) FROM astronautes").fetchone()[0] == 4

    # Deuxième reset consécutif immédiat
    reinitialiser(con)
    assert con.execute("SELECT COUNT(*) FROM astronautes").fetchone()[0] == 4
    con.close()


def test_3_panne_capteur_puis_nominal_sans_traces():
    """3. Après panne_capteur : sources_muettes contient 'pouls'. Après nominal : sources_muettes est vide et niveau_global vaut 0."""
    # Déclenchement de la panne capteur
    res_panne = client.post("/api/simulation/scenario", json={"scenario": "panne_capteur", "jours": 28})
    assert res_panne.status_code == 200
    etat_panne = client.get("/api/etat/AST2026-001").json()
    assert "pouls" in etat_panne["sources_muettes"], f"Pouls attendu dans {etat_panne['sources_muettes']}"

    # Enchaînement avec le scénario nominal
    res_nom = client.post("/api/simulation/scenario", json={"scenario": "nominal", "jours": 28})
    assert res_nom.status_code == 200
    etat_nom = client.get("/api/etat/AST2026-001").json()
    assert etat_nom["sources_muettes"] == [], "sources_muettes doit être vide après scénario nominal"
    assert etat_nom["niveau_global"] == 0, "niveau_global doit être à 0 en nominal"


def test_4_route_sante_base_vide_et_remplie():
    """4. GET /api/sante répond 200 sur base vide et sur base remplie, avec les champs documentés."""
    con = connecter()
    reinitialiser(con)
    con.close()

    # Base vide
    res_vide = client.get("/api/sante")
    assert res_vide.status_code == 200
    data_vide = res_vide.json()
    assert data_vide["etat"] in ("ok", "degrade")
    assert data_vide["nb_mesures"] == 0
    assert "trames_rejetees" in data_vide
    assert "dernieres_trames" in data_vide
    assert "modele_local" in data_vide

    # Base remplie
    con2 = connecter()
    generer(con2, scenario="nominal", jours=10)
    con2.close()

    res_pleine = client.get("/api/sante")
    assert res_pleine.status_code == 200
    data_pleine = res_pleine.json()
    assert data_pleine["nb_mesures"] > 0
    assert "watch" in data_pleine["dernieres_trames"]
    assert "age" in data_pleine["dernieres_trames"]["watch"]


def test_5_erreur_volontaire_format_json_sans_trace():
    """5. Une erreur volontaire (astronaute inconnu) renvoie 404 avec {"detail": ..., "code": ...} et non une trace."""
    res = client.get("/api/etat/AST_INCONNU_12345")
    assert res.status_code == 404
    data = res.json()
    assert "detail" in data
    assert "code" in data
    assert data["code"] == "HTTP_404"
    assert "Traceback" not in res.text
    assert "File " not in res.text
