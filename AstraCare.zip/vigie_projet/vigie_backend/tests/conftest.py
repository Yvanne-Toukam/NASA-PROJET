"""Fixtures partagées pour les tests unitaires et d'intégration Vigie."""
import pytest
from vigie.services.database.connectdb import connecter
from vigie.services.database import astronaute


@pytest.fixture
def con():
    """Connexion SQLite en mémoire entièrement initialisée pour un test."""
    c = connecter(":memory:")
    # Insertion des astronautes par défaut pour les tests de clés étrangères
    astronaute.inserer_astronaute(c, "Orion", "Commandant", "commandant", astro_id="AST2026-001")
    astronaute.inserer_astronaute(c, "Lyra", "Ingénieure", "ingenieur", astro_id="AST2026-002")
    astronaute.inserer_astronaute(c, "Vega", "Médecin", "medecin", astro_id="AST2026-003")
    astronaute.inserer_astronaute(c, "Altaïr", "Pilote", "pilote", astro_id="AST2026-004")
    yield c
    c.close()
