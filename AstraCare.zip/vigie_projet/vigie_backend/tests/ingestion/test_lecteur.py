import sqlite3
from pathlib import Path

import pytest

from vigie.services.database import systeme, trames_rejetees
from vigie.services.ingestion.lecteur_serie import traiter_ligne

SCHEMA = Path(__file__).resolve().parents[2] / "vigie" / "services" / "database" / "database.sql"
ASTRO = "AST2026-001"


@pytest.fixture
def con():
    c = sqlite3.connect(":memory:")
    c.row_factory = sqlite3.Row
    c.executescript(SCHEMA.read_text(encoding="utf-8"))
    yield c
    c.close()


def test_trame_valide_enregistree(con):
    assert traiter_ligne(con, f"watch,{ASTRO},pouls,72,bpm,ok,1") == "ok"
    assert con.execute("SELECT COUNT(*) FROM mesures").fetchone()[0] == 1
    assert systeme.get_valeur(con, "derniere_trame_watch") is not None


def test_trame_invalide_comptee_et_tracee(con):
    assert traiter_ligne(con, f"watch,{ASTRO},pouls,999,bpm,ok,1") == "rejetee"
    assert con.execute("SELECT COUNT(*) FROM mesures").fetchone()[0] == 0
    assert systeme.get_valeur(con, "trames_rejetees") == "1"
    assert "hors plage" in trames_rejetees.select_dernieres_trames(con)[0]["motif"]


def test_doublon_ignore(con):
    ligne = f"watch,{ASTRO},pouls,72,bpm,ok,1"
    assert traiter_ligne(con, ligne) == "ok"
    assert traiter_ligne(con, ligne) == "doublon"
    assert con.execute("SELECT COUNT(*) FROM mesures").fetchone()[0] == 1
    assert systeme.get_valeur(con, "trames_doublons") == "1"


def test_capteur_hs_enregistre_et_signale(con):
    assert traiter_ligne(con, f"watch,{ASTRO},spo2,90,pct,capteur_hs,2") == "ok"
    assert systeme.get_valeur(con, f"capteur_muet_{ASTRO}_spo2") == "1"