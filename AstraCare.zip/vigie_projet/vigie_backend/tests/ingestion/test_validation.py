import pytest

from vigie.services.ingestion.contrat import valider_trame

ASTRO = "AST2026-001"


def test_trame_valide():
    trame, motif = valider_trame(f"watch,{ASTRO},pouls,72,bpm,ok,1042")
    assert motif is None
    assert trame == {"source": "watch", "astro": ASTRO, "mesure": "pouls",
                     "valeur": 72.0, "unite": "bpm", "qualite": "ok", "seq": 1042}


def test_trame_cabine_avec_zone():
    trame, motif = valider_trame("cab,poste_pilotage,co2,4577,ppm,ok,5")
    assert motif is None and trame["astro"] == "poste_pilotage"


def test_valeur_decimale():
    trame, _ = valider_trame(f"watch,{ASTRO},temp_peau,36.8,degC,ok,1")
    assert trame["valeur"] == 36.8


@pytest.mark.parametrize("ligne", [
    "",                                              # vide
    f"watch,{ASTRO},pouls,72,bpm,ok",                # 6 champs
    f"watch,{ASTRO},pouls,72,bpm,ok,1,en_trop",      # 8 champs
    f"montre,{ASTRO},pouls,72,bpm,ok,1",             # source inconnue
    f"watch,{ASTRO},tachycardie,72,bpm,ok,1",        # mesure inconnue
    f"watch,{ASTRO},pouls,abc,bpm,ok,1",             # valeur non numérique
    f"watch,{ASTRO},pouls,nan,bpm,ok,1",             # NaN
    f"watch,{ASTRO},pouls,300,bpm,ok,1",             # hors plage (haut)
    f"watch,{ASTRO},pouls,10,bpm,ok,1",              # hors plage (bas)
    f"watch,{ASTRO},pouls,72,mmHg,ok,1",             # mauvaise unité
    f"watch,{ASTRO},pouls,72,bpm,douteux,1",         # qualité inconnue
    f"watch,{ASTRO},pouls,72,bpm,ok,x",              # seq non entier
    f"watch,{ASTRO},pouls,72,bpm,ok,-3",             # seq négatif
    "watch,astro1,pouls,72,bpm,ok,1",                # ancien format d'identifiant
    f"cab,{ASTRO},co2,800,ppm,ok,1",                 # une personne sur un capteur de cabine
    "watch,module_vie,pouls,72,bpm,ok,1",            # une zone sur une montre
    f"cab,{ASTRO},pouls,72,bpm,ok,1",                # pouls envoyé par la mauvaise source
])
def test_trames_invalides_rejetees(ligne):
    trame, motif = valider_trame(ligne)
    assert trame is None and motif