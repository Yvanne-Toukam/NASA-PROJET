"""Tests du moteur d'analyse et des 4 scénarios de démonstration (CDC section 13)."""
import datetime as dt

from vigie.services.database.connectdb import connecter
from vigie.services.database import systeme, trames_rejetees
from vigie.services.ingestion.lecteur_serie import traiter_ligne
from vigie.services.analyse.moteur import analyser, enregistrer_alertes
from vigie.services.analyse.references import calculer_references
from vigie.services.analyse.statistiques import zscore, cusum
from vigie.services.simulation.simulateur import generer, ASTROS

DEBUT = dt.datetime(2026, 10, 1, 0, 0, 0)
ASTRO_CIBLE = "AST2026-001"


def preparer_base_scenario(scenario, jours=28):
    con = connecter(":memory:")
    generer(con, scenario=scenario, jours=jours, debut=DEBUT)
    for a in ASTROS:
        calculer_references(con, a)
    return con


def test_zscore_et_cusum():
    assert zscore(12, 10, 2) == 1.0
    assert zscore(12, 10, 0) > 1000  # protection division par zéro
    assert not cusum([0.1, -0.2, 0.3, 0.0] * 10)
    assert cusum([1.5] * 10)  # glissement durable détecté
    assert not cusum([4.0])   # une seule valeur isolée ne déclenche jamais


def test_scenario_nominal_sans_fausse_alerte():
    con = preparer_base_scenario("nominal")
    for a in ASTROS:
        res = analyser(con, a)
        assert res["niveau_global"] == 0, f"Alerte inattendue pour {a} : {res['alertes']}"
        assert res["alertes"] == []


def test_scenario_derive_lente_detectee_avant_seuil():
    con = preparer_base_scenario("derive_lente")
    # Analyse au 18ème jour : la dérive CUSUM doit être active alors que le seuil N1 n'est pas franchi
    jusqua = (DEBUT + dt.timedelta(days=17, hours=23)).strftime("%Y-%m-%d %H:%M:%S")
    res = analyser(con, ASTRO_CIBLE, jusqua=jusqua)
    regles = [a["regle"] for a in res["alertes"]]
    assert "DERIVE_POULS" in regles, f"DERIVE_POULS manquant dans {regles}"
    assert not any(x.startswith("SEUIL_POULS") for x in regles), "Le seuil classique ne doit pas être franchi si tôt"
    # Les autres astronautes restent nominaux
    assert analyser(con, "AST2026-002")["niveau_global"] == 0


def test_croisement_causes_effets():
    con = preparer_base_scenario("derive_lente")
    res = analyser(con, ASTRO_CIBLE)
    # Dans derive lente, la température monte et le sommeil baisse
    regles_croisees = [c["regle"] for c in res["croisements"]]
    assert "CR-01" in regles_croisees or "CR-02" in regles_croisees


def test_scenario_urgence_niveau_critique():
    con = preparer_base_scenario("urgence")
    res = analyser(con, ASTRO_CIBLE)
    assert res["niveau_global"] == 2
    regles = {a["regle"] for a in res["alertes"]}
    assert "SEUIL_POULS_N2" in regles or "SEUIL_SPO2_N2" in regles


def test_scenario_panne_capteur_muet_et_confiance():
    con = preparer_base_scenario("panne_capteur")
    res = analyser(con, ASTRO_CIBLE)
    assert "pouls" in res["sources_muettes"]
    ind_pouls = [i for i in res["modules"]["cardio"]["indicateurs"] if i["mesure"] == "pouls"][0]
    assert ind_pouls["confiance"] <= 0.4  # confiance fortement dégradée (P6)


def test_alertes_enregistrees_sans_doublon():
    con = preparer_base_scenario("urgence")
    res = analyser(con, ASTRO_CIBLE)
    nb1 = enregistrer_alertes(con, res)
    assert nb1 > 0
    # Ré-exécution : aucune alerte active non acquittée ne doit être ré-insérée
    nb2 = enregistrer_alertes(con, res)
    assert nb2 == 0


def test_lecteur_serie_rejets_et_doublons():
    con = connecter(":memory:")
    ok_trame = "watch,AST2026-001,pouls,72,bpm,ok,1"
    assert traiter_ligne(con, ok_trame) == "ok"
    assert traiter_ligne(con, ok_trame) == "doublon"
    assert traiter_ligne(con, "trame_invalide_nimporte_quoi") == "rejetee"
    assert traiter_ligne(con, "watch,AST2026-001,pouls,999,bpm,ok,2") == "rejetee"
    assert systeme.get_valeur(con, "trames_rejetees") == "2"
    assert con.execute("SELECT COUNT(*) FROM mesures").fetchone()[0] == 1
    assert con.execute("SELECT COUNT(*) FROM trames_rejetees").fetchone()[0] == 2
