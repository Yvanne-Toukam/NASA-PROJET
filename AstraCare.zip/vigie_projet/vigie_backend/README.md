# Vigie : backend Python

Installation (une fois, avec connexion) :
    python -m venv venv && venv\Scripts\activate      (Linux : source venv/bin/activate)
    pip install -r requirements.txt

Donnees de demonstration (sans Proteus) :
    python -m vigie.simulateur --scenario derive_lente --jours 28
    scenarios : nominal, derive_lente, urgence, panne_capteur

Tests :
    pytest

API locale :
    uvicorn vigie.serveur:app --host 127.0.0.1 --port 8000
    documentation interactive : http://127.0.0.1:8000/docs

Avec Proteus (plus tard) :
    python -m vigie.lecteur_serie        (lit COM2 a 9600 bauds)
