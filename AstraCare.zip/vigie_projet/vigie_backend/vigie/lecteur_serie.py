"""Façade rétro-compatible du lecteur série."""
from vigie.services.ingestion.lecteur_serie import (
    traiter_ligne as _traiter_ligne,
    boucle as _boucle,
    maintenant,
)


def traiter_ligne(con, brut, t_recu=None):
    """Garde la compatibilité de valeur de retour avec les anciens tests ('rejet' vs 'rejetee')."""
    res = _traiter_ligne(con, brut, t=t_recu)
    if res == "rejetee":
        return "rejet"
    return res


def boucle(port="COM2", debit=9600, base=None):
    from vigie.services.database.connectdb import connecter
    return _boucle(lambda: connecter(base), port=port, debit=debit)
