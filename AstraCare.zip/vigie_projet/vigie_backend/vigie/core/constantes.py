"""Catalogue des mesures, plages autorisées, sources et modules de Vigie."""

# Sources matérielles acceptées
SOURCES = {"watch", "dosi", "cab", "sante"}

# Niveaux de qualité d'un signal
QUALITES = {"ok", "bruit", "capteur_hs"}

# Modules de santé surveillés (P1/P2)
MODULES_SANTE = ["cardio", "os_muscles", "immunite", "comportement"]

# Catalogue strict des 15 mesures autorisées :
# mesure -> (source_attendue, unite, minimum, maximum, module)
CATALOGUE = {
    "pouls":        ("watch", "bpm",  20.0, 250.0,  "cardio"),
    "hrv":          ("watch", "ms",    5.0, 200.0,  "cardio"),
    "spo2":         ("watch", "pct",  70.0, 100.0,  "cardio"),
    "tension_sys":  ("sante", "mmHg", 60.0, 220.0,  "cardio"),
    "tension_dia":  ("sante", "mmHg", 30.0, 140.0,  "cardio"),
    "resp":         ("watch", "/min",  4.0,  50.0,  "cardio"),
    "temp_peau":    ("watch", "degC", 30.0,  42.0,  "immunite"),
    "activite":     ("watch", "min",   0.0, 600.0,  "os_muscles"),
    "force_main":   ("sante", "kg",    5.0,  80.0,  "os_muscles"),
    "sommeil":      ("watch", "h",     0.0,  14.0,  "comportement"),
    "debit_dose":   ("dosi",  "uSvh",  0.0, 5000.0, "immunite"),
    "co2":          ("cab",   "ppm", 300.0, 20000.0, "cabine"),
    "o2":           ("cab",   "pct",  15.0,  25.0,  "cabine"),
    "temp_cabine":  ("cab",   "degC", 10.0,  40.0,  "cabine"),
    "humidite":     ("cab",   "pct",   5.0,  95.0,  "cabine"),
}

# Nombre de champs obligatoires dans une trame série
NB_CHAMPS_TRAME = 7

# Format de date unique et immuable dans tout le système (UTC)
FORMAT_DATE_UTC = "%Y-%m-%d %H:%M:%S"
