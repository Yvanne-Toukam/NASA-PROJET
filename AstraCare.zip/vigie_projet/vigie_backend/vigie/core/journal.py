"""Journalisation unifiée (logging) pour le projet Vigie."""
import logging
import sys


def configurer_journal(niveau=logging.INFO):
    """Initialise le format des journaux en console sans dépendance externe."""
    logging.basicConfig(
        level=niveau,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        stream=sys.stdout,
        force=True,
    )
    return logging.getLogger("vigie")


journal = logging.getLogger("vigie")
