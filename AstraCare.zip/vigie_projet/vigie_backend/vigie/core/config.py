"""Configuration globale de Vigie : lecture unique des fichiers YAML."""
from pathlib import Path
try:
    import yaml
except ImportError:
    yaml = None


# Répertoire racine de la configuration
RACINE_PROJET = Path(__file__).resolve().parents[2]
DOSSIER_CONFIG = RACINE_PROJET / "config"


def charger_yaml(chemin_relatif_ou_absolu):
    """Charge un fichier YAML de façon sécurisée."""
    if yaml is None:
        # Fallback de secours si pyyaml n'est pas encore installé
        return {
            "jours_base": 14,
            "cusum": {"k": 0.5, "h": 5.0},
            "indicateurs": {
                "pouls": {"module": "cardio", "libelle": "Pouls au repos", "fenetre": 1, "type": "relatif_haut", "n1": 10, "n2": 25, "abs_min": 40, "abs_max": 120, "derive": "haut"},
                "spo2": {"module": "cardio", "libelle": "SpO2", "fenetre": 1, "type": "seuil_bas", "n1": 95, "n2": 92},
                "resp": {"module": "cardio", "libelle": "Respiration", "fenetre": 1, "type": "seuil_haut", "n1": 20, "n2": 25},
                "hrv": {"module": "cardio", "libelle": "Variabilité cardiaque", "fenetre": 1, "type": "suivi"},
                "temp_peau": {"module": "immunite", "libelle": "Température", "fenetre": 1, "type": "seuil_haut", "n1": 37.8, "n2": 38.5},
                "sommeil": {"module": "comportement", "libelle": "Sommeil", "fenetre": 3, "type": "seuil_bas", "n1": 6, "n2": 5, "derive": "bas"},
                "activite": {"module": "os_muscles", "libelle": "Exercice", "fenetre": 7, "type": "cible_bas", "cible": 120, "n1": 0.6, "n2": 0.3},
            }
        }
    chemin = Path(chemin_relatif_ou_absolu)
    if not chemin.is_absolute():
        chemin = RACINE_PROJET / chemin
    if not chemin.exists():
        # Repli dans vigie_backend si exécuté depuis la racine vigie_projet
        alt = RACINE_PROJET / "vigie_backend" / chemin_relatif_ou_absolu
        if alt.exists():
            chemin = alt
    with open(chemin, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def charger_seuils(chemin=None):
    """Charge les seuils d'analyse (seuils.yaml)."""
    return charger_yaml(chemin or (DOSSIER_CONFIG / "seuils.yaml"))


def charger_regles(chemin=None):
    """Charge les règles de croisement (regles.yaml)."""
    return charger_yaml(chemin or (DOSSIER_CONFIG / "regles.yaml"))


def charger_app(chemin=None):
    """Charge les paramètres d'application (app.yaml)."""
    return charger_yaml(chemin or (DOSSIER_CONFIG / "app.yaml"))
