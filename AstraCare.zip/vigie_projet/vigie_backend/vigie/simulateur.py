"""Façade rétro-compatible du simulateur de secours (CDC 12.3)."""
import argparse
from vigie.services.simulation.simulateur import (
    generer as _generer,
    reinitialiser as _reinitialiser,
    SCENARIOS,
    ASTROS as _ASTROS,
    ALIAS_ASTROS,
)
from vigie.services.analyse.references import calculer_references
from vigie.services.database.connectdb import connecter

ASTROS = _ASTROS


def reinitialiser(con):
    return _reinitialiser(con)


def generer(con, scenario="nominal", jours=28, jours_base=14, debut=None, graine=42):
    return _generer(con, scenario=scenario, jours=jours, jours_base=jours_base, debut=debut, graine=graine)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Simulateur de mesures Vigie")
    ap.add_argument("--scenario", default="nominal", choices=SCENARIOS)
    ap.add_argument("--jours", type=int, default=28)
    ap.add_argument("--base", default=None)
    args = ap.parse_args()

    con = connecter(args.base)
    reinitialiser(con)
    nb = generer(con, scenario=args.scenario, jours=args.jours)
    print(f"{nb} trames générées pour le scénario '{args.scenario}'")
    for a in ASTROS:
        calculer_references(con, a)
    print("Références personnelles calculées.")
