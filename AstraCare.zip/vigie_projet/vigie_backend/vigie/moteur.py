"""Façade rétro-compatible du moteur d'analyse."""
from vigie.services.analyse.moteur import analyser, enregistrer_alertes
from vigie.services.analyse.references import calculer_references
from vigie.services.analyse.statistiques import zscore, cusum, serie_journaliere as serie_jour

__all__ = [
    "analyser",
    "enregistrer_alertes",
    "calculer_references",
    "zscore",
    "cusum",
    "serie_jour",
]
