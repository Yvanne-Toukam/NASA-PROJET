"""Acces SQLite (cahier des charges, section 11)."""
import os
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS astronautes (id TEXT PRIMARY KEY, nom TEXT, role TEXT);
CREATE TABLE IF NOT EXISTS references_perso (astro TEXT, mesure TEXT, moyenne REAL, ecart_type REAL,
  n INTEGER, periode TEXT, PRIMARY KEY (astro, mesure));
CREATE TABLE IF NOT EXISTS mesures (id INTEGER PRIMARY KEY AUTOINCREMENT, astro TEXT, source TEXT,
  mesure TEXT, valeur REAL, unite TEXT, qualite TEXT, seq INTEGER, t_recu TEXT);
CREATE INDEX IF NOT EXISTS idx_mes ON mesures (astro, mesure, t_recu);
CREATE UNIQUE INDEX IF NOT EXISTS idx_seq ON mesures (source, astro, seq);
CREATE TABLE IF NOT EXISTS bilans (id INTEGER PRIMARY KEY AUTOINCREMENT, astro TEXT, t TEXT,
  humeur INTEGER, stress INTEGER, fatigue INTEGER, symptomes TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS examens (id INTEGER PRIMARY KEY AUTOINCREMENT, astro TEXT, t TEXT,
  type TEXT, valeur REAL, unite TEXT);
CREATE TABLE IF NOT EXISTS alertes (id INTEGER PRIMARY KEY AUTOINCREMENT, astro TEXT, t TEXT,
  module TEXT, niveau INTEGER, regle TEXT, detail_json TEXT, acquittee INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS conversations (id INTEGER PRIMARY KEY AUTOINCREMENT, astro TEXT, t TEXT,
  question TEXT, reponse TEXT, sources_json TEXT);
CREATE TABLE IF NOT EXISTS systeme (cle TEXT PRIMARY KEY, valeur TEXT);
"""


def connecter(chemin="data/vigie.db"):
    if chemin != ":memory:":
        os.makedirs(os.path.dirname(os.path.abspath(chemin)), exist_ok=True)
    con = sqlite3.connect(chemin, timeout=5)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    return con


def lignes(con, sql, params=()):
    """Resultat d'une requete sous forme de liste de dictionnaires."""
    cur = con.execute(sql, params)
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def inserer_mesure(con, t, t_recu):
    """Insere une trame validee. Renvoie False si c'est un doublon (meme source, astro, seq)."""
    cur = con.execute(
        "INSERT OR IGNORE INTO mesures(astro,source,mesure,valeur,unite,qualite,seq,t_recu) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (t["astro"], t["source"], t["mesure"], t["valeur"], t["unite"], t["qualite"], t["seq"], t_recu))
    return cur.rowcount == 1


def incrementer(con, cle):
    con.execute("INSERT INTO systeme(cle,valeur) VALUES (?, '1') "
                "ON CONFLICT(cle) DO UPDATE SET valeur = CAST(valeur AS INTEGER) + 1", (cle,))


def ecrire_systeme(con, cle, valeur):
    con.execute("INSERT INTO systeme(cle,valeur) VALUES (?,?) "
                "ON CONFLICT(cle) DO UPDATE SET valeur = excluded.valeur", (cle, str(valeur)))


def lire_systeme(con):
    return {c: v for c, v in con.execute("SELECT cle, valeur FROM systeme")}
