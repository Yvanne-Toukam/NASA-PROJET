-- ---------------------------------------------------------------------
-- 1. ASTRONAUTES : une ligne par membre d'équipage
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS astronautes (
    id             TEXT PRIMARY KEY NOT NULL,
    first_name     TEXT NOT NULL,
    last_name      TEXT NOT NULL,
    role           TEXT NOT NULL,
    email_address  TEXT NOT NULL,
    phone_number   TEXT,
    statut         INTEGER NOT NULL DEFAULT 1 CHECK (statut IN (0, 1)),
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_at      TEXT DEFAULT NULL
);

-- ---------------------------------------------------------------------
-- 2. APPAREILS : relie chaque matériel (lunettes, dosimètre...) à sa personne
--    Pour le prototype elle peut rester vide : l'identifiant est déjà dans la trame.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS appareils (
    serie       TEXT PRIMARY KEY,                         -- numéro de série, ex. 'LUN-03'
    source      TEXT NOT NULL CHECK (source IN ('watch', 'dosi', 'cab', 'sante')),
    astro       TEXT REFERENCES astronautes(id),          -- NULL pour un appareil partagé (cabine)
    zone        TEXT,                                     -- 'cabine1' pour un capteur de cabine
    actif       INTEGER NOT NULL DEFAULT 1 CHECK (actif IN (0, 1))
);

-- ---------------------------------------------------------------------
-- 3. MESURES : le cœur du système, une ligne par trame valide
--    `astro` contient un astronaute OU une zone ('cabine1'), d'où l'absence de clé étrangère :
--    la validité de l'identifiant est contrôlée par la validation des trames.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mesures (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    astro    TEXT    NOT NULL,
    source   TEXT    NOT NULL,
    mesure   TEXT    NOT NULL,                           
    valeur   REAL    NOT NULL,
    unite    TEXT    NOT NULL,
    qualite  TEXT    NOT NULL DEFAULT 'ok' CHECK (qualite IN ('ok', 'bruit', 'capteur_hs')),
    seq      INTEGER NOT NULL,                            -- numéro de séquence envoyé par l'appareil
    create_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP                            -- heure de réception, ajoutée par Python
);
CREATE INDEX        IF NOT EXISTS idx_mesures_recherche ON mesures (astro, mesure, create_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_mesures_doublon   ON mesures (source, astro, seq);   -- anti-doublon

-- ---------------------------------------------------------------------
-- 4. REFERENCES_PERSO : la « normale » de chaque personne, pour chaque mesure
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS references_perso (
    astro          TEXT NOT NULL REFERENCES astronautes(id),
    mesure         TEXT NOT NULL,
    moyenne        REAL NOT NULL,
    ecart_type     REAL NOT NULL,
    n              INTEGER NOT NULL,                      -- nombre de points utilisés
    periode_debut  TEXT NOT NULL,                         -- (le CDC stockait un seul texte « début/fin »)
    periode_fin    TEXT NOT NULL,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (astro, mesure)
);

-- ---------------------------------------------------------------------
-- 5. BILANS : le bilan quotidien déclaré par l'astronaute
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bilans (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    astro      TEXT NOT NULL REFERENCES astronautes(id),
    t          TEXT NOT NULL,
    humeur     INTEGER NOT NULL CHECK (humeur  BETWEEN 1 AND 5),
    stress     INTEGER NOT NULL CHECK (stress  BETWEEN 1 AND 5),
    fatigue    INTEGER NOT NULL CHECK (fatigue BETWEEN 1 AND 5),
    symptomes  TEXT,
    note       TEXT,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_bilans_astro ON bilans (astro, t);

-- ---------------------------------------------------------------------
-- 6. EXAMENS : saisies manuelles (poids, densité osseuse, analyses)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS examens (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    astro   TEXT NOT NULL REFERENCES astronautes(id),
    t       TEXT NOT NULL,
    type    TEXT NOT NULL,
    valeur  REAL NOT NULL,
    unite   TEXT,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_examens_astro ON examens (astro, type, t);

-- ---------------------------------------------------------------------
-- 7. ALERTES : journal des alertes produites par le moteur
--    Seuls les niveaux 1 (à surveiller) et 2 (critique) sont enregistrés : le niveau 0 est « tout va bien ».
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alertes (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    astro             TEXT NOT NULL REFERENCES astronautes(id),
    t                 TEXT NOT NULL,
    module            TEXT NOT NULL,                      -- cardio, os_muscles, immunite, comportement, croisement
    niveau            INTEGER NOT NULL CHECK (niveau IN (1, 2)),
    regle             TEXT NOT NULL,                      -- 'DERIVE_POULS', 'CR-01'...
    texte_court       TEXT,                               -- phrase prête à afficher
    detail_json       TEXT,                               -- valeurs et références qui ont déclenché l'alerte
    acquittee         INTEGER NOT NULL DEFAULT 0 CHECK (acquittee IN (0, 1)),
    t_acquittement    TEXT,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_alertes_astro ON alertes (astro, acquittee, t);

-- ---------------------------------------------------------------------
-- 8. ACTIONS : ce que l'astronaute a fait suite à une alerte (journal, exigence EF-16)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS actions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    astro       TEXT NOT NULL REFERENCES astronautes(id),
    alerte_id   INTEGER REFERENCES alertes(id),           -- NULL si l'action n'est liée à aucune alerte
    t           TEXT NOT NULL,
    description TEXT NOT NULL,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------
-- 9. TRAMES_REJETEES : trace des trames refusées (utile pour déboguer et pour le jury)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS trames_rejetees (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    t       TEXT NOT NULL,
    ligne   TEXT NOT NULL,                                -- la ligne brute reçue
    motif   TEXT  ,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP                                        -- 'hors plage', 'champ manquant'...
);

-- ---------------------------------------------------------------------
-- 10. CONVERSATIONS : historique de l'assistant (rempli par la partie IA)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversations (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    astro         TEXT NOT NULL REFERENCES astronautes(id),
    t             TEXT NOT NULL,
    question      TEXT NOT NULL,
    reponse       TEXT,
    sources_json  TEXT,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------
-- 11. SYSTEME : petits compteurs et états (âge des sources, mode dégradé...)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS systeme (
    cle     TEXT PRIMARY KEY,
    valeur  TEXT,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);