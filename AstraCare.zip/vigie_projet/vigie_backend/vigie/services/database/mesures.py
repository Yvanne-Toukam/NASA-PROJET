"""Fonctions d'accès à la table mesures (coeur de l'acquisition Vigie)."""
import sqlite3
from datetime import datetime, timedelta, timezone


def maintenant():
    """Date et heure courante en UTC au format strict AAAA-MM-JJ HH:MM:SS."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def inserer_mesure(con, astro, source, mesure, valeur, unite, seq, qualite="ok", create_at=None):
    """Insère une mesure validée dans la table mesures.
    
    Renvoie l'id inséré, ou None s'il s'agit d'un doublon exact (même source, astro et numéro seq).
    Lève les vraies erreurs d'intégrité (par exemple si qualite viole la contrainte CHECK).
    """
    timestamp = create_at or maintenant()
    try:
        curseur = con.execute(
            "INSERT INTO mesures (astro, source, mesure, valeur, unite, qualite, seq, create_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (astro, source, mesure, valeur, unite, qualite, seq, timestamp),
        )
        con.commit()
        return curseur.lastrowid
    except sqlite3.IntegrityError as e:
        # On vérifie si c'est le doublon attendu sur idx_mesures_doublon (source, astro, seq)
        deja_present = con.execute(
            "SELECT 1 FROM mesures WHERE source = ? AND astro = ? AND seq = ?",
            (source, astro, seq),
        ).fetchone()
        if deja_present:
            return None
        # Si ce n'est pas un doublon (ex. violation de CHECK sur qualite), on propage la vraie erreur
        raise e


def select_mesure_id(con, mesure_id):
    """Récupère une mesure par son identifiant unique."""
    ligne = con.execute("SELECT * FROM mesures WHERE id = ?", (mesure_id,)).fetchone()
    return dict(ligne) if ligne else None


def select_mesures_astro(con, astro, mesure, limite=100):
    """Les dernières mesures d'un paramètre pour un astronaute (du plus récent au plus ancien)."""
    lignes = con.execute(
        "SELECT * FROM mesures WHERE astro = ? AND mesure = ? "
        "ORDER BY create_at DESC LIMIT ?",
        (astro, mesure, limite),
    ).fetchall()
    return [dict(l) for l in lignes]


def select_mesures_jours(con, astro, mesure=None, jours=14):
    """Récupère les mesures d'un astronaute sur les N derniers jours disponibles en base."""
    fin_ligne = con.execute("SELECT MAX(create_at) FROM mesures WHERE astro = ?", (astro,)).fetchone()
    if not fin_ligne or not fin_ligne[0]:
        return []
    fin_str = fin_ligne[0]
    try:
        fin_dt = datetime.strptime(fin_str[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        fin_dt = datetime.fromisoformat(fin_str)
    debut_str = (fin_dt - timedelta(days=jours)).strftime("%Y-%m-%d %H:%M:%S")

    if mesure:
        lignes = con.execute(
            "SELECT create_at, valeur, qualite, mesure, unite FROM mesures "
            "WHERE astro = ? AND mesure = ? AND create_at >= ? "
            "ORDER BY create_at ASC",
            (astro, mesure, debut_str),
        ).fetchall()
    else:
        lignes = con.execute(
            "SELECT create_at, valeur, qualite, mesure, unite FROM mesures "
            "WHERE astro = ? AND create_at >= ? "
            "ORDER BY create_at ASC",
            (astro, debut_str),
        ).fetchall()
    return [dict(l) for l in lignes]


def select_mesures_serie(con, astro, mesure="pouls", jours=14, depuis=None, limite=500):
    """Récupère la série chronologique pour les courbes de mesures en direct.
    
    Si `depuis` est spécifié (exclusif), ne récupère que les nouveaux points arrivés après cet instant.
    Sinon, extrait jusqu'à `limite` points les plus récents dans la fenêtre temporelle demandée,
    ordonnés chronologiquement (croissant) pour un tracé direct.
    """
    if depuis:
        lignes = con.execute(
            "SELECT create_at, valeur, qualite, mesure, unite FROM mesures "
            "WHERE astro = ? AND mesure = ? AND create_at > ? "
            "ORDER BY create_at ASC, id ASC LIMIT ?",
            (astro, mesure, depuis, limite),
        ).fetchall()
    else:
        max_row = con.execute("SELECT MAX(create_at) FROM mesures WHERE astro = ?", (astro,)).fetchone()
        if not max_row or not max_row[0]:
            return []
        fin_str = max_row[0]
        try:
            fin_dt = datetime.strptime(fin_str[:19], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            fin_dt = datetime.fromisoformat(fin_str)
        debut_str = (fin_dt - timedelta(days=jours)).strftime("%Y-%m-%d %H:%M:%S")

        lignes = con.execute(
            "SELECT create_at, valeur, qualite, mesure, unite FROM ("
            "  SELECT id, create_at, valeur, qualite, mesure, unite FROM mesures "
            "  WHERE astro = ? AND mesure = ? AND create_at >= ? "
            "  ORDER BY create_at DESC, id DESC LIMIT ?"
            ") ORDER BY create_at ASC, id ASC",
            (astro, mesure, debut_str, limite),
        ).fetchall()

    return [
        {
            "t": l["create_at"],
            "valeur": float(l["valeur"]),
            "qualite": l["qualite"],
            "mesure": l["mesure"],
            "unite": l["unite"],
        }
        for l in lignes
    ]


def select_mesures_periode(con, astro, mesure, debut, fin, qualite="ok"):
    """Mesures d'une période donnée, par défaut uniquement celles de bonne qualité."""
    lignes = con.execute(
        "SELECT * FROM mesures WHERE astro = ? AND mesure = ? AND qualite = ? "
        "AND create_at BETWEEN ? AND ? ORDER BY create_at ASC",
        (astro, mesure, qualite, debut, fin),
    ).fetchall()
    return [dict(l) for l in lignes]


def select_derniere_mesure(con, astro, mesure):
    """Récupère la toute dernière mesure enregistrée pour un astronaute et un paramètre."""
    ligne = con.execute(
        "SELECT * FROM mesures WHERE astro = ? AND mesure = ? "
        "ORDER BY create_at DESC, id DESC LIMIT 1",
        (astro, mesure),
    ).fetchone()
    return dict(ligne) if ligne else None


def select_dernieres_mesures_zone(con, zone):
    """Récupère la dernière valeur de chaque paramètre d'environnement pour une zone de cabine."""
    lignes = con.execute(
        "SELECT m1.* FROM mesures m1 "
        "INNER JOIN ("
        "   SELECT mesure, MAX(id) as max_id FROM mesures WHERE astro = ? GROUP BY mesure"
        ") m2 ON m1.id = m2.max_id",
        (zone,),
    ).fetchall()
    return [dict(l) for l in lignes]


def stats_mesure(con, astro, mesure, debut, fin):
    """Calcule la moyenne, l'écart-type et le nombre d'échantillons sur une période (qualité ok)."""
    valeurs = [
        l[0]
        for l in con.execute(
            "SELECT valeur FROM mesures WHERE astro = ? AND mesure = ? AND qualite = 'ok' "
            "AND create_at BETWEEN ? AND ?",
            (astro, mesure, debut, fin),
        ).fetchall()
    ]
    n = len(valeurs)
    if n == 0:
        return None
    moyenne = sum(valeurs) / n
    variance = sum((v - moyenne) ** 2 for v in valeurs) / n
    return {"moyenne": moyenne, "ecart_type": variance ** 0.5, "n": n}


def compter_mesures(con, astro=None):
    """Compte le nombre total de mesures enregistrées."""
    if astro:
        return con.execute("SELECT COUNT(*) FROM mesures WHERE astro = ?", (astro,)).fetchone()[0]
    return con.execute("SELECT COUNT(*) FROM mesures").fetchone()[0]


def purger_mesures(con):
    """Supprime toutes les mesures (utile pour réinitialiser la simulation)."""
    curseur = con.execute("DELETE FROM mesures")
    con.commit()
    return curseur.rowcount
