
def inserer_appareil(con, serie, source, astro=None, zone=None):
    """source : 'watch', 'dosi', 'cab' ou 'sante'. astro = None pour un appareil partagé."""
    con.execute(
        "INSERT INTO appareils (serie, source, astro, zone) VALUES (?, ?, ?, ?)",
        (serie, source, astro, zone),
    )
    con.commit()
    return serie


def select_appareil_serie(con, serie):
    ligne = con.execute("SELECT * FROM appareils WHERE serie = ?", (serie,)).fetchone()
    return dict(ligne) if ligne else None


def select_appareils_astro(con, astro_id, actif_seulement=True):
    requete = "SELECT * FROM appareils WHERE astro = ?"
    if actif_seulement:
        requete += " AND actif = 1"
    return [dict(l) for l in con.execute(requete, (astro_id,)).fetchall()]


def select_appareils_source(con, source):
    lignes = con.execute(
        "SELECT * FROM appareils WHERE source = ? AND actif = 1", (source,)
    ).fetchall()
    return [dict(l) for l in lignes]


def update_actif(con, serie, actif):
    """actif : 1 = en service, 0 = hors service. Renvoie True si l'appareil existait."""
    curseur = con.execute("UPDATE appareils SET actif = ? WHERE serie = ?", (actif, serie))
    con.commit()
    return curseur.rowcount == 1


def update_attribution(con, serie, astro_id):
    """Réattribue un appareil à un autre astronaute."""
    curseur = con.execute("UPDATE appareils SET astro = ? WHERE serie = ?", (astro_id, serie))
    con.commit()
    return curseur.rowcount == 1