"""Gestion des auto-évaluations quotidiennes de l'astronaute (bilans déclaratifs)."""
from datetime import datetime, timezone


def maintenant():
    """Date et heure courante UTC au format strict AAAA-MM-JJ HH:MM:SS."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def inserer_bilan(con, astro, humeur, stress, fatigue, symptomes=None, note=None, t=None):
    """Insère un bilan quotidien. humeur, stress, fatigue sont des entiers de 1 à 5."""
    curseur = con.execute(
        "INSERT INTO bilans (astro, t, humeur, stress, fatigue, symptomes, note) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (astro, t or maintenant(), int(humeur), int(stress), int(fatigue), symptomes or "", note or ""),
    )
    con.commit()
    return curseur.lastrowid


def select_bilan_id(con, bilan_id):
    """Récupère un bilan par son identifiant unique."""
    ligne = con.execute("SELECT * FROM bilans WHERE id = ?", (bilan_id,)).fetchone()
    return dict(ligne) if ligne else None


def select_bilans_astro(con, astro, limite=30):
    """Historique des bilans de l'astronaute, du plus récent au plus ancien."""
    lignes = con.execute(
        "SELECT * FROM bilans WHERE astro = ? ORDER BY t DESC LIMIT ?", (astro, limite)
    ).fetchall()
    return [dict(l) for l in lignes]


def select_dernier_bilan(con, astro):
    """Récupère le dernier bilan quotidien renseigné par l'astronaute."""
    ligne = con.execute(
        "SELECT * FROM bilans WHERE astro = ? ORDER BY t DESC, id DESC LIMIT 1", (astro,)
    ).fetchone()
    return dict(ligne) if ligne else None


def update_bilan(con, bilan_id, humeur, stress, fatigue, symptomes=None, note=None):
    """Met à jour un bilan existant."""
    curseur = con.execute(
        "UPDATE bilans SET humeur = ?, stress = ?, fatigue = ?, symptomes = ?, note = ?, "
        "updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (humeur, stress, fatigue, symptomes, note, bilan_id),
    )
    con.commit()
    return curseur.rowcount == 1


def supprimer_bilan(con, bilan_id):
    """Supprime un bilan."""
    curseur = con.execute("DELETE FROM bilans WHERE id = ?", (bilan_id,))
    con.commit()
    return curseur.rowcount == 1


def purger_bilans(con):
    """Supprime tous les bilans."""
    curseur = con.execute("DELETE FROM bilans")
    con.commit()
    return curseur.rowcount
