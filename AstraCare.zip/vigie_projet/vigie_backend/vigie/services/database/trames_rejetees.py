"""Table trames_rejetees : traçabilité des rejets (P4/P6, explicable et auditable)."""
from datetime import datetime, timezone


def maintenant():
    """Date et heure courante UTC au format strict AAAA-MM-JJ HH:MM:SS."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def inserer_trame_rejetee(con, ligne, motif=None, t=None):
    """Enregistre une trame rejetée avec la raison précise du rejet."""
    curseur = con.execute(
        "INSERT INTO trames_rejetees (t, ligne, motif) VALUES (?, ?, ?)",
        (t or maintenant(), ligne, motif or "invalide"),
    )
    con.commit()
    return curseur.lastrowid


def select_trame_id(con, trame_id):
    """Récupère une trame rejetée par son id."""
    ligne = con.execute("SELECT * FROM trames_rejetees WHERE id = ?", (trame_id,)).fetchone()
    return dict(ligne) if ligne else None


def select_dernieres_trames(con, limite=50):
    """Récupère les dernières trames rejetées."""
    lignes = con.execute(
        "SELECT * FROM trames_rejetees ORDER BY t DESC, id DESC LIMIT ?", (limite,)
    ).fetchall()
    return [dict(l) for l in lignes]


def select_trames_motif(con, motif, limite=50):
    """Filtre les trames rejetées par motif."""
    lignes = con.execute(
        "SELECT * FROM trames_rejetees WHERE motif = ? ORDER BY t DESC LIMIT ?", (motif, limite)
    ).fetchall()
    return [dict(l) for l in lignes]


def compter_par_motif(con):
    """Répartition des trames rejetées par motif."""
    lignes = con.execute(
        "SELECT motif, COUNT(*) AS nb FROM trames_rejetees GROUP BY motif ORDER BY nb DESC"
    ).fetchall()
    return [dict(l) for l in lignes]


def compter_rejets(con):
    """Compte le nombre total de trames rejetées."""
    return con.execute("SELECT COUNT(*) FROM trames_rejetees").fetchone()[0]


def purger_avant(con, date_limite):
    """Supprime les trames rejetées antérieures à date_limite."""
    curseur = con.execute("DELETE FROM trames_rejetees WHERE t < ?", (date_limite,))
    con.commit()
    return curseur.rowcount


def purger_trames_rejetees(con):
    """Supprime toutes les trames rejetées."""
    curseur = con.execute("DELETE FROM trames_rejetees")
    con.commit()
    return curseur.rowcount
