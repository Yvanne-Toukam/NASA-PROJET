from datetime import datetime, timezone


def maintenant():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def inserer_action(con, astro, description, alerte_id=None, t=None):
    """alerte_id = None si l'action n'est liée à aucune alerte."""
    curseur = con.execute(
        "INSERT INTO actions (astro, alerte_id, t, description) VALUES (?, ?, ?, ?)",
        (astro, alerte_id, t or maintenant(), description),
    )
    con.commit()
    return curseur.lastrowid


def select_action_id(con, action_id):
    ligne = con.execute("SELECT * FROM actions WHERE id = ?", (action_id,)).fetchone()
    return dict(ligne) if ligne else None


def select_actions_astro(con, astro, limite=50):
    lignes = con.execute(
        "SELECT * FROM actions WHERE astro = ? ORDER BY t DESC LIMIT ?", (astro, limite)
    ).fetchall()
    return [dict(l) for l in lignes]


def select_actions_alerte(con, alerte_id):
    lignes = con.execute(
        "SELECT * FROM actions WHERE alerte_id = ? ORDER BY t", (alerte_id,)
    ).fetchall()
    return [dict(l) for l in lignes]


def update_description(con, action_id, description):
    curseur = con.execute(
        "UPDATE actions SET description = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (description, action_id),
    )
    con.commit()
    return curseur.rowcount == 1


def supprimer_action(con, action_id):
    """Suppression réelle : la table n'a pas de colonne delete_at."""
    curseur = con.execute("DELETE FROM actions WHERE id = ?", (action_id,))
    con.commit()
    return curseur.rowcount == 1