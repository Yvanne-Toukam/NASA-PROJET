import json
from datetime import datetime, timezone


def maintenant():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def inserer_question(con, astro, question, t=None):
    """Enregistre la question ; la réponse est ajoutée ensuite avec update_reponse."""
    curseur = con.execute(
        "INSERT INTO conversations (astro, t, question) VALUES (?, ?, ?)",
        (astro, t or maintenant(), question),
    )
    con.commit()
    return curseur.lastrowid


def update_reponse(con, conversation_id, reponse, sources=None):
    """sources : liste ou dict converti en JSON (documents utilisés par l'assistant)."""
    curseur = con.execute(
        "UPDATE conversations SET reponse = ?, sources_json = ?, updated_at = CURRENT_TIMESTAMP "
        "WHERE id = ?",
        (
            reponse,
            json.dumps(sources, ensure_ascii=False) if sources is not None else None,
            conversation_id,
        ),
    )
    con.commit()
    return curseur.rowcount == 1


def _vers_dict(ligne):
    if ligne is None:
        return None
    d = dict(ligne)
    if d.get("sources_json"):
        d["sources"] = json.loads(d["sources_json"])
    return d


def select_conversation_id(con, conversation_id):
    ligne = con.execute("SELECT * FROM conversations WHERE id = ?", (conversation_id,)).fetchone()
    return _vers_dict(ligne)


def select_conversations_astro(con, astro, limite=20):
    """Les derniers échanges d'un astronaute, du plus récent au plus ancien."""
    lignes = con.execute(
        "SELECT * FROM conversations WHERE astro = ? ORDER BY t DESC, id DESC LIMIT ?",
        (astro, limite),
    ).fetchall()
    return [_vers_dict(l) for l in lignes]


def supprimer_conversation(con, conversation_id):
    """Suppression réelle : la table n'a pas de colonne delete_at."""
    curseur = con.execute("DELETE FROM conversations WHERE id = ?", (conversation_id,))
    con.commit()
    return curseur.rowcount == 1
