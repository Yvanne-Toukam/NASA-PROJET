"""Gestion des examens médicaux et saisies manuelles (poids, densité osseuse, etc.)."""
from datetime import datetime, timezone


def maintenant():
    """Date et heure courante UTC au format strict AAAA-MM-JJ HH:MM:SS."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def inserer_examen(con, astro, type_examen, valeur, unite=None, t=None):
    """Insère un résultat d'examen manuel."""
    curseur = con.execute(
        "INSERT INTO examens (astro, t, type, valeur, unite) VALUES (?, ?, ?, ?, ?)",
        (astro, t or maintenant(), type_examen, float(valeur), unite or ""),
    )
    con.commit()
    return curseur.lastrowid


def select_examen_id(con, examen_id):
    """Récupère un examen par son id."""
    ligne = con.execute("SELECT * FROM examens WHERE id = ?", (examen_id,)).fetchone()
    return dict(ligne) if ligne else None


def select_examens_astro(con, astro, type_examen=None, limite=50):
    """Historique des examens d'un astronaute."""
    if type_examen:
        lignes = con.execute(
            "SELECT * FROM examens WHERE astro = ? AND type = ? ORDER BY t DESC LIMIT ?",
            (astro, type_examen, limite),
        ).fetchall()
    else:
        lignes = con.execute(
            "SELECT * FROM examens WHERE astro = ? ORDER BY t DESC LIMIT ?", (astro, limite)
        ).fetchall()
    return [dict(l) for l in lignes]


def select_dernier_examen(con, astro, type_examen):
    """Récupère le dernier examen d'un certain type."""
    ligne = con.execute(
        "SELECT * FROM examens WHERE astro = ? AND type = ? ORDER BY t DESC, id DESC LIMIT 1",
        (astro, type_examen),
    ).fetchone()
    return dict(ligne) if ligne else None


def update_examen(con, examen_id, valeur, unite=None):
    """Met à jour une saisie d'examen."""
    curseur = con.execute(
        "UPDATE examens SET valeur = ?, unite = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (valeur, unite, examen_id),
    )
    con.commit()
    return curseur.rowcount == 1


def supprimer_examen(con, examen_id):
    """Supprime un examen."""
    curseur = con.execute("DELETE FROM examens WHERE id = ?", (examen_id,))
    con.commit()
    return curseur.rowcount == 1


def purger_examens(con):
    """Supprime tous les examens."""
    curseur = con.execute("DELETE FROM examens")
    con.commit()
    return curseur.rowcount
