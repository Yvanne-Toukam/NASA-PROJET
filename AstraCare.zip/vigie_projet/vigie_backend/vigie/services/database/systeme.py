"""Table système : compteurs globaux, état de dégradation et âges des sources."""


def set_valeur(con, cle, valeur):
    """Enregistre ou met à jour une clé d'état système."""
    con.execute(
        "INSERT INTO systeme (cle, valeur) VALUES (?, ?) "
        "ON CONFLICT (cle) DO UPDATE SET valeur = excluded.valeur, updated_at = CURRENT_TIMESTAMP",
        (cle, None if valeur is None else str(valeur)),
    )
    con.commit()
    return cle


def get_valeur(con, cle, defaut=None):
    """Lit une clé d'état système."""
    ligne = con.execute("SELECT valeur FROM systeme WHERE cle = ?", (cle,)).fetchone()
    return ligne[0] if (ligne and ligne[0] is not None) else defaut


def select_systeme(con, cle):
    """Récupère l'enregistrement complet d'une clé."""
    ligne = con.execute("SELECT * FROM systeme WHERE cle = ?", (cle,)).fetchone()
    return dict(ligne) if ligne else None


def select_tout(con):
    """Retourne l'ensemble de l'état système sous la forme d'un dictionnaire {clé: valeur}."""
    lignes = con.execute("SELECT cle, valeur FROM systeme").fetchall()
    return {l["cle"]: l["valeur"] for l in lignes}


def incrementer(con, cle, pas=1):
    """Incrémente un compteur système de façon atomique."""
    actuelle = get_valeur(con, cle, "0")
    try:
        valeur_int = int(actuelle)
    except (ValueError, TypeError):
        valeur_int = 0
    nouvelle = valeur_int + pas
    set_valeur(con, cle, nouvelle)
    return nouvelle


def supprimer_cle(con, cle):
    """Supprime une clé système."""
    curseur = con.execute("DELETE FROM systeme WHERE cle = ?", (cle,))
    con.commit()
    return curseur.rowcount == 1


def purger_systeme(con):
    """Vide la table système."""
    curseur = con.execute("DELETE FROM systeme")
    con.commit()
    return curseur.rowcount
