"""Fonctions de la table astronautes (gestion du profil et suppression logique)."""
from datetime import date


def generer_id(con):
    """Prochain identifiant de l'année : AST2026-001, AST2026-002..."""
    pref = f"AST{date.today().year}-"
    n = con.execute(
        "SELECT COUNT(*) FROM astronautes WHERE id LIKE ?", (pref + "%",)
    ).fetchone()[0]
    return f"{pref}{n + 1:03d}"


def inserer_astronaute(con, first_name, last_name, role, email=None, astro_id=None):
    """Insère un membre d'équipage. Si astro_id est fourni, l'utilise sinon génère AST2026-xxx."""
    if astro_id is None:
        astro_id = generer_id(con)
    con.execute(
        "INSERT INTO astronautes (id, first_name, last_name, role, email_address) "
        "VALUES (?, ?, ?, ?, ?)",
        (astro_id, first_name, last_name, role, email),
    )
    con.commit()
    return astro_id


def select_astronaute_id(con, astro_id):
    """Récupère un astronaute par son identifiant unique, s'il n'est pas supprimé logiquement."""
    ligne = con.execute(
        "SELECT * FROM astronautes WHERE id = ? AND delete_at IS NULL", (astro_id,)
    ).fetchone()
    return dict(ligne) if ligne else None


def select_tous_astronautes(con):
    """Liste tous les membres d'équipage actifs (non supprimés logiquement)."""
    lignes = con.execute(
        "SELECT * FROM astronautes WHERE delete_at IS NULL ORDER BY id"
    ).fetchall()
    return [dict(l) for l in lignes]


def select_astronaute_nom(con, first_name, last_name):
    """Recherche un astronaute par son prénom et nom."""
    lignes = con.execute(
        "SELECT * FROM astronautes WHERE first_name = ? AND last_name = ? AND delete_at IS NULL",
        (first_name, last_name),
    ).fetchall()
    return [dict(l) for l in lignes]


def update_statut(con, astro_id, statut):
    """statut : 1 = actif, 0 = inactif. Renvoie True si l'astronaute existait."""
    curseur = con.execute(
        "UPDATE astronautes SET statut = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND delete_at IS NULL",
        (statut, astro_id),
    )
    con.commit()
    return curseur.rowcount == 1


def supprimer_astronaute(con, astro_id):
    """Suppression logique (affectation de delete_at au lieu de DELETE physique)."""
    curseur = con.execute(
        "UPDATE astronautes SET delete_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP "
        "WHERE id = ? AND delete_at IS NULL",
        (astro_id,),
    )
    con.commit()
    return curseur.rowcount == 1


def restaurer_astronaute(con, astro_id):
    """Restaure un astronaute supprimé logiquement."""
    curseur = con.execute(
        "UPDATE astronautes SET delete_at = NULL, updated_at = CURRENT_TIMESTAMP "
        "WHERE id = ? AND delete_at IS NOT NULL",
        (astro_id,),
    )
    con.commit()
    return curseur.rowcount == 1
