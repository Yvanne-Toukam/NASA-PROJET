"""Connexion à la base SQLite de Vigie avec row_factory, WAL et Foreign Keys."""
import sqlite3
from pathlib import Path

SCHEMA = Path(__file__).parent / "database.sql"
BASE_PAR_DEFAUT = Path(__file__).resolve().parents[2] / "data" / "vigie.db"


def connecter(chemin=None):
    """Ouvre une connexion SQLite sécurisée pour Vigie.
    
    Active les clés étrangères (PRAGMA foreign_keys = ON), le mode WAL
    (PRAGMA journal_mode = WAL) et le row_factory pour accéder aux colonnes par leur nom.
    Exécute le schéma database.sql à la création.
    """
    if chemin is None:
        chemin = BASE_PAR_DEFAUT
    elif chemin != ":memory:":
        chemin = Path(chemin)
    
    if chemin != ":memory:":
        chemin.parent.mkdir(parents=True, exist_ok=True)
        
    con = sqlite3.connect(chemin, timeout=10.0)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA journal_mode = WAL")
    
    # Exécution du schéma si les tables n'existent pas encore
    con.executescript(SCHEMA.read_text(encoding="utf-8"))
    return con
