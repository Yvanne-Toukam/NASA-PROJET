"""Utilitaires pour la base de données SQLite de Vigie."""
from . import (
    actions,
    alertes,
    appareils,
    astronaute,
    bilans,
    conversations,
    examens,
    mesures,
    references_perso,
    systeme,
    trames_rejetees,
)


def vider_toutes_tables(con):
    """Purge l'ensemble des tables métier pour repartir d'un état propre."""
    mesures.purger_mesures(con)
    alertes.purger_alertes(con)
    references_perso.purger_references(con)
    bilans.purger_bilans(con)
    examens.purger_examens(con)
    actions.purger_actions(con) if hasattr(actions, "purger_actions") else None
    trames_rejetees.purger_trames_rejetees(con)
    systeme.purger_systeme(con)
    con.commit()
