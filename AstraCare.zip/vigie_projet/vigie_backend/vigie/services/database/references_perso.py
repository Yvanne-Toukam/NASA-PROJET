"""Gestion des références individuelles (ligne de base personnelle de chaque astronaute)."""


def inserer_reference(con, astro, mesure, moyenne, ecart_type, n, periode_debut, periode_fin):
    """Crée ou remplace la référence d'une personne pour une mesure donnée."""
    con.execute(
        "INSERT INTO references_perso (astro, mesure, moyenne, ecart_type, n, periode_debut, periode_fin) "
        "VALUES (?, ?, ?, ?, ?, ?, ?) "
        "ON CONFLICT (astro, mesure) DO UPDATE SET "
        "moyenne = excluded.moyenne, ecart_type = excluded.ecart_type, n = excluded.n, "
        "periode_debut = excluded.periode_debut, periode_fin = excluded.periode_fin, "
        "updated_at = CURRENT_TIMESTAMP",
        (astro, mesure, float(moyenne), float(ecart_type), int(n), str(periode_debut), str(periode_fin)),
    )
    con.commit()
    return (astro, mesure)


def select_reference(con, astro, mesure):
    """Récupère la référence personnelle d'un astronaute pour un paramètre."""
    ligne = con.execute(
        "SELECT * FROM references_perso WHERE astro = ? AND mesure = ?", (astro, mesure)
    ).fetchone()
    return dict(ligne) if ligne else None


def select_references_astro(con, astro):
    """Liste l'ensemble des références disponibles pour un astronaute."""
    lignes = con.execute(
        "SELECT * FROM references_perso WHERE astro = ? ORDER BY mesure", (astro,)
    ).fetchall()
    return [dict(l) for l in lignes]


def supprimer_reference(con, astro, mesure):
    """Supprime une référence spécifique."""
    curseur = con.execute(
        "DELETE FROM references_perso WHERE astro = ? AND mesure = ?", (astro, mesure)
    )
    con.commit()
    return curseur.rowcount == 1


def purger_references(con):
    """Supprime toutes les références."""
    curseur = con.execute("DELETE FROM references_perso")
    con.commit()
    return curseur.rowcount
