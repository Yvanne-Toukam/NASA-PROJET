"""Gestion du journal des alertes médicales et techniques."""
import json
from datetime import datetime, timezone


def maintenant():
    """Horodatage courant en UTC."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def inserer_alerte(con, astro, module, niveau, regle, texte_court=None, detail=None, t=None):
    """Insère une alerte de niveau 1 (vigilance) ou 2 (critique). detail est sérialisé en JSON."""
    curseur = con.execute(
        "INSERT INTO alertes (astro, t, module, niveau, regle, texte_court, detail_json) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            astro,
            t or maintenant(),
            module,
            niveau,
            regle,
            texte_court,
            json.dumps(detail, ensure_ascii=False) if detail is not None else None,
        ),
    )
    con.commit()
    return curseur.lastrowid


def _vers_dict(ligne):
    """Convertit un row SQLite en dictionnaire avec désérialisation du détail JSON."""
    if ligne is None:
        return None
    d = dict(ligne)
    if d.get("detail_json"):
        try:
            d["detail"] = json.loads(d["detail_json"])
        except Exception:
            d["detail"] = d["detail_json"]
    else:
        d["detail"] = {}
    return d


def select_alerte_id(con, alerte_id):
    """Sélectionne une alerte par son identifiant numérique."""
    ligne = con.execute("SELECT * FROM alertes WHERE id = ?", (alerte_id,)).fetchone()
    return _vers_dict(ligne)


def select_alertes_actives(con, astro=None):
    """Alertes non acquittées, triées par niveau décroissant puis par date décroissante."""
    requete = "SELECT * FROM alertes WHERE acquittee = 0"
    params = ()
    if astro:
        requete += " AND astro = ?"
        params = (astro,)
    requete += " ORDER BY niveau DESC, t DESC"
    return [_vers_dict(l) for l in con.execute(requete, params).fetchall()]


def select_alertes_astro(con, astro, limite=50):
    """Historique complet des alertes d'un membre d'équipage."""
    lignes = con.execute(
        "SELECT * FROM alertes WHERE astro = ? ORDER BY t DESC LIMIT ?", (astro, limite)
    ).fetchall()
    return [_vers_dict(l) for l in lignes]


def select_alertes_mesure(con, astro, mesure, depuis=None):
    """Récupère les alertes associées à une mesure pour l'affichage des repères temporels sur le graphique.
    
    Filtre par motif dans la règle ou le détail JSON, et par date postérieure à `depuis` si fourni.
    """
    motif = f"%{mesure.upper()}%"
    if depuis:
        lignes = con.execute(
            "SELECT t, regle, niveau FROM alertes "
            "WHERE astro = ? AND (regle LIKE ? OR detail_json LIKE ?) AND t > ? "
            "ORDER BY t ASC",
            (astro, motif, f'%"{mesure}"%', depuis),
        ).fetchall()
    else:
        lignes = con.execute(
            "SELECT t, regle, niveau FROM alertes "
            "WHERE astro = ? AND (regle LIKE ? OR detail_json LIKE ?) "
            "ORDER BY t ASC",
            (astro, motif, f'%"{mesure}"%'),
        ).fetchall()
    return [{"t": l["t"], "regle": l["regle"], "niveau": l["niveau"]} for l in lignes]


def alerte_recente_existe(con, astro, regle, depuis):
    """Vérifie si une alerte portant sur la même règle a déjà été déclenchée depuis cet instant."""
    ligne = con.execute(
        "SELECT 1 FROM alertes WHERE astro = ? AND regle = ? AND t >= ? LIMIT 1",
        (astro, regle, depuis),
    ).fetchone()
    return ligne is not None


def alerte_active_existe(con, astro, regle):
    """Vérifie si une alerte identique est déjà active et non acquittée (anti-doublon d'alerte)."""
    ligne = con.execute(
        "SELECT 1 FROM alertes WHERE astro = ? AND regle = ? AND acquittee = 0 LIMIT 1",
        (astro, regle),
    ).fetchone()
    return ligne is not None


def acquitter_alerte(con, alerte_id):
    """Acquitte une alerte active. Renvoie True si l'alerte a été acquittée avec succès."""
    curseur = con.execute(
        "UPDATE alertes SET acquittee = 1, t_acquittement = ?, updated_at = CURRENT_TIMESTAMP "
        "WHERE id = ? AND acquittee = 0",
        (maintenant(), alerte_id),
    )
    con.commit()
    return curseur.rowcount == 1


def purger_alertes(con):
    """Supprime toutes les alertes (pour réinitialiser un scénario)."""
    curseur = con.execute("DELETE FROM alertes")
    con.commit()
    return curseur.rowcount
