"""Application des scenarios (derive, urgence, panne) aux valeurs"""
