"""Simulateur de capteurs Vigie : produit les trames au format du contrat sans Proteus.

Génère et diffuse les 4 scénarios de démonstration (CDC section 12.3) :
- nominal : équipage en bonne santé, aucune fausse alerte.
- derive_lente : dérive précoce du pouls et du sommeil, détectée par CUSUM avant le seuil N1.
- urgence : détresse cardiorespiratoire aiguë (niveau critique 2).
- panne_capteur : perte de signal (qualite=capteur_hs), source muette et confiance dégradée (P6).

Prend en charge la simulation en direct accélérée en arrière-plan avec pré-remplissage de la
période de référence et émission progressive au fil du temps simulé.
"""
import math
import random
import threading
import time
from datetime import datetime, timedelta, timezone

from vigie.core.config import charger_app
from vigie.core.constantes import CATALOGUE, FORMAT_DATE_UTC
from vigie.core.journal import journal
from vigie.services.database import (
    actions,
    alertes as db_alertes,
    astronaute as db_astronaute,
    bilans,
    connectdb,
    examens,
    mesures,
    references_perso,
    systeme,
)
from vigie.services.ingestion.contrat import valider_trame
from vigie.services.ingestion.lecteur_serie import traiter_ligne
from vigie.services.analyse import moteur as moteur_analyse
from vigie.services.analyse.references import calculer_references

# Les 4 astronautes principaux de la mission
ASTROS = {
    "AST2026-001": ("Orion", "Commandant"),
    "AST2026-002": ("Lyra", "Ingénieure de vol"),
    "AST2026-003": ("Vega", "Médecin de bord"),
    "AST2026-004": ("Altaïr", "Spécialiste mission"),
}

ASTRONAUTES = list(ASTROS.keys())
ZONES = ["cabine1", "cabine2"]

# Alias pour compatibilité
ALIAS_ASTROS = {
    "astro1": "AST2026-001",
    "astro2": "AST2026-002",
    "astro3": "AST2026-003",
    "astro4": "AST2026-004",
}

SCENARIOS = ["nominal", "derive_lente", "urgence", "panne_capteur"]

PAS_MINUTES = 5
PAS_PAR_JOUR = 24 * 60 // PAS_MINUTES

# Profils types (valeur moyenne de base, bruit gaussien, heures d'émission journalières)
PROFILS = {
    "pouls":       (62.0, 1.5, (0, 3, 6, 9, 12, 15, 18, 21)),
    "hrv":         (55.0, 4.0, (0, 3, 6, 9, 12, 15, 18, 21)),
    "spo2":        (97.5, 0.4, (0, 3, 6, 9, 12, 15, 18, 21)),
    "resp":        (14.0, 0.8, (0, 3, 6, 9, 12, 15, 18, 21)),
    "temp_peau":   (36.5, 0.15, (0, 3, 6, 9, 12, 15, 18, 21)),
    "sommeil":     (7.2, 0.35, (7,)),
    "activite":    (125.0, 10.0, (21,)),
}


def _valeur_simulee(rng, mesure, indice_astro, jour, astro_id, scenario, jours_base, nb_jours):
    """Calcule la valeur numérique simulée selon le scénario et l'astronaute."""
    base, bruit, _ = PROFILS[mesure]

    # Personnalisation de la normale de chaque astronaute
    if mesure in ("pouls", "hrv", "sommeil", "activite"):
        base *= 1.0 + 0.04 * (indice_astro - 1.5)

    val = base + rng.gauss(0, bruit)

    # Scénario Dérive lente : s'applique à AST2026-001 après la période de base
    cible_derive = (astro_id in ("AST2026-001", "astro1"))
    if cible_derive and scenario == "derive_lente" and jour >= jours_base:
        d = jour - jours_base + 1
        increment = {
            "pouls": 0.55 * d,
            "sommeil": -0.12 * d,
            "temp_peau": 0.05 * d,
            "hrv": -1.0 * d,
            "activite": -4.0 * d,
        }.get(mesure, 0.0)
        val += increment

    # Scénario Urgence : détérioration critique sur le dernier jour
    if cible_derive and scenario == "urgence" and jour >= (nb_jours - 1):
        if mesure == "pouls":
            val = 128.0 + rng.gauss(0, 0.5)
        elif mesure == "spo2":
            val = 89.5 + rng.gauss(0, 0.3)
        elif mesure == "resp":
            val = 27.0 + rng.gauss(0, 0.5)

    # Bornage strict dans les limites acceptables du catalogue
    vmin = CATALOGUE[mesure][2]
    vmax = CATALOGUE[mesure][3]
    return round(min(max(val, vmin), vmax), 1)


def reinitialiser(con):
    """Purge l'ensemble des tables dans l'ordre strict des contraintes d'intégrité (clés étrangères).
    
    Exécute les suppressions (enfants puis parents) et recrée les astronautes standard
    dans une transaction SQLite atomique (P3/P6).
    """
    with con:
        tables_a_purger = [
            "actions",
            "conversations",
            "alertes",
            "bilans",
            "examens",
            "references_perso",
            "appareils",
            "mesures",
            "trames_rejetees",
            "systeme",
            "astronautes",
        ]
        for table in tables_a_purger:
            con.execute(f"DELETE FROM {table}")

        # Recréation immédiate des astronautes pour garantir la cohérence des clés étrangères
        for a_id, (prenom, role) in ASTROS.items():
            con.execute(
                "INSERT INTO astronautes (id, first_name, last_name, role, email_address) "
                "VALUES (?, ?, ?, ?, ?)",
                (a_id, prenom, "-", role, f"{prenom.lower()}@vigie.local"),
            )


class Simulateur:
    """Simulateur pas-à-pas pour la simulation en direct ou les tests unitaires."""

    def __init__(self, graine=42, debut=None):
        self.rng = random.Random(graine)
        self.t = debut or datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
        self.seq = {}
        self.scenario_actif = "nominal"
        self.cible_active = ASTRONAUTES[0]
        self.pas_compteur = 0

    def activer(self, scenario, cible=None):
        alias = {
            "S1": "nominal",
            "S2": "derive_lente",
            "S3": "derive_lente",
            "S4": "urgence",
            "S5": "cabine",
            "S6": "panne_capteur",
        }
        nom_resolu = alias.get(scenario, scenario)
        if nom_resolu not in SCENARIOS and scenario not in ("S3", "S4", "S5", "S6"):
            raise ValueError(f"Scénario inconnu : {scenario}")
        self.scenario_actif = scenario
        self.cible_active = cible or ASTRONAUTES[0]
        self.pas_compteur = 0

    def retablir(self):
        self.scenario_actif = "nominal"
        self.pas_compteur = 0

    def _ligne(self, source, astro, mesure, valeur, qualite):
        _, unite, vmin, vmax, _ = CATALOGUE[mesure]
        val = min(max(valeur, vmin), vmax)
        cle = (source, astro)
        seq_num = self.seq.get(cle, 0)
        self.seq[cle] = seq_num + 1
        return f"{source},{astro},{mesure},{val:.1f},{unite},{qualite},{seq_num}"

    def pas(self):
        """Avance de 5 minutes de mission et renvoie (horodatage, liste_de_lignes_trames)."""
        t_str = self.t.strftime(FORMAT_DATE_UTC)
        lignes = []

        for i, astro_id in enumerate(ASTRONAUTES):
            for m in ("pouls", "hrv", "spo2", "resp", "temp_peau"):
                val = _valeur_simulee(self.rng, m, i, 20, astro_id, self.scenario_actif, 14, 28)
                q = "ok"
                # Scénario panne de capteur (officiel ou S6)
                if (self.scenario_actif in ("panne_capteur", "S6")) and astro_id == self.cible_active and m == "pouls":
                    val = 0.0
                    q = "capteur_hs"
                # Scénario anomalie cardiaque (S3)
                elif self.scenario_actif == "S3" and astro_id == self.cible_active and m == "pouls":
                    val = 95.0 + self.rng.gauss(0, 1.0)
                # Scénario baisse de SpO2 (S4)
                elif self.scenario_actif == "S4" and astro_id == self.cible_active and m == "spo2":
                    val = 78.0 + self.rng.gauss(0, 0.5)

                lignes.append(self._ligne("watch", astro_id, m, val, q))

            lignes.append(self._ligne("sante", astro_id, "tension_sys", 115.0 + self.rng.gauss(0, 2), "ok"))
            lignes.append(self._ligne("sante", astro_id, "tension_dia", 75.0 + self.rng.gauss(0, 2), "ok"))
            lignes.append(self._ligne("dosi", astro_id, "debit_dose", 7.0 + self.rng.gauss(0, 0.3), "ok"))

        for zone in ZONES:
            co2_val = 750.0 + self.rng.gauss(0, 15)
            if self.scenario_actif == "S5" and (zone in ("poste_pilotage", ZONES[0])):
                co2_val = 4500.0 + self.rng.gauss(0, 50)
            elif self.scenario_actif == "S5":
                co2_val = 800.0 + self.rng.gauss(0, 20)

            lignes.append(self._ligne("cab", zone, "co2", co2_val, "ok"))
            lignes.append(self._ligne("cab", zone, "o2", 20.9 + self.rng.gauss(0, 0.05), "ok"))
            lignes.append(self._ligne("cab", zone, "temp_cabine", 22.0 + self.rng.gauss(0, 0.1), "ok"))
            lignes.append(self._ligne("cab", zone, "humidite", 45.0 + self.rng.gauss(0, 1.0), "ok"))

        self.t += timedelta(minutes=PAS_MINUTES)
        self.pas_compteur += 1
        return t_str, lignes

    def reprendre(self, con):
        for row in con.execute("SELECT source, astro, MAX(seq) FROM mesures GROUP BY source, astro").fetchall():
            self.seq[(row[0], row[1])] = row[2] + 1


def remplir_base(con, sim, nb_pas):
    """Remplit la base en injectant nb_pas pas de simulation."""
    total = 0
    for _ in range(nb_pas):
        t, lignes = sim.pas()
        for l in lignes:
            traiter_ligne(con, l, t=t)
            total += 1
    return total


def injecter_pas(con, sim):
    """Injecte un pas de simulation dans la connexion SQLite."""
    t, lignes = sim.pas()
    return [traiter_ligne(con, l, t=t) for l in lignes]


def generer(con, scenario="nominal", jours=28, jours_base=14, debut=None, graine=42):
    """Génère plusieurs jours de mesures simulées et les insère dans SQLite.
    
    Conservé pour la compatibilité avec les tests existants.
    """
    alias = {
        "S1": "nominal",
        "S2": "derive_lente",
        "S3": "derive_lente",
        "S4": "urgence",
        "S5": "derive_lente",
        "S6": "panne_capteur",
    }
    sc_resolu = alias.get(scenario, scenario)
    if sc_resolu not in SCENARIOS:
        raise ValueError(f"Scénario inconnu : {scenario}. Scénarios autorisés : {', '.join(SCENARIOS)}")

    rng = random.Random(graine)
    if debut is None:
        maintenant_dt = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        debut = maintenant_dt - timedelta(days=jours - 1)

    for a_id, (prenom, role) in ASTROS.items():
        if not db_astronaute.select_astronaute_id(con, a_id):
            con.execute(
                "INSERT OR IGNORE INTO astronautes (id, first_name, last_name, role, email_address) "
                "VALUES (?, ?, ?, ?, ?)",
                (a_id, prenom, "-", role, f"{prenom.lower()}@vigie.local"),
            )

    seq_counters = {a: 0 for a in ASTROS}
    lignes_a_inserer = []

    for jour in range(jours):
        date_du_jour = debut + timedelta(days=jour)
        for i_ast, (a_id, _) in enumerate(ASTROS.items()):
            for mesure, (_, _, heures) in PROFILS.items():
                for h in heures:
                    valeur = _valeur_simulee(rng, mesure, i_ast, jour, a_id, sc_resolu, jours_base, jours)
                    qualite = "ok"

                    est_cible = (a_id in ("AST2026-001", "astro1"))
                    if sc_resolu == "panne_capteur" and est_cible and mesure == "pouls" and jour >= (jours - 2):
                        valeur = 0.0
                        qualite = "capteur_hs"

                    source = CATALOGUE[mesure][0]
                    unite = CATALOGUE[mesure][1]
                    num_seq = seq_counters[a_id]
                    seq_counters[a_id] += 1

                    ligne_trame = f"{source},{a_id},{mesure},{valeur},{unite},{qualite},{num_seq}"
                    trame, motif = valider_trame(ligne_trame)
                    if trame is None:
                        raise ValueError(f"Trame invalide générée par le simulateur ({motif}) : {ligne_trame}")

                    t_recu = (date_du_jour + timedelta(hours=h)).strftime(FORMAT_DATE_UTC)
                    lignes_a_inserer.append((
                        trame["astro"],
                        trame["source"],
                        trame["mesure"],
                        trame["valeur"],
                        trame["unite"],
                        trame["qualite"],
                        trame["seq"],
                        t_recu,
                    ))

        # Mesures de cabine
        for z in ZONES:
            for m_cab in ("co2", "o2", "temp_cabine", "humidite"):
                v_cab = {"co2": 780.0, "o2": 20.9, "temp_cabine": 22.0, "humidite": 45.0}[m_cab]
                src = CATALOGUE[m_cab][0]
                un = CATALOGUE[m_cab][1]
                t_cab = (date_du_jour + timedelta(hours=12)).strftime(FORMAT_DATE_UTC)
                lignes_a_inserer.append((z, src, m_cab, v_cab, un, "ok", jour, t_cab))

    with con:
        con.executemany(
            "INSERT OR IGNORE INTO mesures (astro, source, mesure, valeur, unite, qualite, seq, create_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            lignes_a_inserer,
        )
    return len(lignes_a_inserer)


# =====================================================================
# Producteur en arrière-plan pour la simulation en direct accélérée
# =====================================================================

class GestionnaireSimulation:
    """Orchestre la simulation continue en direct avec horloge accélérée.
    
    Gère le pré-remplissage initial des 14 jours de base et diffuse progressivement
    le reste de la mission via un thread d'arrière-plan sans bloquer les requêtes API.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._thread = None
        self._stop_event = threading.Event()
        self._pause_event = threading.Event()
        self._pause_event.set()

        self.scenario = "nominal"
        self.vitesse = 21600.0  # 6h simulées par seconde réelle par défaut
        self.en_cours = False
        self.en_pause = False
        self.debut_mission = None
        self.fin_mission = None
        self.horloge_simulee = None
        self.jours_base = 14
        self.jours_total = 28
        self.pas_secondes_sim = 10800  # 3 heures simulées par pas (8 points/jour)
        self.graine = 42
        self.rng = random.Random(42)
        self.seq_compteurs = {}
        self.cible_active = "AST2026-001"

    def _obtenir_seq(self, source, identifiant):
        cle = (source, identifiant)
        val = self.seq_compteurs.get(cle, 0)
        self.seq_compteurs[cle] = val + 1
        return val

    def demarrer(self, scenario="nominal", vitesse=None, jours_base=14, jours_total=28, debut=None):
        """Initialise la base et lance la diffusion progressive du scénario."""
        with self._lock:
            # Arrêt propre d'une simulation précédente en cours
            self._stop_event.set()
            if self._thread and self._thread.is_alive():
                self._thread.join(timeout=1.0)

            # Lecture de la configuration si disponible
            cfg_app = charger_app() or {}
            cfg_sim = cfg_app.get("simulation", {})
            vitesse_resolue = float(vitesse or cfg_sim.get("vitesse_defaut", 21600.0))
            self.pas_secondes_sim = int(cfg_sim.get("pas_secondes_simulees", 10800))
            self.jours_base = int(cfg_sim.get("jours_base", jours_base))
            self.jours_total = int(cfg_sim.get("jours_total", jours_total))

            self.scenario = scenario
            self.vitesse = vitesse_resolue
            self.graine = 42
            self.rng = random.Random(self.graine)
            self.seq_compteurs = {}
            self.cible_active = "AST2026-001"

            # Date de début de mission simulée
            if debut is None:
                self.debut_mission = datetime(2026, 11, 1, 0, 0, 0, tzinfo=timezone.utc)
            else:
                self.debut_mission = debut

            self.fin_mission = self.debut_mission + timedelta(days=self.jours_total)

            # 1. Réinitialisation complète et atomique de la base SQLite
            con = connectdb.connecter()
            try:
                reinitialiser(con)

                # 2. Pré-remplissage instantané des 14 premiers jours de base (profil nominal)
                self._pre_remplir_base(con)

                # 3. Calcul immédiat des références individuelles pour chaque astronaute
                for a_id in ASTROS:
                    calculer_references(con, a_id)

                # L'horloge simulée se positionne au début du 15ème jour (après la période de base)
                self.horloge_simulee = self.debut_mission + timedelta(days=self.jours_base)
                
                # Analyse initiale au début de la phase de streaming
                for a_id in ASTROS:
                    etat = moteur_analyse.analyser(con, a_id, jusqua=self.horloge_simulee.strftime(FORMAT_DATE_UTC))
                    moteur_analyse.enregistrer_alertes(con, etat)

            finally:
                con.close()

            # 4. Démarrage du thread producteur
            self._stop_event.clear()
            self._pause_event.set()
            self.en_cours = True
            self.en_pause = False

            self._thread = threading.Thread(target=self._boucle_production, daemon=True)
            self._thread.start()

            journal.info(
                "Simulation '%s' démarrée : 14 jours de base injectés, streaming actif à %.1f h/s.",
                self.scenario,
                self.vitesse / 3600.0,
            )
            return self.etat()

    def _pre_remplir_base(self, con):
        """Injecte les mesures des 14 premiers jours nominaux pour calibrer la référence."""
        for jour in range(self.jours_base):
            date_jour = self.debut_mission + timedelta(days=jour)
            # 8 relevés par jour pour les signes vitaux
            for h in (0, 3, 6, 9, 12, 15, 18, 21):
                t_point = date_jour + timedelta(hours=h)
                t_str = t_point.strftime(FORMAT_DATE_UTC)

                for idx, a_id in enumerate(ASTROS):
                    for m in ("pouls", "hrv", "spo2", "resp", "temp_peau"):
                        val = _valeur_simulee(self.rng, m, idx, jour, a_id, "nominal", self.jours_base, self.jours_total)
                        num_seq = self._obtenir_seq("watch", a_id)
                        ligne = f"watch,{a_id},{m},{val:.1f},{CATALOGUE[m][1]},ok,{num_seq}"
                        traiter_ligne(con, ligne, t=t_str)

                    if h in (8, 20):
                        s1 = self._obtenir_seq("sante", a_id)
                        s2 = self._obtenir_seq("sante", a_id)
                        sd = self._obtenir_seq("dosi", a_id)
                        traiter_ligne(con, f"sante,{a_id},tension_sys,116.0,mmHg,ok,{s1}", t=t_str)
                        traiter_ligne(con, f"sante,{a_id},tension_dia,76.0,mmHg,ok,{s2}", t=t_str)
                        traiter_ligne(con, f"dosi,{a_id},debit_dose,7.0,uSvh,ok,{sd}", t=t_str)

                    if h == 7:
                        val_s = _valeur_simulee(self.rng, "sommeil", idx, jour, a_id, "nominal", self.jours_base, self.jours_total)
                        ss = self._obtenir_seq("watch", a_id)
                        traiter_ligne(con, f"watch,{a_id},sommeil,{val_s:.1f},h,ok,{ss}", t=t_str)

                    if h == 21:
                        val_a = _valeur_simulee(self.rng, "activite", idx, jour, a_id, "nominal", self.jours_base, self.jours_total)
                        sa = self._obtenir_seq("watch", a_id)
                        traiter_ligne(con, f"watch,{a_id},activite,{val_a:.1f},min,ok,{sa}", t=t_str)

                # Surveillance cabine
                if h in (6, 12, 18):
                    for z in ZONES:
                        sc1 = self._obtenir_seq("cab", z)
                        sc2 = self._obtenir_seq("cab", z)
                        sc3 = self._obtenir_seq("cab", z)
                        sc4 = self._obtenir_seq("cab", z)
                        traiter_ligne(con, f"cab,{z},co2,760.0,ppm,ok,{sc1}", t=t_str)
                        traiter_ligne(con, f"cab,{z},o2,20.9,pct,ok,{sc2}", t=t_str)
                        traiter_ligne(con, f"cab,{z},temp_cabine,22.1,degC,ok,{sc3}", t=t_str)
                        traiter_ligne(con, f"cab,{z},humidite,45.0,pct,ok,{sc4}", t=t_str)

    def avancer(self, n_pas=1):
        """Avance la simulation de n pas de manière synchrone et déterministe (sans sleep)."""
        with self._lock:
            if not self.horloge_simulee:
                self.demarrer(scenario=self.scenario)

            con = connectdb.connecter()
            try:
                for _ in range(n_pas):
                    if self.horloge_simulee >= self.fin_mission:
                        self.en_cours = False
                        break

                    self.horloge_simulee += timedelta(seconds=self.pas_secondes_sim)
                    t_str = self.horloge_simulee.strftime(FORMAT_DATE_UTC)
                    jour_courant = (self.horloge_simulee - self.debut_mission).days
                    heure_courante = self.horloge_simulee.hour

                    for idx, a_id in enumerate(ASTROS):
                        for m in ("pouls", "hrv", "spo2", "resp", "temp_peau"):
                            val = _valeur_simulee(
                                self.rng, m, idx, jour_courant, a_id,
                                self.scenario, self.jours_base, self.jours_total
                            )
                            qualite = "ok"

                            # Cas de la panne capteur (derniers 2 jours sur AST2026-001)
                            est_cible = (a_id == self.cible_active)
                            if self.scenario == "panne_capteur" and est_cible and m == "pouls" and jour_courant >= (self.jours_total - 2):
                                val = 0.0
                                qualite = "capteur_hs"

                            num_seq = self._obtenir_seq("watch", a_id)
                            ligne = f"watch,{a_id},{m},{val:.1f},{CATALOGUE[m][1]},{qualite},{num_seq}"
                            traiter_ligne(con, ligne, t=t_str)

                        if heure_courante in (8, 20):
                            s1 = self._obtenir_seq("sante", a_id)
                            s2 = self._obtenir_seq("sante", a_id)
                            sd = self._obtenir_seq("dosi", a_id)
                            traiter_ligne(con, f"sante,{a_id},tension_sys,116.0,mmHg,ok,{s1}", t=t_str)
                            traiter_ligne(con, f"sante,{a_id},tension_dia,76.0,mmHg,ok,{s2}", t=t_str)
                            traiter_ligne(con, f"dosi,{a_id},debit_dose,7.0,uSvh,ok,{sd}", t=t_str)

                        if heure_courante == 7:
                            val_s = _valeur_simulee(
                                self.rng, "sommeil", idx, jour_courant, a_id,
                                self.scenario, self.jours_base, self.jours_total
                            )
                            ss = self._obtenir_seq("watch", a_id)
                            traiter_ligne(con, f"watch,{a_id},sommeil,{val_s:.1f},h,ok,{ss}", t=t_str)

                        if heure_courante == 21:
                            val_a = _valeur_simulee(
                                self.rng, "activite", idx, jour_courant, a_id,
                                self.scenario, self.jours_base, self.jours_total
                            )
                            sa = self._obtenir_seq("watch", a_id)
                            traiter_ligne(con, f"watch,{a_id},activite,{val_a:.1f},min,ok,{sa}", t=t_str)

                    # Mesures cabine
                    for z in ZONES:
                        co2_val = 770.0 + self.rng.gauss(0, 15)
                        sc1 = self._obtenir_seq("cab", z)
                        sc2 = self._obtenir_seq("cab", z)
                        sc3 = self._obtenir_seq("cab", z)
                        sc4 = self._obtenir_seq("cab", z)
                        traiter_ligne(con, f"cab,{z},co2,{co2_val:.1f},ppm,ok,{sc1}", t=t_str)
                        traiter_ligne(con, f"cab,{z},o2,20.9,pct,ok,{sc2}", t=t_str)
                        traiter_ligne(con, f"cab,{z},temp_cabine,22.0,degC,ok,{sc3}", t=t_str)
                        traiter_ligne(con, f"cab,{z},humidite,45.0,pct,ok,{sc4}", t=t_str)

                    # Analyse et journalisation des alertes à ce pas simulé
                    for a_id in ASTROS:
                        etat = moteur_analyse.analyser(con, a_id, jusqua=t_str)
                        moteur_analyse.enregistrer_alertes(con, etat)

            finally:
                con.close()

            return self.etat()

    def _boucle_production(self):
        """Boucle du thread d'arrière-plan cadençant l'émission en temps réel."""
        while not self._stop_event.is_set() and self.en_cours:
            if not self._pause_event.is_set():
                self._stop_event.wait(0.2)
                continue

            # Délai réel entre deux pas simulés en fonction de la vitesse
            delai_reel = max(0.02, min(2.0, self.pas_secondes_sim / max(self.vitesse, 1.0)))
            if self._stop_event.wait(delai_reel):
                break

            self.avancer(1)

    def pause(self):
        """Suspend la progression de la simulation."""
        self._pause_event.clear()
        self.en_pause = True
        return self.etat()

    def reprendre(self):
        """Reprend la simulation après une pause."""
        self._pause_event.set()
        self.en_pause = False
        return self.etat()

    def arreter(self):
        """Arrête définitivement la simulation en cours."""
        self._stop_event.set()
        self.en_cours = False
        self.en_pause = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        return self.etat()

    def etat(self):
        """Fournit l'état complet de la simulation pour les requêtes de contrôle."""
        total_sec = (self.fin_mission - self.debut_mission).total_seconds() if (self.fin_mission and self.debut_mission) else 1.0
        courant_sec = (self.horloge_simulee - self.debut_mission).total_seconds() if (self.horloge_simulee and self.debut_mission) else 0.0
        pct = round(max(0.0, min(100.0, (courant_sec / total_sec) * 100.0)), 1)

        t_str = self.horloge_simulee.strftime(FORMAT_DATE_UTC) if self.horloge_simulee else None

        return {
            "en_cours": self.en_cours,
            "en_pause": self.en_pause,
            "scenario": self.scenario,
            "horloge_simulee": t_str,
            "vitesse": self.vitesse,
            "progression_pct": pct,
        }


# Instance globale unique du simulateur en direct
_gestionnaire = GestionnaireSimulation()


def demarrer(scenario="nominal", vitesse=None):
    """Démarre le scénario accéléré en direct."""
    return _gestionnaire.demarrer(scenario=scenario, vitesse=vitesse)


def pause():
    """Met en pause la simulation en cours."""
    return _gestionnaire.pause()


def reprendre_simulation():
    """Reprend la simulation en cours."""
    return _gestionnaire.reprendre()


def arreter():
    """Arrête la simulation."""
    return _gestionnaire.arreter()


def etat_simulation():
    """Renvoie l'état de la simulation."""
    return _gestionnaire.etat()


def avancer(n_pas=1):
    """Avance d'un nombre déterminé de pas (pour tests déterministes)."""
    return _gestionnaire.avancer(n_pas=n_pas)
