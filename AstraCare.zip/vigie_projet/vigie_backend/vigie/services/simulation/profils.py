"""Valeurs de base et bruit de chaque mesure, difference entre astronautes"""
