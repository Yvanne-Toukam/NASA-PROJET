"""Lecture et ecriture de references_perso"""
