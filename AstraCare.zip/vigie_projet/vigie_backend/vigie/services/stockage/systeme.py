"""Compteurs et etat du systeme (trames rejetees, age des sources)"""
