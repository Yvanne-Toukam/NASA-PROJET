"""Service STOCKAGE : seul endroit qui ecrit du SQL"""
