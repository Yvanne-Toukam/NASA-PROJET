"""connecter() : ouvre la base, active WAL, cree les tables"""
