"""Journal des alertes : creer sans doublon, acquitter, lister"""
