"""inserer_mesure(), lire_serie(), derniere_mesure()"""
