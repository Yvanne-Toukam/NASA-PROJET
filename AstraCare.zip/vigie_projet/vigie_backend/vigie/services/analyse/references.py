"""Calcul et mise à jour des références individuelles (ligne de base de chaque astronaute)."""
from datetime import datetime, timedelta
import math

from vigie.core.config import charger_seuils
from vigie.services.database import references_perso
from vigie.services.analyse.statistiques import serie_journaliere


def calculer_references(con, astro, cfg=None):
    """Calcule la moyenne et l'écart-type de référence pour chaque paramètre sur la période de base.
    
    Enregistre le résultat dans la table references_perso avec periode_debut et periode_fin.
    Renvoie le nombre de références calculées.
    """
    cfg = cfg or charger_seuils()
    jours_base = cfg.get("jours_base", 14)
    nb_calcules = 0

    for mesure in cfg.get("indicateurs", {}):
        serie = serie_journaliere(con, astro, mesure)
        if len(serie) < 3:
            continue

        jours_tries = sorted(serie.keys())
        date_debut = datetime.strptime(jours_tries[0], "%Y-%m-%d")
        date_fin_base = date_debut + timedelta(days=jours_base)

        valeurs_base = [
            serie[j]
            for j in jours_tries
            if datetime.strptime(j, "%Y-%m-%d") < date_fin_base
        ]

        if len(valeurs_base) < 3:
            continue

        n = len(valeurs_base)
        moyenne = sum(valeurs_base) / n
        variance = sum((v - moyenne) ** 2 for v in valeurs_base) / max(n - 1, 1)
        ecart_type = math.sqrt(variance)

        periode_debut = jours_tries[0]
        # Dernier jour effectif de la fenêtre de base
        derniers_jours_base = [j for j in jours_tries if datetime.strptime(j, "%Y-%m-%d") < date_fin_base]
        periode_fin = derniers_jours_base[-1]

        references_perso.inserer_reference(
            con,
            astro=astro,
            mesure=mesure,
            moyenne=round(moyenne, 2),
            ecart_type=round(ecart_type, 3),
            n=n,
            periode_debut=periode_debut,
            periode_fin=periode_fin,
        )
        nb_calcules += 1

    return nb_calcules
