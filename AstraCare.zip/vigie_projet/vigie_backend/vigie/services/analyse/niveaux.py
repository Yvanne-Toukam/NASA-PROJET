"""Évaluation des niveaux de criticité et génération de messages explicables (P4, P5)."""


def determiner_niveau(param_cfg, valeur, ref=None):
    """Détermine le niveau d'alerte (0: nominal, 1: à surveiller, 2: critique) selon seuils.yaml."""
    t = param_cfg.get("type")

    if t == "relatif_haut":
        if not ref or ref.get("moyenne") is None:
            return 0
        moy = ref["moyenne"]
        ecart_pct = (valeur - moy) / moy * 100.0
        abs_min = param_cfg.get("abs_min", -float("inf"))
        abs_max = param_cfg.get("abs_max", float("inf"))
        if ecart_pct >= param_cfg.get("n2", 25) or not (abs_min <= valeur <= abs_max):
            return 2
        if ecart_pct >= param_cfg.get("n1", 10):
            return 1
        return 0

    if t == "seuil_haut":
        if valeur >= param_cfg.get("n2", 999):
            return 2
        if valeur >= param_cfg.get("n1", 999):
            return 1
        return 0

    if t == "seuil_bas":
        if valeur <= param_cfg.get("n2", -999):
            return 2
        if valeur <= param_cfg.get("n1", -999):
            return 1
        return 0

    if t == "cible_bas":
        cible = param_cfg.get("cible", 100.0)
        ratio = valeur / max(cible, 1e-6)
        if ratio <= param_cfg.get("n2", 0.3):
            return 2
        if ratio <= param_cfg.get("n1", 0.6):
            return 1
        return 0

    return 0


def formater_texte(mesure, param_cfg, valeur, ecart_pct, regle):
    """Génère un message d'alerte explicable, sourcé et sans diagnostic médical (P4, P5)."""
    libelle = param_cfg.get("libelle", mesure)
    if regle.startswith("DERIVE"):
        return f"{libelle} : dérive lente détectée par rapport à votre référence individuelle"

    suffixe = f" ({ecart_pct:+.1f} % vs référence)" if ecart_pct is not None else ""
    return f"{libelle} à {valeur:.1f}{suffixe}"
