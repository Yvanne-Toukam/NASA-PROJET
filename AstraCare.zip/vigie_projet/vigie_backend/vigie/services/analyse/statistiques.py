"""Briques statistiques du moteur Vigie (z-score, CUSUM, séries journalières)."""
from datetime import datetime


def zscore(valeur, moyenne, ecart_type):
    """Calcule le score centré réduit (z-score) avec protection contre la division par zéro."""
    return (valeur - moyenne) / max(ecart_type, 1e-6)


def cusum(zscores, k=0.5, h=5.0):
    """Algorithme CUSUM pour la détection précoce de dérive lente.
    
    Accumule les écarts supérieurs à la tolérance k.
    Renvoie True dès que la somme cumulée dépasse le seuil de décision h.
    Une seule valeur extrême isolée ne suffit jamais à déclencher (P2).
    """
    somme = 0.0
    for z in zscores:
        somme = max(0.0, somme + (z - k))
        if somme > h:
            return True
    return False


def serie_journaliere(con, astro, mesure, jusqua=None):
    """Calcule la moyenne quotidienne des mesures de qualité 'ok' pour un astronaute.
    
    Renvoie un dictionnaire ordonné {date_str ('YYYY-MM-DD'): valeur_moyenne}.
    Les mesures altérées (bruit, capteur_hs) sont strictement exclues des calculs (P6).
    """
    requete = (
        "SELECT SUBSTR(create_at, 1, 10) AS jour, AVG(valeur) AS moyenne "
        "FROM mesures "
        "WHERE astro = ? AND mesure = ? AND qualite = 'ok' "
    )
    params = [astro, mesure]
    if jusqua:
        requete += "AND create_at <= ? "
        params.append(str(jusqua))
    requete += "GROUP BY SUBSTR(create_at, 1, 10) ORDER BY jour ASC"

    lignes = con.execute(requete, params).fetchall()
    return {l["jour"]: float(l["moyenne"]) for l in lignes}


def calculer_pente_tendance(valeurs):
    """Calcule la pente d'une série par régression linéaire élémentaire (sans dépendance obligatoire)."""
    n = len(valeurs)
    if n < 2:
        return 0.0
    x_mean = (n - 1) / 2.0
    y_mean = sum(valeurs) / n
    numerateur = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(valeurs))
    denominateur = sum((i - x_mean) ** 2 for i in range(n))
    if denominateur == 0:
        return 0.0
    pente = numerateur / denominateur
    # Variation totale estimée sur la période
    return pente * n
