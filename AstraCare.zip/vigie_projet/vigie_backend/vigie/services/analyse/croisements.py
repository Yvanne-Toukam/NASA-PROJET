"""Règles de croisement causes-effets CR-01 à CR-05 (analyse multi-paramètres)."""
from vigie.core.config import charger_regles


def evaluer_croisements(indicateurs, cabine=None, cfg=None):
    """Évalue les règles de croisement causes-effets.
    
    Toutes les alertes formulées respectent le principe P5 :
    aucun diagnostic affirmatif, qualification factuelle de signes compatibles
    et recommandation d'évaluation par le médecin de bord.
    """
    croisements = []

    def get_ind(m):
        return indicateurs.get(m)

    pouls = get_ind("pouls")
    temp = get_ind("temp_peau")
    som = get_ind("sommeil")
    hrv = get_ind("hrv")
    act = get_ind("activite")
    spo2 = get_ind("spo2")
    resp = get_ind("resp")
    force = get_ind("force_main")

    # CR-01 : Signes compatibles avec un début d'infection
    if pouls and temp and som and pouls.get("ref") and temp.get("ref") and som.get("ref"):
        if (
            temp["valeur"] >= temp["ref"] + 0.5
            and (pouls.get("ecart_pct") or 0) >= 8.0
            and som["valeur"] <= som["ref"] - 1.0
        ):
            croisements.append({
                "regle": "CR-01",
                "niveau": 1,
                "module": "croisement",
                "texte_court": "Signes compatibles avec un début d'infection : isolement conseillé, prévenir le médecin",
            })

    # CR-02 : Perte de condition physique
    if act and pouls and hrv and pouls.get("ref") and hrv.get("ref"):
        cible_act = 120.0  # minutes recommandées
        if (
            act["valeur"] < 0.6 * cible_act
            and (pouls.get("ecart_pct") or 0) > 0
            and (hrv.get("ecart_pct") or 0) < 0
        ):
            croisements.append({
                "regle": "CR-02",
                "niveau": 1,
                "module": "croisement",
                "texte_court": "Perte de condition physique : reprendre le programme d'exercice, adapter la séance",
            })

    # CR-03 : Dégradation respiratoire combinée
    if spo2 and resp:
        if spo2["valeur"] <= 92.0 and resp["valeur"] >= 22.0:
            croisements.append({
                "regle": "CR-03",
                "niveau": 2,
                "module": "croisement",
                "texte_court": "SpO2 basse associée à une fréquence respiratoire élevée : repos immédiat, contrôle médecin",
            })

    # CR-04 : Impact CO2 cabine sur l'équipage
    co2_val = cabine.get("co2") if cabine else None
    if co2_val and co2_val >= 2500.0 and pouls and (pouls.get("ecart_pct") or 0) >= 5.0:
        croisements.append({
            "regle": "CR-04",
            "niveau": 1,
            "module": "croisement",
            "texte_court": "Taux de CO2 cabine élevé avec élévation du pouls : vérifier le système de ventilation",
        })

    # CR-05 : Fatigue cumulée
    if som and force and force.get("ref"):
        ecart_force = force.get("ecart_pct") or 0
        if som["valeur"] <= 5.5 and ecart_force <= -15.0:
            croisements.append({
                "regle": "CR-05",
                "niveau": 1,
                "module": "croisement",
                "texte_court": "Baisse cumulée du sommeil et de la force de préhension : repos préconisé",
            })

    return croisements
