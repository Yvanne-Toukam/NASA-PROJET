"""Lecture et agregation pandas (moyennes par jour, fenetres)"""
