"""Construction des alertes : regroupement, texte court, regle"""
