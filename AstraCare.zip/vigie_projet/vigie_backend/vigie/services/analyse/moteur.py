"""Moteur d'analyse de Vigie (P2 Le calcul décide, l'IA explique).

Prend en entrée la base SQLite et un identifiant d'astronaute.
Produit le JSON contractuel (section 13.5) complet et explicable (P4).
Ne pose aucun diagnostic médical ni prescription (P5).
"""
from datetime import datetime, timezone

from vigie.core.config import charger_seuils
from vigie.core.constantes import MODULES_SANTE, FORMAT_DATE_UTC
from vigie.services.database import references_perso, alertes as db_alertes
from vigie.services.analyse.references import calculer_references
from vigie.services.analyse.statistiques import (
    serie_journaliere,
    zscore,
    cusum,
    calculer_pente_tendance,
)
from vigie.services.analyse.niveaux import determiner_niveau, formater_texte
from vigie.services.analyse.croisements import evaluer_croisements


def maintenant():
    """Date et heure courante en UTC au format contractuel strict."""
    return datetime.now(timezone.utc).strftime(FORMAT_DATE_UTC)


def analyser(con, astro, jusqua=None, cfg=None):
    """Calcule l'état de santé complet d'un astronaute.
    
    `jusqua` permet de rejouer l'analyse dans le temps (utile pour tester la détection précoce).
    Renvoie le dictionnaire JSON standard conforme au contrat.
    """
    cfg = cfg or charger_seuils()
    cusum_cfg = cfg.get("cusum", {"k": 0.5, "h": 5.0})
    k_cusum = cusum_cfg.get("k", 0.5)
    h_cusum = cusum_cfg.get("h", 5.0)

    # Récupération des références personnelles de l'astronaute
    lignes_refs = references_perso.select_references_astro(con, astro)
    refs = {r["mesure"]: r for r in lignes_refs}

    # Recherche du timestamp de la dernière mesure pour cet astronaute
    requete_max = "SELECT MAX(create_at) FROM mesures WHERE astro = ?"
    params_max = [astro]
    if jusqua:
        requete_max += " AND create_at <= ?"
        params_max.append(str(jusqua))
    max_t_row = con.execute(requete_max, params_max).fetchone()
    dernier_t_str = max_t_row[0] if (max_t_row and max_t_row[0]) else None

    # Normalisation de l'affichage de la date en UTC
    if dernier_t_str:
        t_affiche = dernier_t_str.replace("T", " ")[:19]
    else:
        t_affiche = maintenant()

    # Initialisation des 4 modules de santé
    modules = {m: {"niveau": 0, "indicateurs": []} for m in MODULES_SANTE}
    alertes = []
    indicateurs_dict = {}

    indicateurs_cfg = cfg.get("indicateurs", {})

    for mesure, param_cfg in indicateurs_cfg.items():
        module_nom = param_cfg.get("module", "cardio")
        if module_nom not in modules:
            modules[module_nom] = {"niveau": 0, "indicateurs": []}

        serie = serie_journaliere(con, astro, mesure, jusqua=jusqua)
        if not serie:
            continue

        jours_tries = sorted(serie.keys())
        fenetre = param_cfg.get("fenetre", 1)
        derniers_jours = jours_tries[-fenetre:]
        valeurs_fenetre = [serie[j] for j in derniers_jours]
        valeur = sum(valeurs_fenetre) / len(valeurs_fenetre)

        ref = refs.get(mesure)
        niveau_seuil = determiner_niveau(param_cfg, valeur, ref)
        regle = f"SEUIL_{mesure.upper()}"

        ecart_pct = None
        tendance = "stable"
        derive = False

        if ref and ref.get("moyenne"):
            moy = ref["moyenne"]
            sigma = ref.get("ecart_type", 1.0)
            ecart_pct = round((valeur - moy) / moy * 100.0, 1)

            # Détection de dérive lente par CUSUM sur les points postérieurs à la période de base
            fin_base_str = ref.get("periode_fin") or ref.get("periode_debut")
            jours_apres_base = [j for j in jours_tries if j > fin_base_str] if fin_base_str else jours_tries

            sens_derive = param_cfg.get("derive")  # 'haut' ou 'bas'
            if sens_derive and len(jours_apres_base) >= 3:
                facteur_sens = 1.0 if sens_derive == "haut" else -1.0
                zscores = [
                    facteur_sens * zscore(serie[j], moy, sigma)
                    for j in jours_apres_base
                ]
                derive = cusum(zscores, k=k_cusum, h=h_cusum)

            # Tendance sur les 14 derniers jours
            fenetre_14j = [serie[j] for j in jours_tries[-14:]]
            if len(fenetre_14j) >= 5:
                pente = calculer_pente_tendance(fenetre_14j)
                seuil_sig = max(sigma, 0.5)
                if pente > seuil_sig:
                    tendance = "hausse"
                elif pente < -seuil_sig:
                    tendance = "baisse"

        # Priorité de la dérive lente : si le seuil classique n'est pas encore franchi
        if derive and niveau_seuil == 0:
            niveau = 1
            regle = f"DERIVE_{mesure.upper()}"
        else:
            niveau = niveau_seuil
            if niveau > 0:
                regle += f"_N{niveau}"

        # Calcul de la confiance et fraîcheur
        confiance = 1.0
        if dernier_t_str and jours_tries:
            try:
                date_derniere = datetime.strptime(dernier_t_str[:10], "%Y-%m-%d")
                date_mesure = datetime.strptime(jours_tries[-1], "%Y-%m-%d")
                age_jours = (date_derniere - date_mesure).days
                confiance = round(max(0.2, 1.0 - 0.25 * max(0, age_jours)), 2)
            except Exception:
                confiance = 1.0

        indicateur = {
            "mesure": mesure,
            "valeur": round(valeur, 2),
            "ref": round(ref["moyenne"], 2) if ref else None,
            "ecart_pct": ecart_pct,
            "tendance_14j": tendance,
            "derive": derive,
            "niveau": niveau,
            "confiance": confiance,
            "seuil_n1": param_cfg.get("n1"),
            "seuil_n2": param_cfg.get("n2"),
            "seuil_type": param_cfg.get("type"),
            "abs_min": param_cfg.get("abs_min"),
            "abs_max": param_cfg.get("abs_max"),
            "libelle": param_cfg.get("libelle", mesure),
            "est_muet": False,
        }

        indicateurs_dict[mesure] = indicateur
        modules[module_nom]["indicateurs"].append(indicateur)
        modules[module_nom]["niveau"] = max(modules[module_nom]["niveau"], niveau)

        if niveau > 0:
            texte_court = formater_texte(mesure, param_cfg, valeur, ecart_pct, regle)
            alertes.append({
                "regle": regle,
                "niveau": niveau,
                "module": module_nom,
                "texte_court": texte_court,
            })

    # Analyse des croisements causes-effets
    croisements = evaluer_croisements(indicateurs_dict, cfg=cfg)
    for c in croisements:
        alertes.append(c)

    # Détection des capteurs muets (P6 : capteur_hs sur la dernière mesure)
    # On regarde si la dernière mesure reçue pour chaque capteur est 'capteur_hs'
    requete_muettes = (
        "SELECT m.mesure FROM mesures m "
        "INNER JOIN ("
        "  SELECT MAX(id) AS max_id FROM mesures WHERE astro = ? GROUP BY mesure"
        ") dern ON m.id = dern.max_id "
        "WHERE m.qualite = 'capteur_hs'"
    )
    lignes_muettes = con.execute(requete_muettes, (astro,)).fetchall()
    sources_muettes = [l["mesure"] for l in lignes_muettes]

    # Dégradation de la confiance et marquage pour les capteurs muets
    if sources_muettes:
        for mod in modules.values():
            for ind in mod["indicateurs"]:
                if ind["mesure"] in sources_muettes:
                    ind["confiance"] = min(ind["confiance"], 0.4)
                    ind["est_muet"] = True

    # Calcul du niveau global
    niveaux_modules = [m["niveau"] for m in modules.values()]
    niveaux_croisements = [c["niveau"] for c in croisements]
    niveau_global = max(niveaux_modules + niveaux_croisements) if (niveaux_modules or niveaux_croisements) else 0

    return {
        "astro": astro,
        "t": t_affiche,
        "niveau_global": niveau_global,
        "modules": modules,
        "alertes": alertes,
        "croisements": croisements,
        "sources_muettes": sources_muettes,
        "config_seuils": {
            k: {
                "libelle": v.get("libelle", k),
                "n1": v.get("n1"),
                "n2": v.get("n2"),
                "type": v.get("type"),
                "abs_min": v.get("abs_min"),
                "abs_max": v.get("abs_max"),
                "module": v.get("module"),
            }
            for k, v in indicateurs_cfg.items()
        },
    }


def enregistrer_alertes(con, resultat_analyse):
    """Enregistre les alertes calculées sans doublon (EF-16).
    
    Une alerte portant sur la même règle n'est pas recréée si elle est déjà active et non acquittée.
    Renvoie le nombre de nouvelles alertes insérées.
    """
    astro = resultat_analyse["astro"]
    t = resultat_analyse["t"]
    nb_nouvelles = 0

    for a in resultat_analyse.get("alertes", []):
        regle = a["regle"]
        # Vérification anti-doublon d'alerte active
        if not db_alertes.alerte_active_existe(con, astro, regle):
            db_alertes.inserer_alerte(
                con,
                astro=astro,
                module=a["module"],
                niveau=a["niveau"],
                regle=regle,
                texte_court=a.get("texte_court", regle),
                detail=a,
                t=t,
            )
            nb_nouvelles += 1

    return nb_nouvelles
