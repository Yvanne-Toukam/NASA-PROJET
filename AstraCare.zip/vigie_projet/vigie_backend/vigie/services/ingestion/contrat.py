"""Contrat de la trame série Vigie (cahier des charges section 10).
Format attendu (7 champs séparés par des virgules) :
source,astro,mesure,valeur,unite,qualite,seq
"""
import math
import re
from vigie.core.constantes import CATALOGUE, QUALITES, SOURCES, NB_CHAMPS_TRAME

# Décision 1 : Personnes au format AST2026-001 (AST\d{4}-\d{3})
REGEX_ASTRO = re.compile(r"^AST\d{4}-\d{3}$")

# Décision 1 : Zones au format cabine\d, avec support des noms symboliques pour compatibilité
REGEX_ZONE = re.compile(r"^(cabine\d+|module_vie|laboratoire|poste_pilotage)$")


def identifiant_valide(source, astro):
    """Vérifie si l'identifiant est conforme selon la source :
    - 'cab' mesure une zone de cabine (ex. 'cabine1', 'module_vie')
    - 'watch', 'dosi', 'sante' mesurent un astronaute individuel (ex. 'AST2026-001')
    """
    if source == "cab":
        return bool(REGEX_ZONE.match(astro))
    return bool(REGEX_ASTRO.match(astro))


def valider_trame(ligne):
    """Valide une ligne reçue sur le port série.
    
    Renvoie (trame_dict, None) si la trame est valide.
    Renvoie (None, motif_erreur) si la trame est rejetée.
    
    Règles contractuelles :
    - Exactement 7 champs obligatoires
    - Source reconnue ('watch', 'dosi', 'cab', 'sante')
    - Qualité reconnue ('ok', 'bruit', 'capteur_hs')
    - Mesure reconnue avec source et unité correspondante
    - Valeur numérique finie
    - Respect des plages min/max (sauf si qualite == 'capteur_hs')
    - Numéro de séquence entier positif ou nul
    """
    if not isinstance(ligne, str):
        return None, "trame non textuelle"

    champs = [c.strip() for c in ligne.strip().split(",")]
    if len(champs) != NB_CHAMPS_TRAME:
        return None, f"champs: {len(champs)} au lieu de {NB_CHAMPS_TRAME}"

    source, astro, mesure, valeur_str, unite, qualite, seq_str = champs

    if source not in SOURCES:
        return None, f"source inconnue: {source}"

    if qualite not in QUALITES:
        return None, f"qualite inconnue: {qualite}"

    if mesure not in CATALOGUE:
        return None, f"mesure inconnue: {mesure}"

    source_attendue, unite_attendue, vmin, vmax, _ = CATALOGUE[mesure]

    if source != source_attendue:
        return None, f"source {source} incorrecte pour {mesure} (attendue: {source_attendue})"

    if unite != unite_attendue:
        return None, f"unite {unite} incorrecte pour {mesure} (attendue: {unite_attendue})"

    if not identifiant_valide(source, astro):
        return None, f"identifiant invalide: {astro} pour la source {source}"

    try:
        valeur = float(valeur_str)
    except ValueError:
        return None, f"valeur non numerique: {valeur_str}"

    if not math.isfinite(valeur):
        return None, f"valeur non finie: {valeur_str}"

    # P6 : Un capteur en panne (qualite == 'capteur_hs') est enregistré même hors plage
    # afin de remonter l'état « capteur muet », sans bloquer l'acquisition.
    if qualite != "capteur_hs" and not (vmin <= valeur <= vmax):
        return None, f"hors plage: {mesure}={valeur} (attendu {vmin} a {vmax})"

    try:
        seq = int(seq_str)
    except ValueError:
        return None, f"seq non entier: {seq_str}"

    if seq < 0:
        return None, f"seq negatif: {seq}"

    return {
        "source": source,
        "astro": astro,
        "mesure": mesure,
        "valeur": valeur,
        "unite": unite,
        "qualite": qualite,
        "seq": seq,
    }, None
