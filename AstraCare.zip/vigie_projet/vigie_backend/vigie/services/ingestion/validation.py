"""Module de validation des trames séries (service ingestion)."""
from .contrat import (
    valider_trame,
    identifiant_valide,
    CATALOGUE,
    SOURCES,
    QUALITES,
    REGEX_ASTRO,
    REGEX_ZONE,
)

__all__ = [
    "valider_trame",
    "identifiant_valide",
    "CATALOGUE",
    "SOURCES",
    "QUALITES",
    "REGEX_ASTRO",
    "REGEX_ZONE",
]
