"""Lecteur série de Vigie (CDC 12.2) : ingestion, validation, détection de doublons et traçabilité."""
import time
from datetime import datetime, timezone

from vigie.services.database import mesures, systeme, trames_rejetees
from vigie.services.ingestion.contrat import valider_trame


def maintenant():
    """Date et heure courante en UTC (format strict AAAA-MM-JJ HH:MM:SS)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def traiter_ligne(con, ligne, t=None):
    """Valide une ligne série et l'enregistre en base de données.
    
    Renvoie :
    - 'ok' si la trame est valide et insérée avec succès
    - 'doublon' si la trame a déjà été reçue (même source, astro, seq)
    - 'rejetee' si la trame est invalide (mauvais format, hors plage, etc.)
    
    Testable directement en mémoire, sans port série physique branché.
    """
    horodatage = t or maintenant()
    trame, motif = valider_trame(ligne)

    if trame is None:
        trames_rejetees.inserer_trame_rejetee(con, ligne=ligne, motif=motif, t=horodatage)
        systeme.incrementer(con, "trames_rejetees")
        return "rejetee"

    mesure_id = mesures.inserer_mesure(
        con,
        astro=trame["astro"],
        source=trame["source"],
        mesure=trame["mesure"],
        valeur=trame["valeur"],
        unite=trame["unite"],
        seq=trame["seq"],
        qualite=trame["qualite"],
        create_at=horodatage,
    )

    if mesure_id is None:
        systeme.incrementer(con, "trames_doublons")
        return "doublon"

    # Enregistrement de l'horodatage de réception pour surveiller l'âge des capteurs
    systeme.set_valeur(con, f"derniere_trame_{trame['source']}", horodatage)
    systeme.set_valeur(con, f"derniere_trame:{trame['source']}", horodatage)  # alias rétro-compatible

    # P6 Dégradation maîtrisée : signalement de capteur hors service sans blocage
    if trame["qualite"] == "capteur_hs":
        systeme.set_valeur(con, f"capteur_muet_{trame['astro']}_{trame['mesure']}", "1")

    return "ok"


def boucle(connecter, port="COM2", debit=9600, arret=None):
    """Boucle de lecture continue sur le port série (utilisée avec Proteus ou hub réel).
    
    Se reconnecte automatiquement si le port série virtuel ou physique se déconnecte.
    """
    try:
        import serial
    except ImportError:
        serial = None

    if serial is None:
        raise RuntimeError("pyserial n'est pas installé dans l'environnement")

    con = connecter()
    while not (arret and arret.is_set()):
        try:
            with serial.Serial(port, debit, timeout=1.0) as ser:
                while not (arret and arret.is_set()):
                    brut = ser.readline().decode("ascii", "ignore").strip()
                    if brut:
                        traiter_ligne(con, brut)
        except serial.SerialException:
            time.sleep(2.0)
