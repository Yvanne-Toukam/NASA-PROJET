"""Service INGESTION : du port serie jusqu'a la base"""
