"""Serveur API FastAPI de Vigie (P2 Le calcul décide, l'IA explique).

Toutes les données médicales proviennent du moteur d'analyse et de la base SQLite.
Aucun calcul médical n'est effectué dans les routes API.
Écoute exclusivement en local sur 127.0.0.1 (P3).
"""
import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.exceptions import HTTPException as StarletteHTTPException

from vigie.core.config import charger_seuils
from vigie.core.constantes import CATALOGUE
from vigie.core.journal import journal
from vigie.services.database import (
    actions,
    alertes as db_alertes,
    astronaute as db_astronaute,
    bilans as db_bilans,
    connectdb,
    examens as db_examens,
    mesures as db_mesures,
    references_perso,
    systeme as db_systeme,
    trames_rejetees as db_trames_rejetees,
)
from vigie.services.analyse import moteur as moteur_analyse
from vigie.services.analyse.references import calculer_references
from vigie.services.simulation import simulateur

# Initialisation de l'application FastAPI
app = FastAPI(
    title="Vigie - Système de surveillance de la santé des astronautes",
    description="API locale autonome pour le NASA Space Apps Challenge 2026",
    version="2.1.0",
)


# ---------------------------------------------------------------------
# Gestionnaire d'erreurs unique et journalisation serveur
# ---------------------------------------------------------------------
@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    """Intercepte les erreurs HTTP et renvoie un format d'erreur uniforme {"detail": ..., "code": ...}."""
    journal.warning("Erreur HTTP %s sur %s : %s", exc.status_code, request.url.path, exc.detail)
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "code": f"HTTP_{exc.status_code}"},
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Intercepte les erreurs de validation Pydantic (422) avec message d'erreur standard."""
    journal.warning("Erreur de validation 422 sur %s : %s", request.url.path, exc.errors())
    return JSONResponse(
        status_code=422,
        content={"detail": "Format de corps JSON non conforme aux spécifications.", "code": "VALIDATION_ERROR"},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """Capture toutes les exceptions non prévues, les journalise avec trace et protège le client."""
    journal.exception("Exception non gérée sur %s : %s", request.url.path, exc)
    return JSONResponse(
        status_code=500,
        content={"detail": "Erreur interne du serveur Vigie.", "code": "INTERNAL_SERVER_ERROR"},
    )


@contextmanager
def get_db():
    """Fournit une connexion SQLite sécurisée par requête avec fermeture garantie."""
    con = connectdb.connecter()
    try:
        yield con
    finally:
        con.close()


def _verifier_astronaute_actif(con, astro_id: str):
    """Vérifie que l'astronaute existe et n'a pas fait l'objet d'une suppression logique."""
    astro = db_astronaute.select_astronaute_id(con, astro_id)
    if not astro:
        raise HTTPException(status_code=404, detail=f"Astronaute inconnu ou inactif : {astro_id}")
    return astro


# Modèles Pydantic pour la validation stricte des corps de requêtes
class BilanIn(BaseModel):
    astro: str = Field(..., description="Identifiant unique de l'astronaute (ex. AST2026-001)")
    humeur: int = Field(..., ge=1, le=5, description="Évaluation de l'humeur de 1 à 5")
    stress: int = Field(..., ge=1, le=5, description="Niveau de stress de 1 à 5")
    fatigue: int = Field(..., ge=1, le=5, description="Niveau de fatigue de 1 à 5")
    symptomes: Optional[str] = Field("", description="Symptômes ressentis éventuels")
    note: Optional[str] = Field("", description="Commentaire libre de l'astronaute")


class ExamenIn(BaseModel):
    astro: str = Field(..., description="Identifiant unique de l'astronaute")
    type: str = Field(..., description="Type de mesure ou d'examen (ex. poids, densite_osseuse)")
    valeur: float = Field(..., description="Valeur numérique mesurée")
    unite: Optional[str] = Field("", description="Unité de mesure (ex. kg)")


class ScenarioIn(BaseModel):
    scenario: str = Field("nominal", description="Nom du scénario : nominal, derive_lente, urgence, panne_capteur")
    jours: int = Field(28, ge=7, le=90, description="Nombre de jours de données simulées")


class SimulationDemarrerIn(BaseModel):
    scenario: str = Field("nominal", description="Scénario : nominal, derive_lente, urgence, panne_capteur")
    vitesse: Optional[float] = Field(None, description="Vitesse accélérée en secondes simulées par seconde réelle")


class SimulationAvancerIn(BaseModel):
    pas: int = Field(1, ge=1, le=1000, description="Nombre de pas simulés à franchir de manière déterministe")


class QuestionIn(BaseModel):
    astro: str = Field(..., description="Identifiant de l'astronaute posant la question")
    question: str = Field(..., description="Texte de la question")


# ---------------------------------------------------------------------
# 1. GET /api/astronautes : Liste de l'équipage avec niveau global calculé
# ---------------------------------------------------------------------
@app.get("/api/astronautes")
def lister_astronautes():
    with get_db() as con:
        membres = db_astronaute.select_tous_astronautes(con)
        resultats = []
        for m in membres:
            # Calcul du niveau global exclusivement par le moteur Python
            etat = moteur_analyse.analyser(con, m["id"])
            m_dict = dict(m)
            m_dict["niveau_global"] = etat["niveau_global"]
            resultats.append(m_dict)
        return resultats


# ---------------------------------------------------------------------
# 2. GET /api/etat/{astro} : État de santé complet et indicateurs
# ---------------------------------------------------------------------
@app.get("/api/etat/{astro}")
def obtenir_etat(astro: str):
    with get_db() as con:
        _verifier_astronaute_actif(con, astro)
        etat = moteur_analyse.analyser(con, astro)
        # Enregistrement automatique des alertes dans le journal SQLite
        moteur_analyse.enregistrer_alertes(con, etat)
        etat["explication"] = None  # Réservé pour l'assistant IA
        return JSONResponse(content=etat, headers={"Cache-Control": "no-store"})


# ---------------------------------------------------------------------
# 3. GET /api/mesures/{astro} : Séries temporelles enrichies pour graphes
# ---------------------------------------------------------------------
@app.get("/api/mesures/{astro}")
def obtenir_mesures(
    astro: str,
    mesure: Optional[str] = Query("pouls", description="Paramètre spécifique filtré"),
    jours: int = Query(14, ge=1, le=365, description="Nombre de jours d'historique"),
    depuis: Optional[str] = Query(None, description="Horodatage exclusif pour extraction incrémentale"),
    limite: int = Query(500, ge=1, le=5000, description="Plafond du volume de points retournés"),
):
    with get_db() as con:
        _verifier_astronaute_actif(con, astro)
        nom_mesure = mesure or "pouls"

        # 1. Extraction chronologique des points réels depuis SQLite
        points = db_mesures.select_mesures_serie(
            con,
            astro,
            mesure=nom_mesure,
            jours=jours,
            depuis=depuis,
            limite=limite,
        )

        # 2. Référence individuelle calculée
        ref_ligne = references_perso.select_reference(con, astro, nom_mesure)
        ref_dict = (
            {
                "moyenne": round(ref_ligne["moyenne"], 2),
                "ecart_type": round(ref_ligne["ecart_type"], 2),
            }
            if ref_ligne else None
        )

        # 3. Seuils d'ingénierie issus de config/seuils.yaml via le moteur
        cfg = charger_seuils()
        ind_cfg = cfg.get("indicateurs", {}).get(nom_mesure, {})
        seuils_dict = (
            {
                "n1": ind_cfg.get("n1"),
                "n2": ind_cfg.get("n2"),
                "sens": ind_cfg.get("derive", "haut" if "haut" in ind_cfg.get("type", "") else "bas"),
                "type": ind_cfg.get("type"),
                "abs_min": ind_cfg.get("abs_min"),
                "abs_max": ind_cfg.get("abs_max"),
            }
            if ind_cfg else None
        )

        # 4. Alertes temporelles associées à ce signal
        alertes_associees = db_alertes.select_alertes_mesure(con, astro, nom_mesure, depuis=depuis)

        unite = CATALOGUE.get(nom_mesure, ("", "", "", "", ""))[1]

        reponse = {
            "mesure": nom_mesure,
            "unite": unite,
            "points": points,
            "reference": ref_dict,
            "seuils": seuils_dict,
            "alertes": alertes_associees,
        }
        return JSONResponse(
            content=reponse,
            headers={"Cache-Control": "no-store"},
        )


# ---------------------------------------------------------------------
# 4. POST /api/bilan : Enregistrement de l'auto-évaluation quotidienne
# ---------------------------------------------------------------------
@app.post("/api/bilan")
def enregistrer_bilan(bilan: BilanIn):
    with get_db() as con:
        _verifier_astronaute_actif(con, bilan.astro)
        bilan_id = db_bilans.inserer_bilan(
            con,
            astro=bilan.astro,
            humeur=bilan.humeur,
            stress=bilan.stress,
            fatigue=bilan.fatigue,
            symptomes=bilan.symptomes,
            note=bilan.note,
        )
        return {"ok": True, "bilan_id": bilan_id}


# ---------------------------------------------------------------------
# 5. POST /api/examen : Saisie manuelle d'examen médical
# ---------------------------------------------------------------------
@app.post("/api/examen")
def enregistrer_examen(examen: ExamenIn):
    with get_db() as con:
        _verifier_astronaute_actif(con, examen.astro)
        examen_id = db_examens.inserer_examen(
            con,
            astro=examen.astro,
            type_examen=examen.type,
            valeur=examen.valeur,
            unite=examen.unite,
        )
        return {"ok": True, "examen_id": examen_id}


# ---------------------------------------------------------------------
# 6. GET /api/alertes/{astro} : Historique des alertes
# ---------------------------------------------------------------------
@app.get("/api/alertes/{astro}")
def lister_alertes(astro: str):
    with get_db() as con:
        _verifier_astronaute_actif(con, astro)
        alertes_liste = db_alertes.select_alertes_astro(con, astro)
        return JSONResponse(content=alertes_liste, headers={"Cache-Control": "no-store"})


# ---------------------------------------------------------------------
# 7. POST /api/alertes/{id}/acquitter : Prise en compte par l'astronaute
# ---------------------------------------------------------------------
@app.post("/api/alertes/{id}/acquitter")
def acquitter_alerte(id: int):
    with get_db() as con:
        succes = db_alertes.acquitter_alerte(con, id)
        if not succes:
            raise HTTPException(status_code=404, detail="Alerte introuvable ou déjà acquittée")
        return {"ok": True, "id": id}


# ---------------------------------------------------------------------
# 8. POST /api/assistant : Assistant IA explicatif (501 non connecté)
# ---------------------------------------------------------------------
@app.post("/api/assistant")
def question_assistant(q: QuestionIn):
    raise HTTPException(
        status_code=501,
        detail="L'assistant IA explicatif (RAG/LLM) n'est pas encore activé sur ce banc de test.",
    )


# ---------------------------------------------------------------------
# 9. GET /api/cabine : Surveillance environnementale des zones de cabine
# ---------------------------------------------------------------------
@app.get("/api/cabine")
def surveillance_cabine():
    with get_db() as con:
        lignes_zones = con.execute(
            "SELECT DISTINCT astro FROM mesures WHERE source = 'cab'"
        ).fetchall()
        zones = [l[0] for l in lignes_zones]
        if not zones:
            zones = ["cabine1", "cabine2"]

        resultat = {}
        for z in zones:
            mesures_z = db_mesures.select_dernieres_mesures_zone(con, z)
            resultat[z] = {m["mesure"]: m["valeur"] for m in mesures_z}
        return JSONResponse(content=resultat, headers={"Cache-Control": "no-store"})


# ---------------------------------------------------------------------
# 10. Simulation en direct accélérée et contrôle temps réel
# ---------------------------------------------------------------------
@app.post("/api/simulation/demarrer")
def demarrer_simulation(s: SimulationDemarrerIn):
    """Démarre une simulation continue accélérée avec pré-remplissage et streaming temps réel."""
    if s.scenario not in simulateur.SCENARIOS:
        raise HTTPException(
            status_code=400,
            detail=f"Scénario inconnu. Scénarios acceptés : {', '.join(simulateur.SCENARIOS)}",
        )
    etat = simulateur.demarrer(scenario=s.scenario, vitesse=s.vitesse)
    return {"ok": True, **etat}


@app.post("/api/simulation/pause")
def pause_simulation():
    """Suspend l'horloge et la génération de mesures en arrière-plan."""
    etat = simulateur.pause()
    return {"ok": True, **etat}


@app.post("/api/simulation/reprendre")
def reprendre_simulation():
    """Relance la progression de l'horloge et de la génération de mesures."""
    etat = simulateur.reprendre_simulation()
    return {"ok": True, **etat}


@app.get("/api/simulation/etat")
def etat_simulation():
    """Consulte l'état d'exécution, l'horloge simulée et la progression de la mission."""
    return JSONResponse(content=simulateur.etat_simulation(), headers={"Cache-Control": "no-store"})


@app.post("/api/simulation/avancer")
def avancer_simulation(params: SimulationAvancerIn):
    """Avance la simulation de n pas immédiatement (pour tests automatisés déterministes)."""
    etat = simulateur.avancer(n_pas=params.pas)
    return {"ok": True, **etat}


@app.post("/api/simulation/scenario")
def lancer_scenario(s: ScenarioIn):
    """Route historique rétro-compatible : déclenche le démarrage immédiat du scénario."""
    if s.scenario not in simulateur.SCENARIOS:
        raise HTTPException(
            status_code=400,
            detail=f"Scénario inconnu. Scénarios acceptés : {', '.join(simulateur.SCENARIOS)}",
        )
    etat = simulateur.demarrer(scenario=s.scenario)
    return {
        "ok": True,
        "scenario": s.scenario,
        "trames_generees": 14 * 8 * len(simulateur.ASTROS),
        **etat,
    }


# ---------------------------------------------------------------------
# 11. GET /api/sante : Télémétrie de santé système et âge des capteurs
# ---------------------------------------------------------------------
@app.get("/api/sante")
def sante_systeme():
    with get_db() as con:
        try:
            nb_mesures = db_mesures.compter_mesures(con)
        except Exception:
            nb_mesures = 0

        try:
            nb_rejets = db_trames_rejetees.compter_rejets(con)
        except Exception:
            nb_rejets = 0

        # En simulation active, l'horloge de référence pour l'âge est l'horloge simulée
        sim_etat = simulateur.etat_simulation()
        if sim_etat["en_cours"] and sim_etat["horloge_simulee"]:
            try:
                reference_dt = datetime.strptime(sim_etat["horloge_simulee"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            except Exception:
                reference_dt = datetime.now(timezone.utc)
        else:
            reference_dt = datetime.now(timezone.utc)

        dernieres_sources = {}
        toutes_cles = db_systeme.select_tout(con)

        sources_officielles = ["watch", "dosi", "cab", "sante"]
        has_mute = False

        for src in sources_officielles:
            row = con.execute(
                "SELECT create_at FROM mesures WHERE source = ? ORDER BY create_at DESC LIMIT 1",
                (src,),
            ).fetchone()

            t_val = row[0] if (row and row[0]) else toutes_cles.get(f"derniere_trame_{src}")
            if t_val:
                t_propre = str(t_val).replace("T", " ")[:19]
                try:
                    dt_trame = datetime.strptime(t_propre, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
                    age_sec = max(0, int((reference_dt - dt_trame).total_seconds()))
                except Exception:
                    age_sec = 0

                if age_sec < 60:
                    age_txt = f"{age_sec} s"
                elif age_sec < 3600:
                    age_txt = f"{age_sec // 60} min"
                elif age_sec < 86400:
                    age_txt = f"{age_sec // 3600} h"
                else:
                    age_txt = f"{age_sec // 86400} j"

                dernieres_sources[src] = {
                    "derniere_date": t_propre,
                    "age_secondes": age_sec,
                    "age": age_txt,
                }
            else:
                dernieres_sources[src] = {
                    "derniere_date": None,
                    "age_secondes": None,
                    "age": "Aucune trame",
                }

        row_hs = con.execute("SELECT 1 FROM mesures WHERE qualite = 'capteur_hs' LIMIT 1").fetchone()
        if row_hs:
            has_mute = True

        etat_systeme = "degrade" if (has_mute or nb_rejets > 5) else "ok"

        reponse = {
            "etat": etat_systeme,
            "statut": "operationnel" if etat_systeme == "ok" else "mode degrade",
            "trames_rejetees": nb_rejets,
            "dernieres_trames": dernieres_sources,
            "nb_mesures": nb_mesures,
            "modele_local": "non branche",
        }
        return JSONResponse(content=reponse, headers={"Cache-Control": "no-store"})


# ---------------------------------------------------------------------
# 12. GET /api/config/seuils : Récupération des seuils configurés
# ---------------------------------------------------------------------
@app.get("/api/config/seuils")
def obtenir_seuils():
    return JSONResponse(content=charger_seuils(), headers={"Cache-Control": "no-store"})


# ---------------------------------------------------------------------
# Service statique des fichiers du Frontend à la racine
# ---------------------------------------------------------------------
racine_projet = Path(__file__).resolve().parents[2]
dossier_frontend = racine_projet / "vigie_frontend"
if not dossier_frontend.is_dir():
    dossier_frontend = racine_projet / "interface"

if dossier_frontend.is_dir():
    app.mount("/", StaticFiles(directory=str(dossier_frontend), html=True), name="frontend")
