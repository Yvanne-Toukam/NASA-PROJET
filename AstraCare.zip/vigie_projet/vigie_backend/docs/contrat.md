# Contrat Technique du Projet Vigie (v2.1)
NASA International Space Apps Challenge 2026

Ce document formalise les contrats d'interface non négociables du système Vigie :
1. Format de la trame série
2. Schéma de la base de données SQLite
3. Spécification du JSON d'analyse du moteur
4. Spécification des routes de l'API locale avec exemples de réponses réelles
5. Changements de contrat (Traçabilité des évolutions v2.0 -> v2.1)

---

## 1. Trame Série

### Format de ligne (9600 bauds, 8N1, fin de ligne `\n`)
```text
source,astro,mesure,valeur,unite,qualite,seq
```

- **source** : `watch` | `dosi` | `cab` | `sante`
- **astro** :
  - Pour une personne : `AST2026-001` à `AST2026-999` (format `^AST\d{4}-\d{3}$`)
  - Pour une zone cabine : `cabine1`, `cabine2` (ou zones nommées de bord `module_vie`, `laboratoire`, `poste_pilotage`)
- **qualite** : `ok` | `bruit` | `capteur_hs`
- **seq** : entier incrémental `>= 0` envoyé par l'émetteur pour la détection anti-doublon

### Catalogue des 15 mesures autorisées et plages valides

| Mesure | Source attendue | Unité | Plage min-max | Module associé |
|---|---|---|---|---|
| `pouls` | `watch` | `bpm` | 20 à 250 | cardio |
| `hrv` | `watch` | `ms` | 5 à 200 | cardio |
| `spo2` | `watch` | `pct` | 70 à 100 | cardio |
| `tension_sys` | `sante` | `mmHg` | 60 à 220 | cardio |
| `tension_dia` | `sante` | `mmHg` | 30 à 140 | cardio |
| `resp` | `watch` | `/min` | 4 à 50 | cardio |
| `temp_peau` | `watch` | `degC` | 30 à 42 | immunite |
| `activite` | `watch` | `min` | 0 à 600 | os_muscles |
| `force_main` | `sante` | `kg` | 5 à 80 | os_muscles |
| `sommeil` | `watch` | `h` | 0 à 14 | comportement |
| `debit_dose` | `dosi` | `uSvh` | 0 à 5000 | immunite |
| `co2` | `cab` | `ppm` | 300 à 20000 | cabine |
| `o2` | `cab` | `pct` | 15 à 25 | cabine |
| `temp_cabine` | `cab` | `degC` | 10 à 40 | cabine |
| `humidite` | `cab` | `pct` | 5 à 95 | cabine |

### Règles de rejet et de tolérance (P6)
- **Rejet strict** : nombre de champs != 7, source inconnue, identifiant invalide, mesure inconnue, mauvaise unité, valeur non numérique / infinie, numéro de séquence négatif ou non entier, valeur hors plage si `qualite != 'capteur_hs'`.
- **Règle P6 Dégradation maîtrisée** : une trame portant `qualite='capteur_hs'` est acceptée et stockée en base même hors plage. Elle est exclue des calculs statistiques et active le signalement « capteur muet ».
- **Anti-doublon** : le triplet `(source, astro, seq)` est unique. Un doublon est ignoré sans altérer les compteurs d'erreur d'intégrité.

---

## 2. Schéma de la Base de Données SQLite

La base `data/vigie.db` comporte 11 tables créées par `database.sql` :
1. `astronautes` : identité, rôle, contact et suppression logique (`delete_at`).
2. `appareils` : correspondance entre matériel physique, source et membre d'équipage.
3. `mesures` : table principale d'acquisition (`create_at`, anti-doublon `idx_mesures_doublon`).
4. `references_perso` : ligne de base individuelle (`moyenne`, `ecart_type`, `n`, `periode_debut`, `periode_fin`).
5. `bilans` : auto-évaluation quotidienne déclarée (humeur, stress, fatigue de 1 à 5).
6. `examens` : saisies ponctuelles manuelles (poids, densité osseuse).
7. `alertes` : journal des alertes produites par le moteur (niveaux 1 et 2, statut d'acquittement).
8. `actions` : traçabilité des mesures prises suite à une alerte (EF-16).
9. `trames_rejetees` : journal d'audit des rejets (P4/P6).
10. `conversations` : historique des échanges avec l'assistant IA.
11. `systeme` : état système clé-valeur et horodatages de réception par source.

---

## 3. Sortie JSON du Moteur d'Analyse (`analyser(con, astro)`)

Exemple de réponse retournée pour `AST2026-001` :
```json
{
  "astro": "AST2026-001",
  "t": "2026-11-15 12:03:05",
  "niveau_global": 1,
  "modules": {
    "cardio": {
      "niveau": 1,
      "indicateurs": [
        {
          "mesure": "pouls",
          "valeur": 71.2,
          "ref": 62.0,
          "ecart_pct": 14.8,
          "tendance_14j": "hausse",
          "derive": true,
          "niveau": 1,
          "confiance": 0.95
        },
        {
          "mesure": "spo2",
          "valeur": 97.4,
          "ref": 97.5,
          "ecart_pct": -0.1,
          "tendance_14j": "stable",
          "derive": false,
          "niveau": 0,
          "confiance": 0.95
        }
      ]
    },
    "os_muscles": {
      "niveau": 0,
      "indicateurs": [
        {
          "mesure": "activite",
          "valeur": 122.0,
          "ref": 125.0,
          "ecart_pct": -2.4,
          "tendance_14j": "stable",
          "derive": false,
          "niveau": 0,
          "confiance": 0.95
        }
      ]
    },
    "immunite": {
      "niveau": 0,
      "indicateurs": [
        {
          "mesure": "temp_peau",
          "valeur": 36.6,
          "ref": 36.5,
          "ecart_pct": 0.3,
          "tendance_14j": "stable",
          "derive": false,
          "niveau": 0,
          "confiance": 0.95
        }
      ]
    },
    "comportement": {
      "niveau": 0,
      "indicateurs": [
        {
          "mesure": "sommeil",
          "valeur": 7.1,
          "ref": 7.2,
          "ecart_pct": -1.4,
          "tendance_14j": "stable",
          "derive": false,
          "niveau": 0,
          "confiance": 0.95
        }
      ]
    }
  },
  "alertes": [
    {
      "regle": "DERIVE_POULS",
      "niveau": 1,
      "module": "cardio",
      "texte_court": "Pouls au repos : dérive lente détectée par rapport à votre référence individuelle"
    }
  ],
  "croisements": [],
  "sources_muettes": []
}
```

---

## 4. Routes API FastAPI (Préfixe `/api`)

### 1. `GET /api/astronautes`
Retourne la liste des membres d'équipage actifs avec leur niveau global calculé en temps réel par Python.
```json
[
  {
    "id": "AST2026-001",
    "first_name": "Orion",
    "last_name": "-",
    "role": "Commandant",
    "email_address": "orion@vigie.local",
    "phone_number": null,
    "statut": 1,
    "created_at": "2026-11-15 10:00:00",
    "updated_at": "2026-11-15 10:00:00",
    "delete_at": null,
    "niveau_global": 0
  }
]
```

### 2. `GET /api/etat/{astro}`
Retourne l'état complet calculé par le moteur d'analyse, enregistre les nouvelles alertes et inclut le champ `explication` (None en attendant l'IA).
En-tête HTTP : `Cache-Control: no-store`.

### 3. `GET /api/mesures/{astro}?mesure=pouls&jours=14&depuis=&limite=500`
Retourne la série chronologique complète enrichie pour le tracé graphique en temps réel :
- `depuis` (exclusif) : extrait uniquement les points postérieurs à cet horodatage (polling incrémental).
- `limite` : borne supérieure de points (défaut 500).
- En-tête HTTP obligatoire : `Cache-Control: no-store`.

Exemple de réponse JSON :
```json
{
  "mesure": "pouls",
  "unite": "bpm",
  "points": [
    {
      "t": "2026-11-15 00:00:00",
      "valeur": 62.4,
      "qualite": "ok"
    },
    {
      "t": "2026-11-15 03:00:00",
      "valeur": 63.1,
      "qualite": "ok"
    }
  ],
  "reference": {
    "moyenne": 62.0,
    "ecart_type": 1.5
  },
  "seuils": {
    "n1": 10.0,
    "n2": 25.0,
    "sens": "haut",
    "type": "relatif_haut",
    "abs_min": 40.0,
    "abs_max": 120.0
  },
  "alertes": [
    {
      "t": "2026-11-18 12:00:00",
      "regle": "DERIVE_POULS",
      "niveau": 1
    }
  ]
}
```

### 4. `POST /api/bilan`
Corps :
```json
{
  "astro": "AST2026-001",
  "humeur": 4,
  "stress": 2,
  "fatigue": 2,
  "symptomes": "légère fatigue après EVA",
  "note": "bonne récupération"
}
```
Réponse :
```json
{
  "ok": true,
  "bilan_id": 1
}
```

### 5. `POST /api/examen`
Corps :
```json
{
  "astro": "AST2026-001",
  "type": "poids",
  "valeur": 73.8,
  "unite": "kg"
}
```
Réponse :
```json
{
  "ok": true,
  "examen_id": 1
}
```

### 6. `GET /api/alertes/{astro}`
Retourne l'historique des alertes pour l'astronaute spécifié :
```json
[
  {
    "id": 1,
    "astro": "AST2026-001",
    "t": "2026-11-15 12:00:00",
    "module": "cardio",
    "niveau": 1,
    "regle": "DERIVE_POULS",
    "texte_court": "Pouls au repos : dérive lente détectée par rapport à votre référence",
    "detail": { "derive": true, "ecart_pct": 14.5 },
    "acquittee": 0,
    "t_acquittement": null
  }
]
```

### 7. `POST /api/alertes/{id}/acquitter`
Réponse :
```json
{
  "ok": true,
  "id": 1
}
```

### 8. `POST /api/assistant`
Corps : `{"astro": "AST2026-001", "question": "Mon sommeil a-t-il un impact sur mon rythme cardiaque ?"}`
Réponse : `HTTP 501 Not Implemented` :
```json
{
  "detail": "L'assistant IA explicatif (RAG/LLM) n'est pas encore activé sur ce banc de test."
}
```

### 9. `GET /api/cabine`
Retourne les dernières mesures environnementales des zones :
```json
{
  "cabine1": {
    "co2": 780.0,
    "o2": 20.9,
    "temp_cabine": 22.4,
    "humidite": 45.0
  },
  "cabine2": {
    "co2": 710.0,
    "o2": 21.0,
    "temp_cabine": 21.8,
    "humidite": 42.0
  }
}
```

### 10. Simulation en direct accélérée (`/api/simulation/*`)

#### A. `POST /api/simulation/demarrer`
Démarre la simulation continue en direct avec vitesse paramétrable :
Corps :
```json
{
  "scenario": "derive_lente",
  "vitesse": 21600.0
}
```
Réponse :
```json
{
  "ok": true,
  "en_cours": true,
  "en_pause": false,
  "scenario": "derive_lente",
  "horloge_simulee": "2026-11-15 00:00:00",
  "vitesse": 21600.0,
  "progression_pct": 50.0
}
```

#### B. `POST /api/simulation/pause`
Suspend l'émission des données :
```json
{
  "ok": true,
  "en_cours": true,
  "en_pause": true,
  "scenario": "derive_lente",
  "horloge_simulee": "2026-11-17 06:00:00",
  "vitesse": 21600.0,
  "progression_pct": 58.0
}
```

#### C. `POST /api/simulation/reprendre`
Reprend la simulation suspendue :
```json
{
  "ok": true,
  "en_cours": true,
  "en_pause": false,
  "scenario": "derive_lente",
  "horloge_simulee": "2026-11-17 06:00:00",
  "vitesse": 21600.0,
  "progression_pct": 58.0
}
```

#### D. `GET /api/simulation/etat`
Consulte l'état courant de l'horloge et de la mission :
```json
{
  "en_cours": true,
  "en_pause": false,
  "scenario": "derive_lente",
  "horloge_simulee": "2026-11-18 12:00:00",
  "vitesse": 21600.0,
  "progression_pct": 62.5
}
```

#### E. `POST /api/simulation/avancer`
Avance déterministe de N pas sans délai (utilisé pour les tests automatisés) :
Corps : `{"pas": 5}`

#### F. `POST /api/simulation/scenario` (Rétro-compatible)
Déclenche la réinitialisation et le démarrage du scénario :
Corps : `{"scenario": "derive_lente", "jours": 28}`

### 11. `GET /api/sante`
Retourne la télémétrie de santé système (âge des capteurs calculé par rapport à l'horloge courante ou simulée) :
```json
{
  "etat": "ok",
  "statut": "operationnel",
  "trames_rejetees": 0,
  "dernieres_trames": {
    "watch": { "derniere_date": "2026-11-18 12:00:00", "age_secondes": 0, "age": "0 s" },
    "sante": { "derniere_date": "2026-11-18 08:00:00", "age_secondes": 14400, "age": "4 h" },
    "cab": { "derniere_date": "2026-11-18 12:00:00", "age_secondes": 0, "age": "0 s" },
    "dosi": { "derniere_date": "2026-11-18 08:00:00", "age_secondes": 14400, "age": "4 h" }
  },
  "nb_mesures": 850,
  "modele_local": "non branche"
}
```

---

## 5. Changements de Contrat (Traçabilité v2.0 -> v2.1)

1. **Route `GET /api/mesures/{astro}`** :
   - Évolution de la forme de réponse : passage d'une liste plate brute `[{create_at, valeur, ...}]` à un objet structuré riche `{"mesure", "unite", "points": [{"t", "valeur", "qualite"}], "reference": {"moyenne", "ecart_type"}, "seuils": {"n1", "n2", "sens", "abs_min", "abs_max"}, "alertes": [{"t", "regle", "niveau"}]}`.
   - Ajout des paramètres de requête `depuis` (exclusif pour le streaming incrémental) et `limite` (plafond de volume).
   - En-tête HTTP obligatoire `Cache-Control: no-store` pour proscrire toute mise en cache navigateur.
2. **Nouvelles routes de contrôle de simulation (`/api/simulation/*`)** :
   - `POST /api/simulation/demarrer` : démarrage avec vitesse accélérée.
   - `POST /api/simulation/pause` : suspension propre du thread.
   - `POST /api/simulation/reprendre` : reprise de l'émission.
   - `GET /api/simulation/etat` : interrogation de l'horloge et progression.
   - `POST /api/simulation/avancer` : avance synchrone de pas pour tests déterministes.
3. **Maintien rétro-compatible** :
   - La route `POST /api/simulation/scenario` reste valide et active le nouveau gestionnaire continu.
