# Décisions d'Architecture et Choix Techniques — Projet Vigie (v2.0)
NASA International Space Apps Challenge 2026

Ce document consigne les décisions d'ingénierie et d'architecture arrêtées pour le projet Vigie.

---

## 1. Identifiants des Membres d'Équipage et Zones de Cabine
- **Constat** : Le cahier des charges initial utilisait des identifiants simplifiés `astro1` à `astro4` dans la trame série, tandis que la base de données relationnelle génère des identifiants normalisés `AST2026-001`.
- **Décision** : Le contrat de validation série accepte désormais formellement le format officiel `AST\d{4}-\d{3}` pour les personnes (ex. `AST2026-001`) et le format `cabine\d` pour les zones partagées (ex. `cabine1`, `cabine2`).
- **Impact Matériel** : Cette décision constitue une évolution contractuelle de la trame série à notifier et documenter auprès de l'équipe firmware / matériel. Une rétro-compatibilité temporaire a été implémentée dans les couches de façade pour garantir l'exécution des tests historiques.

---

## 2. Incohérences de Nommage des Colonnes Temporelles dans `database.sql`
- **Constat** : La table `mesures` utilise `create_at DATETIME` (sans le 'd'), la table `astronautes` utilise `delete_at TEXT`, tandis que toutes les autres tables (`alertes`, `bilans`, `examens`, `references_perso`, `actions`, `conversations`, `systeme`) utilisent `created_at` et `updated_at`.
- **Décision** : Conformément à la consigne stricte de non-altération du schéma SQL existant, aucune colonne de `database.sql` n'a été renommée. L'ensemble des services Python (`database`, `ingestion`, `analyse`, `simulation`, `serveur`) a été harmonisé pour interroger rigoureusement `create_at` sur la table `mesures` et `delete_at` sur `astronautes`. Les fonctions `supprimer_astronaute` et `restaurer_astronaute` qui utilisaient par erreur `deleted_at` ont été corrigées.

---

## 3. Format Unique des Dates et Heures (P3 / Décision 3)
- **Constat** : Présence de formats hétérogènes (`isoformat()` avec séparateur 'T', timestamps Unix, dates sans heure).
- **Décision** : Format unique strict `AAAA-MM-JJ HH:MM:SS` en temps universel coordonné (UTC) dans toute la chaîne de données :
  - Base SQLite (colonnes de dates)
  - Moteur d'analyse (champ `t` de la sortie JSON)
  - API FastAPI (requêtes et réponses)
  - Frontend : affichage UTC natif avec conversion locale optionnelle pour l'utilisateur.

---

## 4. Architecture en Couches et Dépendances Unidirectionnelles
- **Règle** : L'ordre de dépendance strict est `API (serveur) -> Analyse (moteur) -> Database -> Core`.
- **Séparation SQL** : Le dossier `vigie/services/database/` est le seul et unique endroit autorisé à exécuter du SQL. Les routes API et les fonctions du moteur n'exécutent aucun SQL brut et appellent exclusivement les fonctions dédiées de `database`.
- **Configuration** : Un point de lecture unique des fichiers YAML est centralisé dans `vigie.core.config`. Aucun chiffre métier ou seuil médical n'est codé en dur dans le code source.

---

## 5. Principe P2 : Le Calcul Décide, l'IA Explique
- Le frontend et les routes d'API ne calculent aucun indicateur médical, ni seuil, ni alerte.
- Toutes les valeurs proviennent du moteur Python.
- L'assistance IA (route `POST /api/assistant`) est configurée pour retourner HTTP 501 ("Not Implemented") tant que le pipeline RAG/LLM local n'est pas activé.

---

## 6. Autonomie Totale et Hors-Ligne (P3)
- Aucune dépendance à un CDN externe : polices système natives et Canvas 2D pour les graphiques dans le navigateur.
- L'API écoute exclusivement sur l'adresse de bouclage local `127.0.0.1:8000`.
- Aucun appel réseau externe (zéro télémétrie, zéro traqueur).
