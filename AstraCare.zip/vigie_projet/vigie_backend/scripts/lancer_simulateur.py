"""Lance le simulateur sur la base locale.

Exemples (depuis la racine vigie_backend) :
  python -m scripts.lancer_simulateur --scenario derive_lente --jours 28
  python -m scripts.lancer_simulateur --scenario urgence --jours 28
"""
import argparse
from vigie.services.database.connectdb import connecter
from vigie.services.simulation.simulateur import generer, reinitialiser, SCENARIOS, ASTROS
from vigie.services.analyse.references import calculer_references


def main():
    ap = argparse.ArgumentParser(description="Générateur de scénarios de vol Vigie")
    ap.add_argument("--scenario", default="nominal", choices=SCENARIOS, help="Scénario simulé")
    ap.add_argument("--jours", type=int, default=28, help="Nombre de jours de mesures")
    ap.add_argument("--base", default=None, help="Chemin de la base de données")
    args = ap.parse_args()

    con = connecter(args.base)
    print(f"Réinitialisation de la base de données...")
    reinitialiser(con)
    print(f"Génération du scénario '{args.scenario}' sur {args.jours} jours...")
    nb_mesures = generer(con, scenario=args.scenario, jours=args.jours)
    print(f"{nb_mesures} trames insérées avec succès.")
    for a in ASTROS:
        calculer_references(con, a)
    print("Références personnelles calculées pour tous les astronautes.")
    con.close()


if __name__ == "__main__":
    main()
