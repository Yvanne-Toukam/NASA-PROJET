"""Lanceur principal du serveur Vigie (Hybride Uvicorn / Serveur HTTP natif).

Si uvicorn et fastapi sont installés, il démarre l'application FastAPI.
Sinon, il bascule automatiquement sur le serveur HTTP natif de Python
pour garantir un fonctionnement 100% hors-ligne immédiat (P3).
"""
import json
import logging
import os
import sys
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from vigie.core.config import charger_seuils
from vigie.core.constantes import CATALOGUE
from vigie.core.journal import journal
from vigie.services.database import (
    actions,
    alertes as db_alertes,
    astronaute as db_astronaute,
    bilans as db_bilans,
    connectdb,
    examens as db_examens,
    mesures as db_mesures,
    references_perso,
    systeme as db_systeme,
    trames_rejetees as db_trames_rejetees,
)
from vigie.services.analyse import moteur as moteur_analyse
from vigie.services.analyse.references import calculer_references
from vigie.services.simulation import simulateur

RACINE_PROJET = Path(__file__).resolve().parents[2]
DOSSIER_FRONTEND = RACINE_PROJET / "vigie_frontend"
if not DOSSIER_FRONTEND.is_dir():
    DOSSIER_FRONTEND = RACINE_PROJET / "interface"


class VigieHandler(SimpleHTTPRequestHandler):
    """Gestionnaire HTTP servant les fichiers statiques du frontend et les routes /api."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(DOSSIER_FRONTEND), **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(HTTPStatus.OK)
        self.end_headers()

    def repondre_json(self, donnees, code=HTTPStatus.OK):
        corps = json.dumps(donnees, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corps)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(corps)

    def repondre_erreur(self, message, code=HTTPStatus.INTERNAL_SERVER_ERROR):
        code_str = f"HTTP_{int(code)}"
        self.repondre_json({"detail": message, "code": code_str}, code)

    def do_GET(self):
        parsed = urlparse(self.path)
        chemin = parsed.path.rstrip("/")
        params = parse_qs(parsed.query)

        con = connectdb.connecter()
        try:
            # 1. GET /api/astronautes
            if chemin == "/api/astronautes":
                membres = db_astronaute.select_tous_astronautes(con)
                res = []
                for m in membres:
                    etat = moteur_analyse.analyser(con, m["id"])
                    d = dict(m)
                    d["niveau_global"] = etat["niveau_global"]
                    res.append(d)
                return self.repondre_json(res)

            # 2. GET /api/etat/{astro}
            if chemin.startswith("/api/etat/"):
                astro_id = chemin.replace("/api/etat/", "")
                astro = db_astronaute.select_astronaute_id(con, astro_id)
                if not astro:
                    return self.repondre_erreur("Astronaute inconnu ou inactif", HTTPStatus.NOT_FOUND)
                etat = moteur_analyse.analyser(con, astro_id)
                moteur_analyse.enregistrer_alertes(con, etat)
                etat["explication"] = None
                return self.repondre_json(etat)

            # 3. GET /api/mesures/{astro}
            if chemin.startswith("/api/mesures/"):
                astro_id = chemin.replace("/api/mesures/", "")
                mesure = params.get("mesure", ["pouls"])[0] or "pouls"
                jours = int(params.get("jours", [14])[0])
                depuis = params.get("depuis", [None])[0]
                limite = int(params.get("limite", [500])[0])

                points = db_mesures.select_mesures_serie(
                    con, astro_id, mesure=mesure, jours=jours, depuis=depuis, limite=limite
                )
                ref_ligne = references_perso.select_reference(con, astro_id, mesure)
                ref_dict = (
                    {
                        "moyenne": round(ref_ligne["moyenne"], 2),
                        "ecart_type": round(ref_ligne["ecart_type"], 2),
                    }
                    if ref_ligne else None
                )

                cfg = charger_seuils()
                ind_cfg = cfg.get("indicateurs", {}).get(mesure, {})
                seuils_dict = (
                    {
                        "n1": ind_cfg.get("n1"),
                        "n2": ind_cfg.get("n2"),
                        "sens": ind_cfg.get("derive", "haut" if "haut" in ind_cfg.get("type", "") else "bas"),
                        "type": ind_cfg.get("type"),
                        "abs_min": ind_cfg.get("abs_min"),
                        "abs_max": ind_cfg.get("abs_max"),
                    }
                    if ind_cfg else None
                )

                alertes_associees = db_alertes.select_alertes_mesure(con, astro_id, mesure, depuis=depuis)
                unite = CATALOGUE.get(mesure, ("", "", "", "", ""))[1]

                return self.repondre_json({
                    "mesure": mesure,
                    "unite": unite,
                    "points": points,
                    "reference": ref_dict,
                    "seuils": seuils_dict,
                    "alertes": alertes_associees,
                })

            # 6. GET /api/alertes/{astro}
            if chemin.startswith("/api/alertes/"):
                astro_id = chemin.replace("/api/alertes/", "")
                alertes = db_alertes.select_alertes_astro(con, astro_id)
                return self.repondre_json(alertes)

            # 9. GET /api/cabine
            if chemin == "/api/cabine":
                lignes_zones = con.execute("SELECT DISTINCT astro FROM mesures WHERE source = 'cab'").fetchall()
                zones = [l[0] for l in lignes_zones] or ["cabine1", "cabine2"]
                res = {}
                for z in zones:
                    mz = db_mesures.select_dernieres_mesures_zone(con, z)
                    res[z] = {m["mesure"]: m["valeur"] for m in mz}
                return self.repondre_json(res)

            # 10. GET /api/simulation/etat
            if chemin == "/api/simulation/etat":
                return self.repondre_json(simulateur.etat_simulation())

            # 11. GET /api/sante
            if chemin == "/api/sante":
                try:
                    nb_mes = db_mesures.compter_mesures(con)
                except Exception:
                    nb_mes = 0

                try:
                    nb_rej = db_trames_rejetees.compter_rejets(con)
                except Exception:
                    nb_rej = 0

                sim_etat = simulateur.etat_simulation()
                if sim_etat["en_cours"] and sim_etat["horloge_simulee"]:
                    try:
                        reference_dt = datetime.strptime(sim_etat["horloge_simulee"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
                    except Exception:
                        reference_dt = datetime.now(timezone.utc)
                else:
                    reference_dt = datetime.now(timezone.utc)

                dernieres_sources = {}
                toutes_cles = db_systeme.select_tout(con)

                sources_officielles = ["watch", "dosi", "cab", "sante"]
                has_mute = False

                for src in sources_officielles:
                    row = con.execute(
                        "SELECT create_at FROM mesures WHERE source = ? ORDER BY create_at DESC LIMIT 1",
                        (src,),
                    ).fetchone()

                    t_val = row[0] if (row and row[0]) else toutes_cles.get(f"derniere_trame_{src}")
                    if t_val:
                        t_propre = str(t_val).replace("T", " ")[:19]
                        try:
                            dt_trame = datetime.strptime(t_propre, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
                            age_sec = max(0, int((reference_dt - dt_trame).total_seconds()))
                        except Exception:
                            age_sec = 0

                        if age_sec < 60:
                            age_txt = f"{age_sec} s"
                        elif age_sec < 3600:
                            age_txt = f"{age_sec // 60} min"
                        elif age_sec < 86400:
                            age_txt = f"{age_sec // 3600} h"
                        else:
                            age_txt = f"{age_sec // 86400} j"

                        dernieres_sources[src] = {
                            "derniere_date": t_propre,
                            "age_secondes": age_sec,
                            "age": age_txt,
                        }
                    else:
                        dernieres_sources[src] = {
                            "derniere_date": None,
                            "age_secondes": None,
                            "age": "Aucune trame",
                        }

                row_hs = con.execute("SELECT 1 FROM mesures WHERE qualite = 'capteur_hs' LIMIT 1").fetchone()
                if row_hs:
                    has_mute = True

                etat_sys = "degrade" if (has_mute or nb_rej > 5) else "ok"

                return self.repondre_json({
                    "etat": etat_sys,
                    "statut": "operationnel" if etat_sys == "ok" else "mode degrade",
                    "trames_rejetees": nb_rej,
                    "dernieres_trames": dernieres_sources,
                    "nb_mesures": nb_mes,
                    "modele_local": "non branche",
                })

            # 12. GET /api/config/seuils
            if chemin == "/api/config/seuils":
                return self.repondre_json(charger_seuils())

        except Exception as e:
            journal.exception("Erreur GET %s : %s", chemin, e)
            return self.repondre_erreur("Erreur interne du serveur Vigie.", HTTPStatus.INTERNAL_SERVER_ERROR)
        finally:
            con.close()

        # Fichiers statiques du frontend (index.html, style.css, app.js...)
        if self.path == "/" or self.path == "":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        chemin = parsed.path.rstrip("/")
        taille = int(self.headers.get("Content-Length", 0))
        corps_brut = self.rfile.read(taille) if taille > 0 else b"{}"
        try:
            donnees = json.loads(corps_brut.decode("utf-8")) if corps_brut else {}
        except Exception:
            donnees = {}

        con = connectdb.connecter()
        try:
            # 4. POST /api/bilan
            if chemin == "/api/bilan":
                astro_id = donnees.get("astro")
                if not db_astronaute.select_astronaute_id(con, astro_id):
                    return self.repondre_erreur("Astronaute inconnu", HTTPStatus.NOT_FOUND)
                b_id = db_bilans.inserer_bilan(
                    con,
                    astro=astro_id,
                    humeur=donnees.get("humeur", 3),
                    stress=donnees.get("stress", 2),
                    fatigue=donnees.get("fatigue", 2),
                    symptomes=donnees.get("symptomes", ""),
                    note=donnees.get("note", ""),
                )
                return self.repondre_json({"ok": True, "bilan_id": b_id})

            # 5. POST /api/examen
            if chemin == "/api/examen":
                astro_id = donnees.get("astro")
                if not db_astronaute.select_astronaute_id(con, astro_id):
                    return self.repondre_erreur("Astronaute inconnu", HTTPStatus.NOT_FOUND)
                e_id = db_examens.inserer_examen(
                    con,
                    astro=astro_id,
                    type_examen=donnees.get("type", "poids"),
                    valeur=donnees.get("valeur", 70.0),
                    unite=donnees.get("unite", ""),
                )
                return self.repondre_json({"ok": True, "examen_id": e_id})

            # 7. POST /api/alertes/{id}/acquitter
            if chemin.startswith("/api/alertes/") and chemin.endswith("/acquitter"):
                partie_id = chemin.replace("/api/alertes/", "").replace("/acquitter", "")
                try:
                    a_id = int(partie_id)
                    succes = db_alertes.acquitter_alerte(con, a_id)
                    if succes:
                        return self.repondre_json({"ok": True, "id": a_id})
                    return self.repondre_erreur("Alerte introuvable", HTTPStatus.NOT_FOUND)
                except ValueError:
                    return self.repondre_erreur("Id invalide", HTTPStatus.BAD_REQUEST)

            # 8. POST /api/assistant
            if chemin == "/api/assistant":
                return self.repondre_erreur(
                    "L'assistant IA explicatif (RAG/LLM) n'est pas encore activé sur ce banc de test.",
                    HTTPStatus.NOT_IMPLEMENTED,
                )

            # 10. Simulation : Démarrer / Pause / Reprendre / Avancer
            if chemin == "/api/simulation/demarrer":
                sc = donnees.get("scenario", "nominal")
                vit = donnees.get("vitesse")
                if sc not in simulateur.SCENARIOS:
                    return self.repondre_erreur("Scénario inconnu", HTTPStatus.BAD_REQUEST)
                etat = simulateur.demarrer(scenario=sc, vitesse=vit)
                return self.repondre_json({"ok": True, **etat})

            if chemin == "/api/simulation/pause":
                etat = simulateur.pause()
                return self.repondre_json({"ok": True, **etat})

            if chemin == "/api/simulation/reprendre":
                etat = simulateur.reprendre_simulation()
                return self.repondre_json({"ok": True, **etat})

            if chemin == "/api/simulation/avancer":
                n = int(donnees.get("pas", 1))
                etat = simulateur.avancer(n_pas=n)
                return self.repondre_json({"ok": True, **etat})

            if chemin == "/api/simulation/scenario":
                sc = donnees.get("scenario", "nominal")
                if sc not in simulateur.SCENARIOS:
                    return self.repondre_erreur("Scénario inconnu", HTTPStatus.BAD_REQUEST)
                etat = simulateur.demarrer(scenario=sc)
                return self.repondre_json({
                    "ok": True,
                    "scenario": sc,
                    "trames_generees": 14 * 8 * len(simulateur.ASTROS),
                    **etat,
                })

        except Exception as e:
            journal.exception("Erreur POST %s : %s", chemin, e)
            return self.repondre_erreur("Erreur interne du serveur Vigie.", HTTPStatus.INTERNAL_SERVER_ERROR)
        finally:
            con.close()

        return self.repondre_erreur("Route introuvable", HTTPStatus.NOT_FOUND)


def demarrer_serveur(port=8000):
    try:
        import uvicorn
        from vigie.serveur import app
        print("Démarrage du serveur avec FastAPI et Uvicorn sur http://127.0.0.1:8000 ...")
        uvicorn.run("vigie.serveur:app", host="127.0.0.1", port=port, reload=False)
    except ImportError:
        print("Uvicorn/FastAPI non détectés. Bascule automatique sur le serveur HTTP natif de Vigie (P3)...")
        print(f"Serveur actif à l'adresse : http://127.0.0.1:{port}")
        serveur = ThreadingHTTPServer(("127.0.0.1", port), VigieHandler)
        try:
            serveur.serve_forever()
        except KeyboardInterrupt:
            print("\nArrêt du serveur.")
            serveur.server_close()


if __name__ == "__main__":
    demarrer_serveur()
