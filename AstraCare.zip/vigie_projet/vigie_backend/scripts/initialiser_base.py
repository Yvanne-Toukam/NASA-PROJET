"""Initialise la base de données SQLite de Vigie et peuple l'équipage initial."""
from vigie.services.database.connectdb import connecter
from vigie.services.database import astronaute

ASTRONAUTES_INITIAUX = [
    ("AST2026-001", "Orion", "Commandant", "orion@vigie.local"),
    ("AST2026-002", "Lyra", "Ingénieure de vol", "lyra@vigie.local"),
    ("AST2026-003", "Vega", "Médecin de bord", "vega@vigie.local"),
    ("AST2026-004", "Altaïr", "Spécialiste mission", "altair@vigie.local"),
]


def initialiser():
    con = connecter()
    for id_, prenom, role, email in ASTRONAUTES_INITIAUX:
        if not astronaute.select_astronaute_id(con, id_):
            astronaute.inserer_astronaute(
                con,
                first_name=prenom,
                last_name="-",
                role=role,
                email=email,
                astro_id=id_,
            )

    tables = con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()
    print("Tables créées :", [t[0] for t in tables])
    print("Membres d'équipage :", [a["id"] + " " + a["first_name"] for a in astronaute.select_tous_astronautes(con)])
    con.close()


if __name__ == "__main__":
    initialiser()
