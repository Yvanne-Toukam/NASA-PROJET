import sqlite3

ASTRONAUTES = [
    ("AST2026-001", "Orion",  "Commandant",          "orion@vigie.local"),
    ("AST2026-002", "Lyra",   "Ingénieure de vol",   "lyra@vigie.local"),
    ("AST2026-003", "Vega",   "Médecin de bord",     "vega@vigie.local"),
    ("AST2026-004", "Altaïr", "Spécialiste mission", "altair@vigie.local"),
    ("AST2026-005", "Astre5", "À compléter",         "ast5@vigie.local"),
    ("AST2026-006", "Astre6", "À compléter",         "ast6@vigie.local"),
]

con = sqlite3.connect("data/vigie.db")
for id_, prenom, role, email in ASTRONAUTES:
    con.execute(
        "INSERT OR IGNORE INTO astronautes (id, first_name, last_name, role, email_address) "
        "VALUES (?, ?, ?, ?, ?)",
        (id_, prenom, "-", role, email),
    )
con.commit()
print(con.execute("SELECT id, first_name, role FROM astronautes").fetchall())