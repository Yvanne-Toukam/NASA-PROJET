"""Exécute le fichier SQL instruction par instruction pour repérer celle qui échoue."""
import sqlite3
from pathlib import Path

sql = Path("vigie/services/database/database.sql").read_text(encoding="utf-8")
con = sqlite3.connect(":memory:")

for i, instruction in enumerate(sql.split(";"), 1):
    if not instruction.strip():
        continue
    try:
        con.execute(instruction)
    except sqlite3.OperationalError as e:
        print(f"Échec à l'instruction n°{i} : {e}")
        print("---")
        print(instruction.strip())
        break
else:
    print("Tout le fichier est valide.")