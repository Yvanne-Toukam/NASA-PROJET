"""Démarre la boucle du lecteur série sur le port configuré."""
from vigie.core.config import charger_app
from vigie.services.database.connectdb import connecter
from vigie.services.ingestion.lecteur_serie import boucle


def main():
    cfg = charger_app().get("serie", {})
    port = cfg.get("port", "COM2")
    debit = cfg.get("debit", 9600)
    print(f"Démarrage de la lecture série sur {port} à {debit} bauds...")
    boucle(connecter=connecter, port=port, debit=debit)


if __name__ == "__main__":
    main()
