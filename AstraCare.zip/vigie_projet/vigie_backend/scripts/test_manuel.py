"""Test manuel de l'ingestion sans port série."""
import sqlite3
from vigie.services.ingestion.lecteur_serie import traiter_ligne


def executer_test_manuel():
    con = sqlite3.connect(":memory:")
    con.row_factory = sqlite3.Row

    # Schéma SQLite
    from vigie.services.database.connectdb import connecter
    con = connecter(":memory:")

    lignes = [
        "watch,AST2026-001,pouls,72,bpm,ok,9001",   # valide
        "watch,AST2026-001,pouls,72,bpm,ok,9001",   # doublon
        "watch,AST2026-001,pouls,999,bpm,ok,9002",  # hors plage
        "cab,cabine1,co2,4577,ppm,ok,9003",         # valide (cabine)
    ]
    for l in lignes:
        print(traiter_ligne(con, l), "<-", l)

    print("mesures :", [tuple(r) for r in con.execute(
        "SELECT astro, mesure, valeur, qualite, seq FROM mesures WHERE seq >= 9001")])
    print("rejetées :", [tuple(r) for r in con.execute(
        "SELECT ligne, motif FROM trames_rejetees")])
    print("système :", {r[0]: r[1] for r in con.execute("SELECT cle, valeur FROM systeme")})


if __name__ == "__main__":
    executer_test_manuel()
