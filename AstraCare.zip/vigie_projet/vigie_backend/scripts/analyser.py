"""Affiche le JSON d'analyse du moteur pour un astronaute (outil de diagnostic CLI)."""
import argparse
import json
from vigie.services.database.connectdb import connecter
from vigie.services.analyse.moteur import analyser


def main():
    ap = argparse.ArgumentParser(description="Affichage du JSON d'analyse Vigie")
    ap.add_argument("--astro", default="AST2026-001", help="Identifiant astronaute")
    args = ap.parse_args()

    con = connecter()
    res = analyser(con, args.astro)
    print(json.dumps(res, indent=2, ensure_ascii=False))
    con.close()


if __name__ == "__main__":
    main()
